# mlops-poc

This directory contains python code, notebooks and ML resource configs related to one ML project.

See the [Project overview](../docs/project-overview.md) for details on code structure of project directory.