# Databricks notebook source
##################################################################################
# Model Training Notebook
#
# This notebook shows an example of a Model Training pipeline using Delta tables.
# It is configured and can be executed as the "Train" task in the model_training_job workflow defined under
# ``cvm_churn_60_30/resources/model-workflow-resource.yml``
#
# Parameters:
# * env (required):                 - Environment the notebook is run in (staging, or prod). Defaults to "staging".
# * training_catalog (required)     - catalog where we wish to read features from
# * training_schema (required)      - schema where we wish to read features from
# * training_table (required)       - table where we wish to read features from
# * experiment_name (required)      - MLflow experiment name for the training runs. Will be created if it doesn't exist.
# * model_name (required)           - MLflow registered model name to use for the trained model. Will be created if it
# *                                   doesn't exist.
##################################################################################

# COMMAND ----------

# Set up the input parameters for the notebook. These are populated automatically for the jobs but this is helpful for debugging the ntebook in dev environments
dbutils.widgets.dropdown("env", "dev", ["dev", "staging", "prod"], "Environment Name")

dbutils.widgets.text(
    "training_catalog",
    "hive_metastore",
    label="training_catalog",
)

dbutils.widgets.text(
    "training_schema",
    "cvm_churn_60_30",
    label="training_schema",
)

dbutils.widgets.text(
    "training_table",
    "training_features",
    label="training_table",
)

dbutils.widgets.text(
    "experiment_name",
    "/Users/"+ dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get() + "/dev-cvm_churn_60_30_SIM12-experiment",
    label="experiment_name",
)

dbutils.widgets.text(
    "model_name",
    "dev-cvm_churn_60_30_SIM12-model",
    label="model_name",
)

# COMMAND ----------

import os
notebook_path =  '/Workspace/' + os.path.dirname(dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get())
%cd $notebook_path

# COMMAND ----------

# MAGIC %pip install -r ../../requirements.txt

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import os, sys
notebook_path =  '/Workspace/' + os.path.dirname(dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get())
%cd $notebook_path
%cd ..
sys.path.append('..') # Need this to access utils.py

# COMMAND ----------

from steps.train import training_pipeline
from utils import get_latest_model_version
from mlflow.exceptions import RestException
import mlflow

# COMMAND ----------

env = dbutils.widgets.get("env")

metastore_or_catalog = dbutils.widgets.get("training_catalog")
schema = dbutils.widgets.get("training_schema")
table = dbutils.widgets.get("training_table")

experiment_name = dbutils.widgets.get("experiment_name")
model_name = dbutils.widgets.get("model_name")

# COMMAND ----------

try:
    exp_id = mlflow.create_experiment(experiment_name)
except RestException:
    # experiment already exists
    exp_id = dict(mlflow.get_experiment_by_name(experiment_name))['experiment_id']

# COMMAND ----------

training_data_location = '.'.join([metastore_or_catalog, schema, table])
# Get the data in
data_df = spark.sql("SELECT * FROM {} WHERE set='Train' AND LOB='Voice_SIMO' AND COMMITMENT_DURATION=12".format(training_data_location))

# COMMAND ----------

# Do training

features_to_include = [
    "INT_WANT_CANCEL", #interactions
    "INT_TARIFF_ENQ", #interactions
    #"std_BILL_PREV_BALANCE_AMT",
    "three_tenure", #metadata
    #"mean_TOTAL_DUE_AMT",
    #"ONNET_TIME",
    "mean_RECURRING_CHRG_AMT", #billing
    "mean_PAST_DUE_AMT", #billing
    "INT_REFUND_ENQ", #interactions
    "first_contract", #metadata
    "std_TOTAL_DUE_AMT", #billing
    "AVE_UNIQ_NUMS_DIALLED", #usage
    "WTC_CALLS", #interactions
    #"mean_BILL_PREV_BALANCE_AMT",
    "INT_WANT_UPGRADE", #interactions
    #"COUNT_OF_VOICE_CALLS",
    "STDDEV_VOICE", #usage
    "MRC_PRICE_MODIFIER", #contract
    #"voice_time",
    "COUNT_OF_ON_NET_CALLS", #usage
    "STDDEV_DATA", #usage
    #"std_OVERDUE_AMT",
    "mean_BILL_PYM_RECEIVED_AMT", #billing
    #"MEAN_VOICE",
    #"MEAN_DATA",
    "FAH_ROAMING_DATA", #usage
    "WTC_CALL_RECENCY", #interactions
    #"mean_OVERDUE_AMT",
    #"std_BILL_PYM_RECEIVED_AMT", 
    "mean_ROAMING_USAGE_CHRG_AMT",#billing
    "AMOUNT_OF_DATA" #usage
]

data_types = {
    "first_contract": "Boolean",
    "INT_WANT_CANCEL": "Boolean",
    "INT_WANT_UPGRADE": "Boolean",
    "INT_NEW_PH_CON": "Boolean",
    "INT_BILL_ENQ": "Boolean",
    "INT_REFUND_ENQ": "Boolean",
    "INT_TECH_ENQ": "Boolean",
    "INT_MAKE_PAYMENT": "Boolean",
    "INT_NETWORK": "Boolean",
    "INT_TARIFF_ENQ": "Boolean",
    "INT_OFFERS_ENQ": "Boolean",
    "INT_WANT_PAC": "Boolean",
    "INT_WANT_DAT_ADDON": "Boolean",
    "INT_COMP_BETTER_OFFER": "Boolean",
    "INT_WANT_BETTER_DEAL": "Boolean",
    "DATA_AYCE_IND": "Boolean",
    "VOICE_AYCE_IND": "Boolean",
    "mbs_alloc_50": "Boolean",
    "mbs_alloc_75": "Boolean",
    "mbs_alloc_90": "Boolean",
    "mbs_alloc_all": "Boolean",
    "voi_alloc_50": "Boolean",
    "voi_alloc_75": "Boolean",
    "voi_alloc_90": "Boolean",
    "voi_alloc_all": "Boolean",
    "three_tenure": "Numerical",
    "OUTCOME_CASE_RAISED": "Numerical",
    "OUTCOME_PAC_GIVEN": "Numerical",
    "OUTCOME_CONS_OFFER": "Numerical",
    "WTC_CALLS": "Numerical",
    "WTC_CALL_RECENCY": "Numerical",
    "voice_time": "Numerical",
    "AMOUNT_OF_DATA": "Numerical",
    "ONNET_TIME": "Numerical",
    "FAH_ROAMING_DATA": "Numerical",
    "OUT_OF_BUNDLE_TIME": "Numerical",
    "COUNT_OF_VOICE_CALLS": "Numerical",
    "COUNT_OF_ON_NET_CALLS": "Numerical",
    "AVE_UNIQ_NUMS_DIALLED": "Numerical",
    "MEAN_VOICE": "Numerical",
    "STDDEV_VOICE": "Numerical",
    "MEAN_DATA": "Numerical",
    "STDDEV_DATA": "Numerical",
    "accs_opened": "Numerical",
    "acc_acq_rec": "Numerical",
    "accs_closed": "Numerical",
    "accs_upgrade": "Numerical",
    "other_acc_FTG": "Numerical",
    "other_acc_ret_window": "Numerical",
    "other_acc_inlife": "Numerical",
    "MRC_PCT_DISCOUNT_AMORTISED": "Numerical",
    "MRC_TARIFF": "Numerical",
    "MRC_PRICE_MODIFIER": "Numerical",
    "MRC_INSURANCE": "Numerical",
    "MRC_OTHER": "Numerical",
    "MRC_DISCOUNT": "Numerical",
    "DISCOUNT_PERCENTAGE": "Numerical",
    "MRC_PCT_DISCOUNT": "Numerical",
    "MRC_FIXED_DISCOUNT": "Numerical",
    "LOB": "Categorical",
    "COMMITMENT_DURATION": "Categorical",
    "DEVICE_BRAND": "Categorical",
    "GBYTE_ALLOWANCE_GROUP": "Categorical",
    "MINUTES_ALLOWANCE_GROUP": "Categorical",
    "PLAN_TARIFF_GROUP": "Categorical",
    "mean_BILL_PREV_BALANCE_AMT": "Numerical",
    "std_BILL_PREV_BALANCE_AMT": "Numerical",
    "mean_BILL_PYM_RECEIVED_AMT": "Numerical",
    "std_BILL_PYM_RECEIVED_AMT": "Numerical",
    "mean_PAST_DUE_AMT": "Numerical",
    "std_PAST_DUE_AMT": "Numerical",
    "mean_LATE_PYM_BASE_AMT": "Numerical",
    "std_LATE_PYM_BASE_AMT": "Numerical",
    "mean_LATE_PYM_CHRG_AMT": "Numerical",
    "std_LATE_PYM_CHRG_AMT": "Numerical",
    "mean_CURR_DISCOUNT_AMT": "Numerical",
    "std_CURR_DISCOUNT_AMT": "Numerical",
    "mean_TOTAL_DUE_AMT": "Numerical",
    "std_TOTAL_DUE_AMT": "Numerical",
    "mean_OVERDUE_AMT": "Numerical",
    "std_OVERDUE_AMT": "Numerical",
    "mean_RECURRING_CHRG_AMT": "Numerical",
    "std_RECURRING_CHRG_AMT": "Numerical",
    "mean_LOCAL_USAGE_CHRG_AMT": "Numerical",
    "std_LOCAL_USAGE_CHRG_AMT": "Numerical",
    "mean_ROAMING_USAGE_CHRG_AMT": "Numerical",
    "std_ROAMING_USAGE_CHRG_AMT": "Numerical",
    "mean_DATA_USAGE_CHRG_AMT": "Numerical",
    "std_DATA_USAGE_CHRG_AMT": "Numerical",
    "TOTAL_COMPLAINTS": "Numerical",
    "BILLING_COMPLAINTS": "Numerical",
    "NETWORK_COMPLAINTS": "Numerical",
    "SERVICE_COMPLAINTS": "Numerical",
    "DEVICE_COMPLAINTS": "Numerical",
    "BILLING_MOST_RECENT_INT": "Boolean",
    "NETWORK_MOST_RECENT_INT": "Boolean",
    "SERVICE_MOST_RECENT_INT": "Boolean",
    "DEVICE_MOST_RECENT_INT": "Boolean",
    "BILLING_COMPLAINT_MTHS_SINCE": "Categorical",
    "NETWORK_COMPLAINT_MTHS_SINCE": "Categorical",
    "SERVICE_COMPLAINT_MTHS_SINCE": "Categorical",
    "DEVICE_COMPLAINT_MTHS_SINCE": "Categorical",
    "MOST_RECENT_COMPLAINT_MTHS_SINCE": "Categorical",
}

params = {'maxIter': 500, 'maxDepth': 8, 'stepSize': 0.05, 'maxBins': 32}

training_pipeline(data_df, 'SIM12', features_to_include, data_types, params, exp_id=exp_id, model_name=model_name)

# The returned model URI is needed by the model deployment notebook.
model_version = get_latest_model_version(model_name)
model_uri = f"models:/{model_name}/{model_version}"
dbutils.jobs.taskValues.set("model_uri", model_uri)
dbutils.jobs.taskValues.set("model_name", model_name)
dbutils.jobs.taskValues.set("model_version", model_version)
dbutils.notebook.exit(model_uri)