# Databricks notebook source
##################################################################################
# Notify Teams channel about ML job status
#
# This notebook contains the boilerplate code to notify Teams webhook listeners to job statuses
# In other words whether a job succeeds or fails.
# 
# By default this code is set to run at the end of the training and batch inference workflows
# defined in 
# ``cvm_churn_60_30/resources/``
#
# Parameters:
#
# * env (required)                - The environment the task is run in (DEV/SIT/PROD)
# * job_id (required)             - Id of the job
# * run_id (required)             - Id of the psrticular run of the job
# * status (required)             - Status of the run - whether it succeeded or failed
# * teams_webhook_url (required)  - URL for the teams webhook
# * job_title (required)          - the title of the job that will be printed in the teams message
##################################################################################

# COMMAND ----------

# MAGIC %pip install pymsteams==0.2.2

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import pymsteams

# COMMAND ----------

# Get the params
environment = dbutils.widgets.get("env")
job_id = dbutils.widgets.get("job_id")
run_id = dbutils.widgets.get("run_id")
status = dbutils.widgets.get("run_status")
teams_webhook_url = dbutils.widgets.get("webhook_url")
job_title = dbutils.widgets.get("job_title")

# Get some other params from the environment
workspace_url = spark.conf.get("spark.databricks.workspaceUrl")
workspace_id = workspace_url.split('.')[0].split('-')[-1]

# COMMAND ----------

# Set up the text for the message
title = '{e} Environment - {jt} Job Status'.format(e = environment, jt=job_title)

# ToDo: Can we get the workspace url programatically within
main_text = """Job completed with status {s}!
            \n\n 
            \n\n For further information and logs click here:
            \n\n https://{w_url}/?o={w_id}#job/{job}/run/{run}""".format(w_url=workspace_url, w_id=workspace_id, s=status, job=job_id, run=run_id)

# COMMAND ----------

# Construct the message and send
mention_message = pymsteams.connectorcard(teams_webhook_url)

mention_message.title(title)
mention_message.text(main_text)

mention_message.send()