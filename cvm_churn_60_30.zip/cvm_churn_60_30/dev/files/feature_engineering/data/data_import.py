def get_snowflake_table_as_sdf(snowflake_options, table):
    """
    Reads a table from Snowflake and returns it as a Spark DataFrame (sdf).

    Args:
    snowflake_options (dict): A dictionary containing the connection options for Snowflake.
    table (str): The name of the table to be loaded from Snowflake.

    Returns:
    pyspark.sql.DataFrame: A Spark DataFrame containing the data from the specified Snowflake table.
    """

    sdf = (
        spark.read.format("snowflake")
        .options(**snowflake_options)
        .option("dbtable", table)
        .load()
    )

    return sdf


def get_data_dict():
    """
    read in raw data from snowflake tables and return dictionary containing all tables
    """

    prod_user = dbutils.secrets.get(scope="DS_SA", key="username")
    prod_pwd = dbutils.secrets.get(scope="DS_SA", key="password")

    bds_prod_user = dbutils.secrets.get(scope="COEX", key="sf_bds_u")
    bds_prod_pwd = dbutils.secrets.get(scope="COEX", key="sf_bds_p")

    bds_make_consumer_options = {
        "sfUrl": "threemobile.west-europe.privatelink.snowflakecomputing.com",
        "sfUser": f"{prod_user}",
        "sfPassword": f"{prod_pwd}",
        "sfDatabase": "PROD_SANDBOX",
        "sfRole": "DATA3PRODBDSMAKECONSUMER",
        "sfWarehouse": "PRD_BDS_REPORTING_MAKECONSUMER_TRANSFORMATION_WH",
    }

    prod_reader_options = {
        "sfUrl": "threemobile.west-europe.privatelink.snowflakecomputing.com",
        "sfUser": f"{prod_user}",
        "sfPassword": f"{prod_pwd}",
        "sfDatabase": "PROD_SANDBOX",
        "sfRole": "DATA3-PROD-READER",
        "sfWarehouse": "PRD_IDW_REPORTING_WH",
    }

    bds_options = {
        "sfUrl": "threemobile.west-europe.privatelink.snowflakecomputing.com",
        "sfUser": f"{bds_prod_user}",
        "sfPassword": f"{bds_prod_pwd}",
        "sfDatabase": "PROD_SANDBOX",
        "sfSchema": "PRS_B2C_TMP",
        "sfWarehouse": "PRD_IDW_REPORTING_WH",
        "sfRole": "SVCPRDDATA3BDSCONSOLIDATION",
    }

    subscriber_history = get_snowflake_table_as_sdf(
        bds_options, "PROD_SANDBOX.ALDM_ANALYTICS.ENG_SUBSCRIBER_HISTORY"
    )
    subscriber = get_snowflake_table_as_sdf(
        bds_options, "PROD_SANDBOX.ALDM_ANALYTICS.SUBSCRIBER"
    )
    dim_customer_v = get_snowflake_table_as_sdf(
        bds_options, "PROD_SANDBOX.ALDM_ANALYTICS.DIM_CUSTOMER_V"
    )
    ads_interaction_v = get_snowflake_table_as_sdf(
        bds_options, "PROD_SANDBOX.PRS_B2C_TMP.ADS_INTERACTION_V"
    )
    usage_v = get_snowflake_table_as_sdf(
        bds_options, "PROD_SANDBOX.ALDM_ANALYTICS.USAGE_V"
    )
    eng_subscriber_history = get_snowflake_table_as_sdf(
        bds_options, "PROD_SANDBOX.ALDM_ANALYTICS.ENG_SUBSCRIBER_HISTORY_v"
    )
    customer_actions_v = get_snowflake_table_as_sdf(
        bds_options, "PROD_SANDBOX.ALDM_ANALYTICS.TBL_CUSTOMER_ACTIONS_V"
    )
    customer = get_snowflake_table_as_sdf(
        bds_options, "PROD_SANDBOX.ALDM_ANALYTICS.CUSTOMER"
    )
    bill_customer = get_snowflake_table_as_sdf(
        bds_options, "PROD_SANDBOX.ALDM_ANALYTICS.BILL_CUSTOMER"
    )
    interactions_v = get_snowflake_table_as_sdf(
        bds_make_consumer_options, "PROD_SANDBOX.PRS_B2C_TMP.ADS_INTERACTION_V"
    )

    data_dict = {
        "subscriber_history": subscriber_history,
        "subscriber": subscriber,
        "dim_customer_v": dim_customer_v,
        "ads_interaction_v": ads_interaction_v,
        "usage_v": usage_v,
        "eng_subscriber_history": eng_subscriber_history,
        "customer_actions_v": customer_actions_v,
        "customer": customer,
        "bill_customer": bill_customer,
        "interactions_v": interactions_v,
    }

    return data_dict
