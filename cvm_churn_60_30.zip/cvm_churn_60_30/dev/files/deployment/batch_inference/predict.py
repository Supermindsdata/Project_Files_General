import mlflow
from pyspark.sql.types import IntegerType, FloatType
import pyspark.sql.functions as psf
import struct


def predict_batch(
    spark_session,
    model_uri,
    input_table_name,
    output_table_name,
    output_table_name_prod,
    lob,
    commitment_duration,
    metric_id,
    model_version,
    ts,
    env,
):

    PROD_USER = dbutils.secrets.get(scope="DS_SA", key="username")
    PROD_PWD = dbutils.secrets.get(scope="DS_SA", key="password")

    BDS_MAKE_CONSUMER_OPTIONS = {
        "sfUrl": "threemobile.west-europe.privatelink.snowflakecomputing.com",
        "sfUser": f"{PROD_USER}",
        "sfPassword": f"{PROD_PWD}",
        "sfDatabase": "PRD_BDS_MAKECONSUMER",
        "sfSchema": "PROD_MAKECONSUMER",
        "sfRole": "DATA3PRODBDSMAKECONSUMER",
        "sfWarehouse": "PRD_BDS_REPORTING_MAKECONSUMER_TRANSFORMATION_WH",
    }

    table = spark_session.sql(
        "SELECT * FROM {} WHERE LOB={} AND COMMITMENT_DURATION={}".format(
            input_table_name, lob, commitment_duration
        )
    )

    predict = mlflow.pyfunc.spark_udf(
        spark_session, model_uri, result_type="string", env_manager="virtualenv"
    )

    get_probability = psf.udf(lambda x: float(x[1]), FloatType())

    output_table = (
        table.withColumn("prediction", predict(struct(*table.columns)))
        .withColumn("probability_positive", get_probability(psf.col("probability")))
        .withColumn(
            "SCORE",
            (psf.round(psf.col("probability_positive"), 2) * 100).astype(IntegerType()),
        )
        .withColumn("METRIC_ID", psf.lit(metric_id))
        .withColumn("MODEL_DATE", psf.to_timestamp(psf.lit(ts)))
        .withColumn("MODEL_VERSION", psf.lit(model_version))
    )

    output_table.write.format("delta").mode("overwrite").saveAsTable(output_table_name)
    #if env == "Prod":
    #    prod_output_table = output_table.select(
    #        "SUBSCRIBER_KEY", "CUSTOMER_KEY", "METRIC_ID", "SCORE", "MODEL_DATE"
    #    ).distinct()
    #    prod_output_table.write.format("snowflake").options(
    #        **BDS_MAKE_CONSUMER_OPTIONS
    #    ).option("dbtable", output_table_name_prod).mode("append").save()
