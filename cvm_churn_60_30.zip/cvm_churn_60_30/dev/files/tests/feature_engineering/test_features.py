from pyspark.sql import SparkSession
from feature_engineering.features import featurization
import pytest


@pytest.fixture(scope="session")
def spark_session():
    """
    Fixture to create a SparkSession for testing.

    Returns:
        SparkSession: The SparkSession instance.
    """
    spark = SparkSession.builder.master("local[*]").appName("TestApp").getOrCreate()
    yield spark
    spark.stop()


def test_get_subs_history_filter_training(spark_session):

    subscriber_history_data = [
        ("B2C", "Individual", "Voice_SIMO", "2024-03-15", "2023-03-09", None),
        ("B2C", "Individual", "Voice_CHS", "2024-04-01", "2023-04-01", None),
        ("B2B", "Business", "Voice_SIMO", "2024-03-01", "2023-03-01", None),
        (
            "B2C",
            "Individual",
            "Data_SIMO",
            "2024-03-10",
            "2023-03-10",
            "3333-03-03T00:00:00Z",
        ),
        ("B2C", "Individual", "Voice_SIMO", "2024-03-20", "2023-03-20", None),
        ("B2C", "Individual", "Voice_CHS", "2024-03-25", "2023-03-25", None),
    ]
    subscriber_history_schema = [
        "CUSTOMER_TYPE",
        "CUSTOMER_SUB_TYPE",
        "LOB",
        "COMMITMENT_END_DATE",
        "DISCONNECTION_DATE",
        "DISCONNECTION_DATE_SPECIAL",
    ]
    subscriber_history = spark_session.createDataFrame(
        subscriber_history_data, subscriber_history_schema
    )

    subscriber_window_start = "2023-03-01"
    subscriber_window_end = "2024-04-01"
    filtered_data = featurization.get_subs_history_filter_training(
        subscriber_history, subscriber_window_start, subscriber_window_end
    ).collect()

    expected_data = [
        ("B2C", "Individual", "Voice_SIMO", "2024-03-15", None),
        ("B2C", "Individual", "Voice_CHS", "2024-04-01", None),
        ("B2C", "Individual", "Voice_SIMO", "2024-03-20", None),
        ("B2C", "Individual", "Voice_CHS", "2024-03-25", None),
    ]

    assert filtered_data == expected_data, "get_subs_history_filter_training failed"


def test_get_subs_history_filter_inference(spark_session):

    subscriber_history_data = [
        ("B2C", "Individual", "Voice_SIMO", "2024-03-15", "2023-03-09", None),
        ("B2C", "Individual", "Voice_CHS", "2024-04-01", "2023-04-01", None),
        ("B2B", "Business", "Voice_SIMO", "2024-03-01", "2023-03-01", None),
        (
            "B2C",
            "Individual",
            "Data_SIMO",
            "2024-03-10",
            "2023-03-10",
            "3333-03-03T00:00:00Z",
        ),
        ("B2C", "Individual", "Voice_SIMO", "2024-03-20", "2023-03-20", None),
        ("B2C", "Individual", "Voice_CHS", "2024-03-25", "2023-03-25", None),
    ]
    subscriber_history_schema = [
        "CUSTOMER_TYPE",
        "CUSTOMER_SUB_TYPE",
        "LOB",
        "COMMITMENT_END_DATE",
        "DISCONNECTION_DATE",
        "DISCONNECTION_DATE_SPECIAL",
    ]
    subscriber_history = spark_session.createDataFrame(
        subscriber_history_data, subscriber_history_schema
    )

    filtered_data = featurization.get_subs_history_filter_inference(
        subscriber_history
    ).collect()

    expected_data = [
        ("B2C", "Individual", "Voice_SIMO", "2024-03-15", None, -24),
        ("B2C", "Individual", "Voice_CHS", "2024-03-25", None, -14),
    ]

    assert filtered_data == expected_data, "get_subs_history_filter_inference failed"
