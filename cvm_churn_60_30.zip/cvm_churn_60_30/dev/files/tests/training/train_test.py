from cvm_churn_60_30.training.steps.train import training_pipeline, balanced_sample, compute_metrics
import unittest
import pyspark.sql.functions as psf

class TestTrain(unittest.TestCase):
    """
    Test cases for the training directory
    """

    def test_balanced_sample(self):

        data = [
            (1, "A", 1),
            (2, "B", 0),
            (3, "C", 1),
            (4, "D", 0),
            (5, "E", 1)
        ]
        schema = ["id", "category", "binary_column"]
        df = spark.createDataFrame(data, schema=schema)

        balanced_df = balanced_sample(df, "binary_column")

        assert balanced_df.count() == 4
        
        positive_count = balanced_df.filter(psf.col("binary_column") == 1).count()
        negative_count = balanced_df.filter(psf.col("binary_column") == 0).count()
        assert positive_count == negative_count, "Positive and negative samples should be equal in count"

    def test_compute_metrics(self):

        data = [
            (1, 1),  # True Positive
            (0, 0),  # True Negative
            (1, 0),  # False Negative
            (0, 1),  # False Positive
            (1, 1),  # True Positive
        ]


        schema = ["churn_flag","prediction"]
        df = spark.createDataFrame(data, schema=schema)

        # Expected outcomes
        expected_precision = 2 / (2 + 1)  # TP / (TP + FP)
        expected_recall = 2 / (2 + 1)  # TP / (TP + FN)
        expected_f1 = 2 * (expected_precision * expected_recall) / (expected_precision + expected_recall)

        # Compute metrics
        precision, recall, f1 = compute_metrics(df)

        # Assertions
        assert precision == expected_precision, f"Expected precision: {expected_precision}, but got: {precision}"
        assert recall == expected_recall, f"Expected recall: {expected_recall}, but got: {recall}"
        assert f1 == expected_f1, f"Expected F1: {expected_f1}, but got: {f1}"

if __name__ == "__main__":
    unittest.main()