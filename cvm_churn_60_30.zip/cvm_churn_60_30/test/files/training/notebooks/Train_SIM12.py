# Databricks notebook source
##################################################################################
# Model Training Notebook
#
# This notebook shows an example of a Model Training pipeline using Delta tables.
# It is configured and can be executed as the "Train" task in the model_training_job workflow defined under
# ``cvm_churn_60_30/resources/model-workflow-resource.yml``
#
# Parameters:
# * env (required):                 - Environment the notebook is run in (staging, or prod). Defaults to "staging".
# * training_catalog (required)     - catalog where we wish to read features from
# * training_schema (required)      - schema where we wish to read features from
# * training_table (required)       - table where we wish to read features from
# * experiment_name (required)      - MLflow experiment name for the training runs. Will be created if it doesn't exist.
# * model_name (required)           - MLflow registered model name to use for the trained model. Will be created if it
# *                                   doesn't exist.
##################################################################################

# COMMAND ----------

# Set up the input parameters for the notebook. These are populated automatically for the jobs but this is helpful for debugging the ntebook in dev environments
dbutils.widgets.dropdown("env", "dev", ["dev", "staging", "prod"], "Environment Name")

dbutils.widgets.text(
    "training_catalog",
    "hive_metastore",
    label="training_catalog",
)

dbutils.widgets.text(
    "training_schema",
    "cvm_churn_60_30",
    label="training_schema",
)

dbutils.widgets.text(
    "training_table",
    "training_features",
    label="training_table",
)

dbutils.widgets.text(
    "experiment_name",
    "/Users/"+ dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get() + "/dev-cvm_churn_60_30_SIM12-experiment",
    label="experiment_name",
)

dbutils.widgets.text(
    "model_name",
    "dev-cvm_churn_60_30_SIM12-model",
    label="model_name",
)

# COMMAND ----------

import os
notebook_path =  '/Workspace/' + os.path.dirname(dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get())
%cd $notebook_path

# COMMAND ----------

# MAGIC %pip install -r ../../requirements.txt

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import os, sys
notebook_path =  '/Workspace/' + os.path.dirname(dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get())
%cd $notebook_path
%cd ..
sys.path.append('..') # Need this to access utils.py

# COMMAND ----------

from steps.train import training_pipeline
from utils import get_latest_model_version
from mlflow.exceptions import RestException
import mlflow
from sklearn.ensemble import GradientBoostingClassifier

# COMMAND ----------

env = dbutils.widgets.get("env")

metastore_or_catalog = dbutils.widgets.get("training_catalog")
schema = dbutils.widgets.get("training_schema")
table = dbutils.widgets.get("training_table")

experiment_name = dbutils.widgets.get("experiment_name")
model_name = dbutils.widgets.get("model_name")

# COMMAND ----------

try:
    exp_id = mlflow.create_experiment(experiment_name)
except RestException:
    # experiment already exists
    exp_id = dict(mlflow.get_experiment_by_name(experiment_name))['experiment_id']

# COMMAND ----------

training_data_location = '.'.join([metastore_or_catalog, schema, table])
training_input = "SELECT * FROM {} WHERE set='train' AND LOB='Voice_SIMO' AND COMMITMENT_DURATION=12".format(training_data_location)
validation_input = "SELECT * FROM {} WHERE set='test' AND LOB='Voice_SIMO' AND COMMITMENT_DURATION=12".format(training_data_location)
data_df = spark.sql(training_input)

# COMMAND ----------

# Do training

features_to_include = ['first_contract',
 'three_tenure',
 'voice_time',
 'ONNET_TIME',
 'FAH_ROAMING_DATA',
 'OUT_OF_BUNDLE_TIME',
 'COUNT_OF_VOICE_CALLS',
 'COUNT_OF_ON_NET_CALLS',
 'AVE_UNIQ_NUMS_DIALLED',
 'MEAN_VOICE',
 'STDDEV_DATA',
 'acc_acq_rec',
 'accs_closed',
 'accs_upgrade',
 'other_acc_FTG',
 'other_acc_ret_window',
 'other_acc_inlife',
 'MRC_PCT_DISCOUNT_AMORTISED',
 'MRC_TARIFF',
 'MRC_PRICE_MODIFIER',
 'MRC_INSURANCE',
 'MRC_OTHER',
 'MRC_DISCOUNT',
 'DISCOUNT_PERCENTAGE',
 'MRC_PCT_DISCOUNT',
 'MRC_FIXED_DISCOUNT',
 'LOB',
 'COMMITMENT_DURATION',
 'DEVICE_TYPE',
 'DEVICE_BRAND',
 'DEVICE_MODEL',
 'GBYTE_ALLOWANCE_GROUP',
 'MINUTES_ALLOWANCE_GROUP',
 'mean_RECURRING_CHRG_AMT',
 'mean_LOCAL_USAGE_CHRG_AMT',
 'std_LOCAL_USAGE_CHRG_AMT',
 'mean_ROAMING_USAGE_CHRG_AMT',
 'mean_DATA_USAGE_CHRG_AMT',
 'int_want_upgrade',
 'int_new_ph_con',
 'int_bill_enq',
 'int_total']

data_types = {
    "first_contract": "Boolean",
    "DATA_AYCE_IND": "Boolean",
    "VOICE_AYCE_IND": "Boolean",
    "mbs_alloc_50": "Boolean",
    "mbs_alloc_75": "Boolean",
    "mbs_alloc_90": "Boolean",
    "mbs_alloc_all": "Boolean",
    "voi_alloc_50": "Boolean",
    "voi_alloc_75": "Boolean",
    "voi_alloc_90": "Boolean",
    "voi_alloc_all": "Boolean",
    "three_tenure": "Numerical",
    "voice_time": "Numerical",
    "AMOUNT_OF_DATA": "Numerical",
    "ONNET_TIME": "Numerical",
    "FAH_ROAMING_DATA": "Numerical",
    "OUT_OF_BUNDLE_TIME": "Numerical",
    "COUNT_OF_VOICE_CALLS": "Numerical",
    "COUNT_OF_ON_NET_CALLS": "Numerical",
    "AVE_UNIQ_NUMS_DIALLED": "Numerical",
    "MEAN_VOICE": "Numerical",
    "STDDEV_VOICE": "Numerical",
    "MEAN_DATA": "Numerical",
    "STDDEV_DATA": "Numerical",
    "accs_opened": "Numerical",
    "acc_acq_rec": "Numerical",
    "accs_closed": "Numerical",
    "accs_upgrade": "Numerical",
    "other_acc_FTG": "Numerical",
    "other_acc_ret_window": "Numerical",
    "other_acc_inlife": "Numerical",
    "MRC_PCT_DISCOUNT_AMORTISED": "Numerical",
    "MRC_TARIFF": "Numerical",
    "MRC_PRICE_MODIFIER": "Numerical",
    "MRC_INSURANCE": "Numerical",
    "MRC_OTHER": "Numerical",
    "MRC_DISCOUNT": "Numerical",
    "DISCOUNT_PERCENTAGE": "Numerical",
    "MRC_PCT_DISCOUNT": "Numerical",
    "MRC_FIXED_DISCOUNT": "Numerical",
    "LOB": "Categorical",
    "COMMITMENT_DURATION": "Categorical",
    "DEVICE_TYPE": "Categorical",
    "DEVICE_BRAND": "Categorical",
    "DEVICE_MODEL": "Categorical",
    "GBYTE_ALLOWANCE_GROUP": "Categorical",
    "MINUTES_ALLOWANCE_GROUP": "Categorical",
    "PLAN_TARIFF_GROUP": "Categorical",
    "mean_BILL_PREV_BALANCE_AMT": "Numerical",
    "std_BILL_PREV_BALANCE_AMT": "Numerical",
    "mean_BILL_PYM_RECEIVED_AMT": "Numerical",
    "std_BILL_PYM_RECEIVED_AMT": "Numerical",
    "mean_PAST_DUE_AMT": "Numerical",
    "std_PAST_DUE_AMT": "Numerical",
    "mean_LATE_PYM_BASE_AMT": "Numerical",
    "std_LATE_PYM_BASE_AMT": "Numerical",
    "mean_LATE_PYM_CHRG_AMT": "Numerical",
    "std_LATE_PYM_CHRG_AMT": "Numerical",
    "mean_CURR_DISCOUNT_AMT": "Numerical",
    "std_CURR_DISCOUNT_AMT": "Numerical",
    "mean_TOTAL_DUE_AMT": "Numerical",
    "std_TOTAL_DUE_AMT": "Numerical",
    "mean_OVERDUE_AMT": "Numerical",
    "std_OVERDUE_AMT": "Numerical",
    "mean_RECURRING_CHRG_AMT": "Numerical",
    "std_RECURRING_CHRG_AMT": "Numerical",
    "mean_LOCAL_USAGE_CHRG_AMT": "Numerical",
    "std_LOCAL_USAGE_CHRG_AMT": "Numerical",
    "mean_ROAMING_USAGE_CHRG_AMT": "Numerical",
    "std_ROAMING_USAGE_CHRG_AMT": "Numerical",
    "mean_DATA_USAGE_CHRG_AMT": "Numerical",
    "std_DATA_USAGE_CHRG_AMT": "Numerical",
    'int_want_cancel': "Numerical",
    'int_want_upgrade': "Numerical",
    'int_new_ph_con': "Numerical",
    'int_bill_enq': "Numerical",
    'int_refund_enq': "Numerical",
    'int_tech_enq': "Numerical",
    'int_make_payment': "Numerical",
    'int_network': "Numerical",
    'int_tariff_enq': "Numerical",
    'int_offers_enq': "Numerical",
    'int_want_pac': "Numerical",
    'int_want_dat_addon': "Numerical",
    'int_comp_better_offer': "Numerical",
    'int_want_better_deal': "Numerical",
    'outcome_case_raised': "Numerical",
    'outcome_pac_given': "Numerical",
    'outcome_cons_offer': "Numerical",
    'WTC_calls': "Numerical",
    'int_total': "Numerical",
    'Total_complaints': "Numerical",
    'Billing_complaints': "Numerical",
    'Network_complaints': "Numerical",
    'Service_complaints': "Numerical",
    'Device_complaints': "Numerical",
}

params = {
    'classifier__n_estimators': [200],
    'classifier__max_depth': [3],
    'classifier__learning_rate': [0.01]
}

classifier = GradientBoostingClassifier(random_state=42)
mlflow_flavour = mlflow.sklearn

training_pipeline(data_df, features_to_include, data_types, classifier, mlflow_flavour, params, exp_id=exp_id, model_name=model_name)

# The returned model URI is needed by the model deployment notebook.
model_version = get_latest_model_version(model_name)
model_uri = f"models:/{model_name}/{model_version}"
dbutils.jobs.taskValues.set("model_uri", model_uri)
dbutils.jobs.taskValues.set("model_name", model_name)
dbutils.jobs.taskValues.set("model_version", model_version)
dbutils.jobs.taskValues.set("validation_input", validation_input)
dbutils.notebook.exit(model_uri)