import mlflow
from pyspark.ml import Pipeline
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import GridSearchCV
import numpy as np


def training_pipeline(
    training_sdf,
    features_to_include,
    data_types,
    classifier,
    mlflow_flavour,
    params,
    exp_id=None,
    model_name=None,
):
    """
    Trains a machine learning model pipeline using scikit-learn and logs the results in MLflow.

    Parameters:
    - training_sdf (pyspark.sql.DataFrame): Training data in Spark DataFrame format.
    - features_to_include (list): List of feature names to include in the training.
    - data_types (dict): Dictionary mapping feature names to their data types.
    - classifier (scikit-learn estimator): Classifier or estimator to be used in the pipeline.
    - mlflow_flavour (mlflow object): MLflow flavor for logging the model and results.
    - params (dict): Dictionary of parameters to be tuned for the classifier using GridSearchCV.
    - exp_id (int, optional): Experiment ID in MLflow to log the training results. If not provided, a new experiment will be created.
    - model_name (str, optional): Name to register the trained model in MLflow model registry. If not provided, model won't be registered.
    """

    BOOL_COLS = [i for i in features_to_include if data_types[i] == "Boolean"]

    NUMERICAL_COLS = [i for i in features_to_include if data_types[i] == "Numerical"]

    CATEGORICAL_COLS = [
        i for i in features_to_include if data_types[i] == "Categorical"
    ]

    train_pdf = training_sdf.toPandas()

    # Create column transformers
    bool_transformer = Pipeline(
        steps=[("onehot", OneHotEncoder(handle_unknown="ignore"))]
    )

    numerical_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="mean")),
            ("scaler", StandardScaler()),
        ]
    )

    categorical_transformer = Pipeline(
        steps=[("onehot", OneHotEncoder(handle_unknown="ignore"))]
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("bool", bool_transformer, BOOL_COLS),
            ("numerical", numerical_transformer, NUMERICAL_COLS),
            ("categorical", categorical_transformer, CATEGORICAL_COLS),
        ]
    )

    pipeline = Pipeline(
        steps=[("preprocessor", preprocessor), ("classifier", classifier)]
    )

    # Create the grid search object
    grid_search = GridSearchCV(pipeline, params, cv=3, scoring="roc_auc")

    # Balance the training data
    train_pdf_balanced = pd.concat(
        [
            train_pdf[train_pdf["churn_flag"] == 0].sample(
                n=len(train_pdf[train_pdf["churn_flag"] == 1]), random_state=42
            ),
            train_pdf[train_pdf["churn_flag"] == 1],
        ],
        0,
    )

    # Split the balanced training data into features and target
    X_train = train_pdf_balanced[features_to_include]
    y_train = train_pdf_balanced["churn_flag"]

    with mlflow.start_run(experiment_id=exp_id) as run:

        grid_search.fit(X_train, y_train)

        best_model = grid_search.best_estimator_
        cv_results = grid_search.cv_results_

        sample_output = best_model.predict(X_train)
        signature = mlflow.models.infer_signature(X_train, sample_output)

        mlflow_flavour.log_model(
            best_model,
            artifact_path="model",
            registered_model_name=model_name,
            signature=signature,
        )

        best_index = np.argmax(cv_results["mean_test_score"])
        best_mean_score = cv_results["mean_test_score"][best_index]

        mlflow.log_metrics({"roc_auc": best_mean_score})

        run = mlflow.active_run()
        mlflow.set_tag("candidate", "true")

        print("Training completed!")
        print("Model and artifacts saved to active run_id: {}".format(run.info.run_id))
