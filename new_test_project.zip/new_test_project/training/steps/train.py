"""
Here we define a training pipeline used to train a simple model using cross validation
"""

def training_pipeline(d, exp_id=None, model_name=None):
    import numpy as np
    from sklearn.linear_model import LinearRegression
    from sklearn.model_selection import cross_validate
    from sklearn.metrics import r2_score, mean_absolute_error, make_scorer
    import mlflow

    mlflow.sklearn.autolog()

    with mlflow.start_run(experiment_id=exp_id) as run:
        # Define the model
        mdl = LinearRegression()

        # Split the predictors and targets
        X = d.drop('target', axis=1)
        y = d['target']

        # Perform cross validation
        scores = cross_validate(mdl, 
                                X, 
                                y, 
                                cv=10, 
                                scoring={'r2': make_scorer(r2_score), 
                                        'mae': make_scorer(mean_absolute_error)}, 
                                n_jobs=-1,
                                error_score='raise',
                                return_train_score=True)

        # Train on entire dataset
        mdl.fit(X, y)

        signature = mlflow.models.infer_signature(X, mdl.predict(X))

        mlflow.sklearn.log_model(
            mdl, artifact_path="model", registered_model_name=model_name, signature=signature
        )
        
        # Get the run id to find the artifacts etc. programatically:
        run = mlflow.active_run()

        # Log validation metrics (mlflow.sklearn.autolog automatically logs the training metrics)
        mlflow.log_metrics({
            "avg_cv_test_r2": np.mean(scores['test_r2']),
            "avg_cv_test_mae": np.mean(scores['test_mae'])
            })
        
        mlflow.set_tag('candidate', 'true')

        print('Training completed!')
        print("Model and artifacts saved to active run_id: {}".format(run.info.run_id))