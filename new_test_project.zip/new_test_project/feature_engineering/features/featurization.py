"""
Within this file we define our feature engineering logic.
"""

def clean_col_names(df):
    """
    Adds sensible column names
    """
    import pandas as pd

    df.columns = ['feature_a', 'feature_b', 'target']
    return df