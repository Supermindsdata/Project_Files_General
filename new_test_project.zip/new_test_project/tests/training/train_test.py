from new_test_project.training.steps.train import training_pipeline

import unittest

class TestTrain(unittest.TestCase):
    """
    Test cases for the data directory
    """
    def test_training_pipeline(self):
        # TODO: Add tests
        pass

if __name__ == '__main__':
    unittest.main()