from new_test_project.feature_engineering.features.featurization import clean_col_names
import unittest
import pandas as pd

class TestFeature(unittest.TestCase):
    """
    Test cases for the data directory
    """
    def test_clean_col_names(self):
        test_input = pd.DataFrame(
            {
                'a': [1, 2, 3],
                'b': [4, 3, 5],
                'c': [1, 4, 7]
            }
            )
        
        output = clean_col_names(test_input)

        self.assertListEqual(output.columns.to_list(), ['feature_a', 'feature_b', 'target'])

if __name__ == '__main__':
    unittest.main()