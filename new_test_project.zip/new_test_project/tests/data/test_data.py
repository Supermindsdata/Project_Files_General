from new_test_project.feature_engineering.data.data_import import get_data
import unittest

class TestData(unittest.TestCase):
    """
    Test cases for the data directory
    """
    def test_get_data(self):
        X = get_data()

        self.assertEqual(X.shape, (1000, 3))

if __name__ == '__main__':
    unittest.main()