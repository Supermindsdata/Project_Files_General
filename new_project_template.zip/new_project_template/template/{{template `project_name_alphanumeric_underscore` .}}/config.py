"""
Use this file to keep track of variables that will change between iterations:
- Names of tables/files in source databases
- Column names
- Values to infill missing data
- Model parameters
etc.
"""

expected_cols = ['feature_a', 'feature_b', 'target']

model_metric_thresholds_dict = {
    'mean_cv_test_neg_mean_absolute_error': -100, # Negative so that we can always assert higher values are better!
    'validation_mae': -100
}

expected_artifacts_list = ['training_prediction_errors.png', 'validation_prediction_errors.png']