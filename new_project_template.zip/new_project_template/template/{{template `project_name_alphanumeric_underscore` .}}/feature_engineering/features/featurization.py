"""
Within this file we define our feature engineering logic.
"""
import config as cg

def clean_col_names(df, training_mode=True):
    """
    Adds sensible column names
    """
    if training_mode:
        df.columns = cg.expected_cols
    else:
        df.columns = cg.expected_cols
        df = df.drop('target', axis=1)
    return df