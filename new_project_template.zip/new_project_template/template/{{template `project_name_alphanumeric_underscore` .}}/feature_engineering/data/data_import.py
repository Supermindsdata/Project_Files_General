"""
This file contains the functions necessary to load data from the source systems into databricks.
"""
def get_data():
    """
    Function that loads our raw data.

    Replace the below boilerplate with appropriate code to read from snowflake/databricks/excel etc
    """

    from sklearn.datasets import make_regression
    import pandas as pd

    d  = make_regression(n_samples=1000, n_features=2, n_informative=2, noise=0.1, random_state=42)

    data_df = pd.concat([pd.DataFrame(d[0]), pd.Series(d[1])], axis=1)
    
    return data_df