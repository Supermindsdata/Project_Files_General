"""
Here we define a training pipeline used to train a simple model using cross validation
"""

import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_validate, train_test_split
from sklearn.metrics import mean_absolute_error, PredictionErrorDisplay
import mlflow
import matplotlib.pyplot as plt


def training_pipeline(d, model_name=None):

    mlflow.sklearn.autolog()

    with mlflow.start_run() as run:
        # Define the model
        mdl = LinearRegression()

        # Split the predictors and targets
        X = d.drop('target', axis=1)
        y = d['target']

        X_train, X_valid, y_train, y_valid = train_test_split(X, y, random_state=42)

        # Perform cross validation
        scores = cross_validate(mdl, 
                                X_train, 
                                y_train, 
                                cv=5, 
                                scoring='neg_mean_absolute_error', 
                                n_jobs=-1,
                                error_score='raise',
                                return_train_score=True)

        compute_and_log_cv_scores(scores)

        # Train on entire trtain data
        mdl.fit(X_train, y_train)

        # Predict on Training and validation set (we build plots and final outputs from these)
        training_preds = mdl.predict(X_train)
        validation_preds = mdl.predict(X_valid)

        # Log validation scores
        compute_and_log_validation_scores(y_valid, validation_preds)

        # Log plots
        compute_and_log_plots(y_train, training_preds, y_valid, validation_preds)

        # Retrain the model one last time with all the data!
        mdl.fit(X, y)

        mlflow.sklearn.log_model(
            mdl, 
            artifact_path="final_model", 
            registered_model_name=model_name, 
            input_example=X_train.iloc[[0]]
        )
        
        print('Training completed!')
        print("Model and artifacts saved to active run_id: {}".format(run.info.run_id))


def compute_and_log_cv_scores(s: dict) -> None:
    """
    Computes and logs the model metrics folowing cross-validation

    Args:
        s: a dictionary containing the cross validation metrics

    Returns:
        None
    """
    # Compute metrics
    mean_cv_train_mae = np.mean(s['train_score'])
    var_cv_train_mae = np.var(s['train_score'], ddof=1)
    mean_cv_test_mae = np.mean(s['test_score'])
    var_cv_test_mae = np.var(s['test_score'], ddof=1)

    #Log metrics
    mlflow.log_metrics({'mean_cv_train_neg_mean_absolute_error': mean_cv_train_mae,
                        'var_cv_train_neg_mean_absolute_error': var_cv_train_mae,
                        'mean_cv_test_neg_mean_absolute_error': mean_cv_test_mae,
                        'var_cv_test_neg_mean_absolute_error': var_cv_test_mae})
    
    return None

def compute_and_log_validation_scores(valid_y_true: pd.Series, v_preds: np.array) -> None:
    """
    Computes and logs the model metrics for the held out validation set

    Args:
        valid_y_true: Ground truth labels
        v_preds: predictions
    Returns:
        None
    """
    
    # Compute validation scores
    validation_mae = mean_absolute_error(valid_y_true, v_preds.ravel())
    # Log validation scores
    mlflow.log_metrics({
        'validation_mae': -validation_mae # Negative so that we can assert higher values are better!
        })
    return None

def compute_and_log_plots(train_true: pd.Series, train_predictions: np.array, validation_true: pd.Series, validation_predictions: np.array) -> None:
    """
    Creates and logs the required plots

    Args:
        train_true: Training set ground truth labels
        train_predictions: Model predictions for the training samples
        validation_true: Validation set ground truth labels
        validation_predictions: Model predictions for the validation samples
    Returns:
        None
    """

    def create_error_plot(true_vals: pd.Series, predictions: np.array, context: str) -> None:
        """
        Generates and logs a precision-recall plot
        
        Args:
            true_vals: ground truth labels
            predictions: model predictions for the samples
            context: String telling us whether we are plotting the training or validation metrics
        Returns:
            None
        """
        fig, ax = plt.subplots()
        disp = PredictionErrorDisplay.from_predictions(y_true=true_vals, y_pred=predictions, ax=ax)
        ax.set_title(context + ' Prediction Errors')
        plt.tight_layout()
        mlflow.log_figure(fig, context.lower() + '_prediction_errors.png')
        plt.close(fig)

        return None
    
    for i in [(train_true, train_predictions, 'Training'), (validation_true, validation_predictions, 'Validation')]:
        create_error_plot(*i)

    return None