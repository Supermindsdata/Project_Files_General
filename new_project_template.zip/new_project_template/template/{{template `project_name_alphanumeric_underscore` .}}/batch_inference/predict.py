"""
This script contains functions related to the prediction task

Here we have a traditional prediction task on a pandas df.

It is also possible to predict on a spark df directly which is more suited to larger inference tasks
"""
import mlflow
import pandas as pd
import numpy as np

def predict_batch(model_uri: str, input_features: pd.DataFrame) -> np.ndarray:
    """
    Apply the model at the specified URI for batch inference on the table with name input_table_name,
    writing results to the table with name output_table_name

    Args:
        model_uri: model location. Must be of the form: "models:/catalog.schema.model_name@Champion"
        input_features: a pandas dataframe containing the input features for prediction
    Returns:
        scores_final: an array of scores from the model
    """
    # Load the model
    mlflow.set_registry_uri("databricks-uc")

    print("Loading registered model version from URI: '{}'".format(model_uri))
    model = mlflow.sklearn.load_model(model_uri)

    # Score samples
    scores = model.predict(input_features)

    return scores