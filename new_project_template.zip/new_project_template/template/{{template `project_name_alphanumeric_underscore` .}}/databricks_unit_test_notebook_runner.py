# Databricks notebook source
# This notebook is used to invoke the unit tests without deploying the project via azure pipelines.
# The notebook is not used by the main pipeline

# COMMAND ----------

# MAGIC %pip install -r ../test-requirements.txt

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import pytest
import sys

# Skip writing pyc files on a readonly filesystem.
sys.dont_write_bytecode = True

# Run pytest.
retcode = pytest.main([".", "-v", "-p", "no:cacheprovider"])

# Fail the cell execution if there are any test failures.
assert retcode == 0, "The pytest invocation failed. See the log for details."
