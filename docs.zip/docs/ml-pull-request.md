# Updating ML code in production

[(back to main README)](../README.md)

## Table of contents
* [Intro](#intro)
* [Opening a pull request](#opening-a-pull-request)
* [Viewing test status and debug logs](#viewing-test-status-and-debug-logs)
* [Merging your pull request](#merging-your-pull-request)
* [Next steps](#next-steps)

## Intro
After following the
[ML quickstart](ml-developer-guide.md).
to iterate on ML code, the next step is to get
your updated code merged back into the repo for production use. This page walks you through the workflow
for doing so via a pull request.

## Opening a pull request
### Add project reference to Azure devops build definition

Prior to opening a pull request for a brand new project, ensure that the project has been added to the [get_project_to_build.ps1](.azure/devops_pipelines/get_project_to_build.ps1) file. To add the reference for a new project follow these steps:

1. Open the file within VS Code
2. Within the `$editedFiles` section, add a reference to your new project:
    ```ps1
    "<new_project_name/*>" {
            Write-Host "<new_project_name> changed"
            AppendQueueVariable "<new_project_name>"
        }
    ```

Once this has been added the buoild pipeline will be able to pick up and build only the project that has changed within the pull request.

### Open a pull request

To push your updated ML code to production, [open a pull request](https://learn.microsoft.com/en-us/azure/devops/repos/git/pull-requests?view=azure-devops&tabs=browser#create-a-pull-request) against the remote Git repo containing the current project.

## Viewing test status and debug logs
Opening a pull request will trigger [Azure DevOps Pipeline](../.azure/devops-pipelines/mlops-poc-tests-ci.yml) that runs unit and integration tests for the model training pipeline on Databricks. A model will be built, logged and validated on a test dataset (specified in `project_name/resources/model-workflow-resource.yml` under `task_key: ModelValidation` by default).

You can view test status and debug logs from the pull request UI, and push new commits to your pull request branch
to address any test failures.

The integration test runs the model training notebook in the staging workspace, training, validating,
and registering a new model version in the model registry. The fitted model along with its metrics and params
will also be logged to an MLflow run. To debug failed integration test runs, click into the Databricks job run
URL printed in the test logs. The job run page will contain a link to the MLflow model training run:

![Link to MLFlow Run](images/MLFlowRunLink.png)

Click the MLflow run link to view training metrics or fetch and debug the model as needed.



## Merging your pull request
Once tests pass on your pull request, get your pull request reviewed and approved by a teammate,
and then merge it into the upstream repo.

## Next Steps
After merging your pull request, subsequent runs of the model training and batch inference
jobs in staging and production will automatically use your updated ML code.

You can track the state of the ML pipelines for the current project from the MLflow registered model UI.

In both the staging and prod workspaces, the MLflow registered model contains links to:
* The model versions produced through automated retraining
* The Git repository containing the ML code run in the training and inference pipelines
 
* The recurring training job that produces new model versions using the latest ML code and data
* The model deployment CD workflow that takes model versions produced by the training job and deploys them for inference
* The recurring batch inference job that uses the currently-deployed model version to score a dataset
