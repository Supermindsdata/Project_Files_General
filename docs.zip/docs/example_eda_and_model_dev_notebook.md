# Introduction
This file provides an example of the kind of EDA and experimentation we would recommend when carrying out the inital exploration or PoC phase of a project.

What is shown here is not an exhaustive list of EDA and model validation techniques as these will vary between projects.

It should be considered as more of a general guide. The data understanding, feature engineering and model development phases of a real project are often far more extensive and in depth.

# Notebook
This is a reproduction of a databricks notebook in markdown format. This version is for easier viewing in VS Code and in the repo.

There is a [databricks notebook](example-eda-and-model-development-notebook.py) also saved that is best viewed in the databricks interface.
## Imports
```python
import pandas as pd
import numpy as np
from sklearn.datasets import make_regression
```

## Load Data
```python
d  = make_regression(n_samples=1000, n_features=2, n_informative=2, noise=0.1, random_state=42)

data_df = pd.concat([pd.DataFrame(d[0]), pd.Series(d[1])], axis=1)

data_df.columns 
= [0, 1, 2]
```

## Explore Data
```python
data_df.shape
```
`(1000, 3)`

---
```python
data_df.head()
```
![df head](images/notebook_images/df_head.png)

---
```python
data_df.isna().sum()
```
```
0    0
1    0
2    0
dtype: int64
```

---
```python
data_df.describe()
```
![summary stats](images/notebook_images/summary_statistics.png)
---
```python
import seaborn as sns

sns.pairplot(data_df);
```

![pairplot](images/notebook_images/pairplot.png)

## EDA Findings
We see some interesting things about the data:
* There is no missing data
* Features are normally distributed
* High degree of correlation between feature 0 and target

## Modelling
## Feature Engineering
```python
# First do some feature engineering
data_df.columns = ['feature_a', 'feature_b', 'target'] # Just something simple to demonstrate

# Now split the data into train and test
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(data_df.drop('target', axis=1), data_df['target'], test_size=0.1, random_state=42)
```
## Train Model
```python
import mlflow
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_validate
from sklearn.metrics import r2_score, mean_absolute_error, make_scorer

#######################################################
### Best practice is to define your own experiment! ###
#######################################################
experiment_name = 'mlops_example_experiment'
username = dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()
experiment_path = '/Users/{u}/{e}'.format(u=username, e=experiment_name)
try:
    exp_id = mlflow.create_experiment(experiment_path)
except RestException:
    # experiment already exists
    exp_id = dict(mlflow.get_experiment_by_name(experiment_path))['experiment_id']
print('Experiment ID is: {}'.format(exp_id))

# Disable mlflow autologging until we are ready to log the artifacts
mlflow.autolog(disable=True)

# Define the model
mdl = LinearRegression()

# Perform cross validation
scores = cross_validate(mdl, 
                        X_train, 
                        y_train, 
                        cv=10, 
                        scoring={'r2': make_scorer(r2_score), 
                                'mae': make_scorer(mean_absolute_error)}, 
                        n_jobs=-1,
                        error_score='raise',
                        return_train_score=True)

# Retrain on entire dataset
mdl.fit(X_train, y_train)
```

## Validate model performance
```python
scores_df = pd.DataFrame(scores).mean()
scores_df
```
```
fit_time      0.003028
score_time    0.001852
test_r2       0.999994
train_r2      0.999994
test_mae      0.078643
train_mae     0.078360
dtype: float64
```
---
```python
# Log model artifacts
with mlflow.start_run(experiment_id=exp_id):
    # Log the metrics
    metrics = {"mean_train_r2": scores_df['train_r2'],
               "mean_test_r2": scores_df['test_r2'],
               "mean_train_mae": scores_df['train_mae'],
               "mean_test_mae": scores_df['test_mae']}
    mlflow.log_metrics(metrics)

    # Set a tag that we can use to remind ourselves what this run was for
    mlflow.set_tag("Training Info", "Example Linear Regression model")

    # Infer the model signature
    signature = mlflow.models.infer_signature(X_train, mdl.predict(X_train))

    # Log the model
    model_info = mlflow.sklearn.log_model(
        sk_model=mdl,
        artifact_path="example_mlops_model",
        signature=signature,
        input_example=X_train[:10]
    )
```
---
```python
# Plot model performance
import matplotlib.pyplot as plt
fig, ax = plt.subplots(ncols = 3, figsize=(15, 5))
ax = ax.flatten()

ax[0].scatter(test_set_preds, y_test)
ax[0].plot([min(test_set_preds), max(test_set_preds)], [min(y_test), max(y_test)], color='black')
ax[0].set_title('Actuals vs. Model Predictions')
ax[0].set_xlabel('Predictions')
ax[0].set_ylabel('Actuals')

ax[1].scatter(test_set_preds, test_set_errors)
ax[1].plot([min(test_set_preds), max(test_set_preds)], [0, 0], color='black')
ax[1].set_title('Residuals vs. Model Predictions')
ax[1].set_xlabel('Predictions')
ax[1].set_ylabel('Residuals')

ax[2].hist(test_set_errors, bins=10)
ax[2].set_title('Distribution of Residuals')
ax[2].set_xlabel('Residual value')
ax[2].set_ylabel('Count')

plt.show()
```
![model performance](images/notebook_images/model_performance_viz.png)
---
## Model Performance Findings
* Model metrics are favourable with high R2 and low MAE
* Test set predictions align closely with actuals
* Minimal heteroskedasticity in the predictions
* Residuals are close to normally distributed

From this we can conclude that a ML model will be effective in this scenario