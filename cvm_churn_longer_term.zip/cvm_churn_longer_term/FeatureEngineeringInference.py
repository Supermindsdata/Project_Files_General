# Databricks notebook source
##################################################################################
# Generate and Write Features Notebook
#
# This notebook can be used to generate and write features to a table.
# It is configured and can be executed as the tasks in the write_feature_table_job workflow defined under
# ``cvm_churn_60_30/resources/feature-engineering-workflow-resource.yml``
#
# Parameters:
#
# * output_catalog (required)  - catalog where we wish to save the features
# * output_schema (required)  - schema where we wish to save the features
# * output_table (required)  - table where we wish to save the features
##################################################################################

# COMMAND ----------

# Set up the input parameters for the notebook. These are populated automatically for the jobs but this is helpful for debugging the ntebook in dev environments

dbutils.widgets.text(
    "output_catalog",
    "hive_metastore",
    label="output_catalog",
)

dbutils.widgets.text(
    "output_schema",
    "cvm_churn_60_30",
    label="output_schema",
)

dbutils.widgets.text(
    "output_table",
    "inference_features",
    label="output_table",
)

# COMMAND ----------

import os
import sys
notebook_path =  '/Workspace/' + os.path.dirname(dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get())
%cd $notebook_path
%cd ..

# COMMAND ----------

# MAGIC %run ./data_import

# COMMAND ----------

# MAGIC %run ./featurization

# COMMAND ----------

from data.data_import import get_data_dict
from features.featurization import get_features

# COMMAND ----------

# Get the location to save the training data to (recommended to save as table)
metastore_or_catalog = dbutils.widgets.get("output_catalog")
schema = dbutils.widgets.get("output_schema")
table = dbutils.widgets.get("output_table")

schema_location = '.'.join([metastore_or_catalog, schema])
table_location = '.'.join([metastore_or_catalog, schema, table])

# COMMAND ----------

# Make the schema and table
spark.sql("CREATE SCHEMA IF NOT EXISTS {}".format(schema_location))

# COMMAND ----------

data_dict = get_data_dict()
feature_data = get_features(spark,data_dict,schema_location)

# COMMAND ----------

# Save data to delta table
feature_data.write.mode('overwrite').saveAsTable(table_location)

# COMMAND ----------

import pyspark.sql.functions as psf

subs_history_filter = spark.read.table('hive_metastore.cvm_churn_90_60.subs_history_filterinf')
customer_sample_w_churn_flag = spark.read.table('hive_metastore.cvm_churn_90_60.customer_sample_w_churn_flag_inf')
customer_sample_keys = spark.read.table('hive_metastore.cvm_churn_90_60.customer_sample_keys_inf')

subs_history_filter = subs_history_filter.filter(psf.col('LOB')=='Voice_CHS')

print(subs_history_filter.count())

customer_sample = (
    subs_history_filter
    .select(
        "CUSTOMER_KEY",
        "SUBSCRIBER_KEY",
        "COMMITMENT_START_DATE",
        "COMMITMENT_END_DATE",
        "DISCONNECTION_DATE",
        "model_date",
    )
    .distinct()
)

print(customer_sample.count())

customer_sample_w_churn_flag = (
    customer_sample.withColumn(
        "DISCONNECTION_DATE",
        psf.when(
            psf.col("DISCONNECTION_DATE") == "3333-03-03T00:00:00Z", None
        ).otherwise(psf.col("DISCONNECTION_DATE")),
    )
    .withColumn(
        "days_remaining",
        -1 * psf.datediff(psf.col("model_date"), psf.col("COMMITMENT_END_DATE")),
    )
    .withColumn("30d_start", psf.date_add(psf.col("model_date"), -30))
    .withColumn("90d_start", psf.date_add(psf.col("model_date"), -90))
)


customer_sample_w_churn_flag_n = customer_sample_w_churn_flag

customer_sample_w_churn_flag_n.count()

# COMMAND ----------

subs_history_filter.filter(psf.col('LOB')=='Voice_SIMO').filter(psf.col('COMMITMENT_DURATION')==12).count()