# Databricks notebook source
# MAGIC %run ./data_import

# COMMAND ----------

import pyspark.sql.functions as psf

# COMMAND ----------

data_dict = get_data_dict()

# COMMAND ----------

customer_sample_w_churn_flag_90_60 = spark.read.table("hive_metastore.cvm_churn_90_60_1.customer_sample_w_churn_flag_train")
customer_sample_w_churn_flag_120_90 = spark.read.table("hive_metastore.cvm_churn_120_90.customer_sample_w_churn_flag_train")

customer_sample_w_churn_flag_90_60.select("CUSTOMER_KEY").distinct().join(customer_sample_w_churn_flag_120_90.select("CUSTOMER_KEY").distinct(),on="CUSTOMER_KEY",how="inner").count()

# COMMAND ----------

customer_sample_w_churn_flag_120_90.select("CUSTOMER_KEY").distinct().count()

# COMMAND ----------

CUSTOMER_KEY = "977894962"
customer_sample_w_churn_flag_90_60.filter(psf.col('CUSTOMER_KEY')==CUSTOMER_KEY).display()
customer_sample_w_churn_flag_120_90.filter(psf.col('CUSTOMER_KEY')==CUSTOMER_KEY).display()

# COMMAND ----------

training_data_location = "hive_metastore.cvm_churn_90_60_1.training_data"
training_data = spark.read.table(training_data_location)
training_data.filter(psf.col('CUSTOMER_KEY')==CUSTOMER_KEY).display()

# COMMAND ----------

training_data_location = "hive_metastore.cvm_churn_120_90.training_data"
training_data = spark.read.table(training_data_location)
training_data.filter(psf.col('CUSTOMER_KEY')==CUSTOMER_KEY).display()

# COMMAND ----------


customer_sample_w_churn_flag= spark.read.table("hive_metastore.cvm_churn_90_60_1.customer_sample_w_churn_flag_train")

eng_subscriber_history = data_dict['eng_subscriber_history']

eng_subscriber_history_b2c = eng_subscriber_history.filter(
    psf.col("customer_type") == "B2C"
)

acquisition_condition = psf.col("ORDER_ACTION_DESC") == "Acquisition"
disconnection_condition = psf.col("tariff_action") == "Disconnection"
upgrade_condition = psf.col("tariff_action") == "Upgrade"

days_since_commitment_end = psf.datediff(
    psf.col("model_date"), psf.to_date(psf.col("COMMITMENT_END_DATE"))
)
in_FTG_condition = days_since_commitment_end <= 0
in_retention_window_condition = (days_since_commitment_end > 0) & (
    days_since_commitment_end <= 60
)
inlife_condition = days_since_commitment_end > 60

eng_subscriber_history_agg = (
    eng_subscriber_history_b2c.join(
        customer_sample_w_churn_flag.select(
            "CUSTOMER_KEY", "SUBSCRIBER_KEY", "model_date"
        ),
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="inner",
    )
    .filter(psf.col("START_DATE") < psf.col("model_date"))
    .filter(psf.col("tariff_action") == "Upgrade")
    .select("CUSTOMER_KEY","SUBSCRIBER_KEY","START_DATE","tariff_action")
    .distinct()
)

eng_subscriber_history_agg.display()