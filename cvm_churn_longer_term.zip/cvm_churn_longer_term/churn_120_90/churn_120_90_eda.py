# Databricks notebook source
# MAGIC %md
# MAGIC ## Import Packages

# COMMAND ----------

import pyspark.sql.functions as psf
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import Functions

# COMMAND ----------

# MAGIC %run ./data_import

# COMMAND ----------

# MAGIC %run ./featurization

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get Data

# COMMAND ----------

training_data_location = "hive_metastore.cvm_churn_120_90_rw.training_data"
train_df = spark.sql("SELECT * FROM {} WHERE set='train' AND LOB='Voice_CHS'".format(training_data_location))
test_df = spark.sql("SELECT * FROM {} WHERE set='test' AND LOB='Voice_CHS'".format(training_data_location))

# COMMAND ----------

data_dict = get_data_dict()

# COMMAND ----------

subscriber = data_dict["subscriber"]
subscriber_history = data_dict["subscriber_history"]
usage_v = data_dict["usage_v"]
eng_subscriber_history = data_dict["eng_subscriber_history"]
bill_customer = data_dict["bill_customer"]
customer = data_dict["customer"]
port_in_request = data_dict["port_in_request"]
interactions_v = data_dict["interactions_v"]
complaints = data_dict["complaints"]
dim_subscriber_key_t = data_dict["dim_subscriber_key_t"]

# COMMAND ----------

schema_path = "hive_metastore.cvm_churn_120_90_rw."
customer_sample_w_churn_flag = spark.read.table(schema_path + "customer_sample_w_churn_flag" + "_train")
customer_sample_keys = spark.read.table(schema_path + "customer_sample_keys" + "_train")
subs_history_filter = spark.read.table(schema_path + "subs_history_filter" + "_train")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Count of Customers

# COMMAND ----------

print(customer_sample_w_churn_flag.count())
print(customer_sample_w_churn_flag.select('CUSTOMER_KEY','SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Contract Details

# COMMAND ----------

customer_contract_details_final = get_contract_details(subs_history_filter, customer_sample_w_churn_flag)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Counts

# COMMAND ----------

print(customer_contract_details_final.count())
print(customer_contract_details_final.select('CUSTOMER_KEY','SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Nulls

# COMMAND ----------

features_list = ['LOB', 'COMMITMENT_DURATION', 'GBYTE_ALLOWANCE', 'GBYTE_ALLOWANCE_GROUP', 'MINUTES_ALLOWANCE', 'MINUTES_ALLOWANCE_GROUP', 'PLAN_TARIFF', 'PLAN_TARIFF_GROUP', 'AMORTISED_DEVICE_COST', 'MRC_DEAL_WITHOUT_ADDONS_EXVAT', 'NMRC_BLENDED_DEAL', 'MRC_BLENDED_DEAL', 'MRC_PCT_DISCOUNT_AMORTISED', 'MRC_TARIFF', 'MRC_PRICE_MODIFIER', 'MRC_INSURANCE', 'MRC_OTHER', 'MRC_DISCOUNT', 'DISCOUNT_PERCENTAGE', 'MRC_PCT_DISCOUNT', 'MRC_FIXED_DISCOUNT', 'DEVICE_BRAND', 'DEVICE_MODEL', 'DEVICE_TYPE', 'RRPPRICE_INC_VAT', 'SIM_TYPE']

null_counts = customer_contract_details_final.select([psf.sum(psf.col(c).isNull().cast("int")).alias(c) for c in features_list])

null_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### View Distributions

# COMMAND ----------

# Plot distribution of GBYTE_ALLOWANCE_GROUP
sns.countplot(data=customer_contract_details_final.toPandas(), x='GBYTE_ALLOWANCE_GROUP')
plt.show()

# Plot distribution of MINUTES_ALLOWANCE_GROUP
sns.countplot(data=customer_contract_details_final.toPandas(), x='MINUTES_ALLOWANCE_GROUP')
plt.show()

# Plot distribution of PLAN_TARIFF_GROUP
sns.countplot(data=customer_contract_details_final.toPandas(), x='PLAN_TARIFF_GROUP')
plt.xticks(rotation=90)
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Metadata

# COMMAND ----------

customer_metadata_final = get_customer_metadata(subscriber, subscriber_history, customer_sample_w_churn_flag)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Counts

# COMMAND ----------

print(customer_metadata_final.count())
print(customer_metadata_final.select('CUSTOMER_KEY','SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Nulls

# COMMAND ----------

features_list = ["age", "three_tenure", "first_contract"]

null_counts = customer_metadata_final.select([psf.sum(psf.col(c).isNull().cast("int")).alias(c) for c in features_list])

null_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC * SUBSCRIBER_BIRTH_DATE is sometimes null or 1900 - can impute for age

# COMMAND ----------

# MAGIC %md
# MAGIC #### View Distributions

# COMMAND ----------

# Plot distribution of age
sns.histplot(data=customer_metadata_final.toPandas(), x="age")
plt.show()

# Plot distribution of three_tenure
sns.histplot(data=customer_metadata_final.toPandas(), x="three_tenure")
plt.show()

# Plot distribution of first_contract
sns.countplot(data=customer_metadata_final.toPandas(), x="first_contract")
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Usage

# COMMAND ----------

date_end = customer_sample_w_churn_flag.agg(psf.max('model_date')).collect()[0]['max(model_date)']
date_start = customer_sample_w_churn_flag.agg(psf.min('model_date')).collect()[0]['min(model_date)']
years, months = get_year_month_lists(date_start, date_end, days_delta=30)

customer_usage_final = get_customer_usage(customer_sample_w_churn_flag, customer_sample_keys, usage_v, years, months)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Counts

# COMMAND ----------

print(customer_usage_final.count())
print(customer_usage_final.select('CUSTOMER_KEY','SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Nulls

# COMMAND ----------

customer_usage_final = spark.read.table(schema_path + "customer_usage" + "_train")

features_list = ['voice_time',
 'AMOUNT_OF_DATA',
 'ONNET_TIME',
 'MOLO_TIME',
 'FAH_TIME',
 'FAH_ROAMING_DATA',
 'OUT_OF_BUNDLE_TIME',
 'COUNT_OF_VOICE_CALLS',
 'COUNT_OF_ON_NET_CALLS',
 'COUNT_OF_MOLO_CALLS',
 'COUNT_OF_FAH_CALLS',
 'AVE_UNIQ_NUMS_DIALLED',
 'MEAN_VOICE',
 'STDDEV_VOICE',
 'MEAN_DATA',
 'STDDEV_DATA']

null_counts = customer_usage_final.select([psf.sum(psf.col(c).isNull().cast("int")).alias(c) for c in features_list])

null_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC * some without usage in last 30 days - can fill with zero

# COMMAND ----------

# MAGIC %md
# MAGIC #### View Distributions

# COMMAND ----------

pdf = customer_usage_final.limit(10000).toPandas()

# COMMAND ----------

# Plot distribution of AVE_UNIQ_NUMS_DIALLED
sns.histplot(data=pdf, x='AVE_UNIQ_NUMS_DIALLED')
plt.show()

# Plot distribution of MEAN_DATA
pdf['MEAN_DATA'] = pd.to_numeric(pdf['MEAN_DATA'], errors='coerce')
pdf['MEAN_DATA_BUCKET'] = (pdf['MEAN_DATA'] // 100).round()
sns.histplot(data=pdf, x='MEAN_DATA_BUCKET')
plt.show()

# Plot distribution of FAH_ROAMING_DATA
pdf['FAH_ROAMING_DATA'] = pd.to_numeric(pdf['FAH_ROAMING_DATA'], errors='coerce')
pdf['FAH_ROAMING_DATA_BUCKET'] = (pdf['FAH_ROAMING_DATA'] // 100).round()
sns.histplot(data=pdf, x='FAH_ROAMING_DATA_BUCKET')
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Multiple Accounts

# COMMAND ----------

customer_multiple_accounts_final = get_customer_multiple_accounts(customer_sample_keys, customer_sample_w_churn_flag, eng_subscriber_history)

# COMMAND ----------

eng_subscriber_history_b2c = eng_subscriber_history.filter(
    psf.col("customer_type") == "B2C"
)

acquisition_condition = psf.col("ORDER_ACTION_DESC") == "Acquisition"
disconnection_condition = psf.col("tariff_action") == "Disconnection"
upgrade_condition = psf.col("tariff_action") == "Upgrade"

days_since_commitment_end = psf.datediff(
    psf.col("model_date"), psf.to_date(psf.col("COMMITMENT_END_DATE"))
)
in_FTG_condition = days_since_commitment_end <= 0
in_retention_window_condition = (days_since_commitment_end > 0) & (
    days_since_commitment_end <= 60
)
inlife_condition = days_since_commitment_end > 60

eng_subscriber_history_agg = (
    eng_subscriber_history_b2c.join(
        customer_sample_w_churn_flag.select(
            "CUSTOMER_KEY", "SUBSCRIBER_KEY", "model_date"
        ),
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="inner",
    )
    .filter(psf.col("START_DATE") < psf.col("model_date"))
    .groupBy("CUSTOMER_KEY")
    .agg(
        psf.countDistinct("SUBSCRIBER_KEY").alias("accs_opened"),
        psf.countDistinct(
            psf.when(acquisition_condition, psf.col("SUBSCRIBER_KEY"))
        ).alias("acc_acq_rec"),
        psf.countDistinct(
            psf.when(disconnection_condition, psf.col("SUBSCRIBER_KEY"))
        ).alias("accs_closed"),
        psf.countDistinct(
            psf.when(upgrade_condition, psf.col("SUBSCRIBER_KEY"))
        ).alias("accs_upgrade"),
        psf.countDistinct(
            psf.when(in_FTG_condition, psf.col("SUBSCRIBER_KEY"))
        ).alias("other_acc_FTG"),
        psf.countDistinct(
            psf.when(in_retention_window_condition, psf.col("SUBSCRIBER_KEY"))
        ).alias("other_acc_ret_window"),
        psf.countDistinct(
            psf.when(inlife_condition, psf.col("SUBSCRIBER_KEY"))
        ).alias("other_acc_inlife"),
    )
)

customer_multiple_accounts_final = customer_sample_keys.join(
    eng_subscriber_history_agg, on="CUSTOMER_KEY", how="left"
).distinct()

# COMMAND ----------

customer_multiple_accounts_final.filter(psf.col('CUSTOMER_KEY')=='100042362').display()

# COMMAND ----------

customer_sample_w_churn_flag.display()

# COMMAND ----------

eng_subscriber_history_b2c.filter(psf.col('CUSTOMER_KEY')=='100042362').display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Counts

# COMMAND ----------

print(customer_multiple_accounts_final.count())
print(customer_multiple_accounts_final.select('CUSTOMER_KEY','SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Nulls

# COMMAND ----------

features_list = ['accs_opened', 'acc_acq_rec', 'accs_closed', 'accs_upgrade', 'other_acc_FTG', 'other_acc_ret_window', 'other_acc_inlife']

null_counts = customer_multiple_accounts_final.select([psf.sum(psf.col(c).isNull().cast("int")).alias(c) for c in features_list])

null_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### View Distributions

# COMMAND ----------

customer_multiple_accounts_final.groupby('accs_opened').count().display()
customer_multiple_accounts_final.groupby('accs_closed').count().display()
customer_multiple_accounts_final.groupby('accs_upgrade').count().display()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Billing

# COMMAND ----------

customer_billing_final = get_customer_billing(customer_sample_w_churn_flag, customer_sample_keys, bill_customer)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Counts

# COMMAND ----------

print(customer_billing_final.count())
print(customer_billing_final.select('CUSTOMER_KEY','SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Nulls

# COMMAND ----------

features_list = ['mean_BILL_PREV_BALANCE_AMT', 'std_BILL_PREV_BALANCE_AMT', 'mean_BILL_PYM_RECEIVED_AMT', 'std_BILL_PYM_RECEIVED_AMT', 'mean_PAST_DUE_AMT', 'std_PAST_DUE_AMT', 'mean_LATE_PYM_BASE_AMT', 'std_LATE_PYM_BASE_AMT', 'mean_LATE_PYM_CHRG_AMT', 'std_LATE_PYM_CHRG_AMT', 'mean_CURR_DISCOUNT_AMT', 'std_CURR_DISCOUNT_AMT', 'mean_TOTAL_DUE_AMT', 'std_TOTAL_DUE_AMT', 'mean_OVERDUE_AMT', 'std_OVERDUE_AMT', 'mean_RECURRING_CHRG_AMT', 'std_RECURRING_CHRG_AMT', 'mean_LOCAL_USAGE_CHRG_AMT', 'std_LOCAL_USAGE_CHRG_AMT', 'mean_ROAMING_USAGE_CHRG_AMT', 'std_ROAMING_USAGE_CHRG_AMT', 'mean_DATA_USAGE_CHRG_AMT', 'std_DATA_USAGE_CHRG_AMT']

null_counts = customer_billing_final.select([psf.sum(psf.col(c).isNull().cast("int")).alias(c) for c in features_list])

null_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC * missing values - can fill with zero
# MAGIC * small number have had no billing data captured in last 90 days

# COMMAND ----------

# MAGIC %md
# MAGIC #### View Distributions

# COMMAND ----------

pdf = customer_billing_final.toPandas()

# COMMAND ----------

# Plot distribution of mean_TOTAL_DUE_AMT
sns.histplot(data=pdf, x='mean_TOTAL_DUE_AMT')
plt.show()

# Plot distribution of mean_PAST_DUE_AMT
sns.histplot(data=pdf, x='mean_PAST_DUE_AMT')
plt.show()

# Plot distribution of mean_RECURRING_CHRG_AMT
sns.histplot(data=pdf, x='mean_RECURRING_CHRG_AMT')
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Demographics

# COMMAND ----------

customer_demographics_final = get_customer_demographics(customer_sample_keys, customer)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Counts

# COMMAND ----------

print(customer_demographics_final.count())
print(customer_demographics_final.select('CUSTOMER_KEY','SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Nulls

# COMMAND ----------

features_list = ["OCCUPATION_CODE_DESC", "REGION",]

null_counts = customer_demographics_final.select([psf.sum(psf.col(c).isNull().cast("int")).alias(c) for c in features_list])

null_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### View Distributions

# COMMAND ----------

# Plot distribution of OCCUPATION_CODE_DESC
sns.countplot(data=customer_demographics_final.toPandas(), x='OCCUPATION_CODE_DESC')
plt.xticks(rotation=90)
plt.show()

# Plot distribution of REGION
sns.countplot(data=customer_demographics_final.toPandas(), x='REGION')
plt.xticks(rotation=90)
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Ported In From

# COMMAND ----------

customer_ported_in_from_final = get_customer_ported_in_from(customer_sample_w_churn_flag, port_in_request)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Counts

# COMMAND ----------

print(customer_ported_in_from_final.count())
print(customer_ported_in_from_final.select('CUSTOMER_KEY','SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Nulls

# COMMAND ----------

features_list = ["portin_flag"]

null_counts = customer_ported_in_from_final.select([psf.sum(psf.col(c).isNull().cast("int")).alias(c) for c in features_list])

null_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### View Distributions

# COMMAND ----------

# Plot distribution of portin_flag
sns.countplot(data=customer_ported_in_from_final.toPandas(), x='portin_flag')
plt.xticks(rotation=90)
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Allocation Usage

# COMMAND ----------

customer_usage = spark.read.table(schema_path + "customer_usage" + "_train")
customer_contract_details = spark.read.table(schema_path + "customer_contract_details" + "_train")
customer_allocation_usage_final = get_customer_allocation_usage(customer_usage, customer_sample_keys, customer_contract_details)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Counts

# COMMAND ----------

print(customer_allocation_usage_final.count())
print(customer_allocation_usage_final.select('CUSTOMER_KEY','SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Nulls

# COMMAND ----------

features_list = ['DATA_AYCE_IND',
 'VOICE_AYCE_IND',
 'voice_usage_min',
 'DATA_USAGE_GB',
 'data_usage_perc',
 'voice_usage_perc',
 'mbs_alloc_50',
 'mbs_alloc_75',
 'mbs_alloc_90',
 'mbs_alloc_all',
 'voi_alloc_50',
 'voi_alloc_75',
 'voi_alloc_90',
 'voi_alloc_all']

null_counts = customer_allocation_usage_final.select([psf.sum(psf.col(c).isNull().cast("int")).alias(c) for c in features_list])

null_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC * some nulls resulting from no usage - can be filled depending on column

# COMMAND ----------

# MAGIC %md
# MAGIC #### View Distributions

# COMMAND ----------

# Plot distribution of data_usage_perc
sns.histplot(data=customer_allocation_usage_final.filter(psf.col('data_usage_perc')<=500).toPandas(), x='data_usage_perc')
plt.show()

# Plot distribution of voice_usage_perc
sns.histplot(data=customer_allocation_usage_final.filter(psf.col('voice_usage_perc')<=500).toPandas(), x='voice_usage_perc')
plt.show()


# COMMAND ----------

print(customer_allocation_usage_final.filter(psf.col('voice_usage_perc')>500).count())
print(customer_allocation_usage_final.filter(psf.col('data_usage_perc')>500).count())

# COMMAND ----------

# MAGIC %md
# MAGIC * some outlier data usage - but assuming this is legitimate usage

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Interactions

# COMMAND ----------

customer_interactions_final = get_customer_interactions(customer_sample_w_churn_flag, subs_history_filter, interactions_v)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Counts

# COMMAND ----------

print(customer_interactions_final.count())
print(customer_interactions_final.select('CUSTOMER_KEY','SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Nulls

# COMMAND ----------

features_list = ['int_want_cancel', 'int_want_upgrade', 'int_new_ph_con', 'int_bill_enq', 'int_refund_enq', 'int_tech_enq', 'int_make_payment', 'int_network', 'int_tariff_enq', 'int_offers_enq', 'int_want_pac', 'int_want_dat_addon', 'int_comp_better_offer', 'int_want_better_deal', 'outcome_case_raised', 'outcome_pac_given', 'outcome_cons_offer', 'WTC_calls', 'int_total']

null_counts = customer_interactions_final.select([psf.sum(psf.col(c).isNull().cast("int")).alias(c) for c in features_list])

null_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### View Distributions

# COMMAND ----------

# Plot distribution of int_total
sns.histplot(data=customer_interactions_final.toPandas(), x='int_total')
plt.show()

# Plot distribution of WTC_calls
sns.histplot(data=customer_interactions_final.toPandas(), x='WTC_calls')
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Complaints

# COMMAND ----------

customer_complaints_final = get_customer_complaints(customer_sample_w_churn_flag, complaints)
customer_complaints_final = spark.read.table(schema_path + "customer_complaints" + "_train") 

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Counts

# COMMAND ----------

print(customer_complaints_final.drop_duplicates().count())
print(customer_complaints_final.drop_duplicates().select('CUSTOMER_KEY', 'SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Nulls

# COMMAND ----------

features_list = ['Total_complaints', 'Billing_complaints', 'Network_complaints', 'Service_complaints', 'Device_complaints']

null_counts = customer_complaints_final.select([psf.sum(psf.col(c).isNull().cast("int")).alias(c) for c in features_list])

null_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC * Nulls - fill with zero

# COMMAND ----------

# MAGIC %md
# MAGIC #### View Distributions

# COMMAND ----------

# Plot distribution of Total_complaints
sns.histplot(data=customer_complaints_final.fillna({'Total_complaints':0}).toPandas(), x='Total_complaints')
plt.show()

# Plot distribution of Billing_complaints
sns.histplot(data=customer_complaints_final.fillna({'Billing_complaints':0}).toPandas(), x='Billing_complaints')
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Acquisition Channel

# COMMAND ----------

customer_acquisition_channel_final = get_customer_acquisition_channel(customer_sample_w_churn_flag, dim_subscriber_key_t)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Counts

# COMMAND ----------

print(customer_acquisition_channel_final.count())
print(customer_acquisition_channel_final.select('CUSTOMER_KEY', 'SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Nulls

# COMMAND ----------

features_list = ['CHANNEL_ACQ', 'CHANNEL_ACQ_GROUP']

null_counts = customer_acquisition_channel_final.select([psf.sum(psf.col(c).isNull().cast("int")).alias(c) for c in features_list])

null_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### View Distributions

# COMMAND ----------

# Plot distribution of CHANNEL_ACQ
sns.countplot(data=customer_acquisition_channel_final.toPandas(), x='CHANNEL_ACQ')
plt.xticks(rotation=90)
plt.show()

# Plot distribution of CHANNEL_ACQ_GROUP
sns.countplot(data=customer_acquisition_channel_final.toPandas(), x='CHANNEL_ACQ_GROUP')
plt.xticks(rotation=90)
plt.show()