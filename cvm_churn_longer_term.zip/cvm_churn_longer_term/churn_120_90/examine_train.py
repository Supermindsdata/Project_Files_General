# Databricks notebook source
# MAGIC %run ./data_import

# COMMAND ----------

data_dict = get_data_dict()

# COMMAND ----------

training_data_location = "hive_metastore.cvm_churn_120_90.training_data"
train_df = spark.sql("SELECT * FROM {} WHERE set='train' AND LOB='Voice_CHS'".format(training_data_location))

train_df.display()

# COMMAND ----------

subscriber_history = data_dict['subscriber_history']

# COMMAND ----------

# Filter subscriber_history for specific customer and subscription keys
filtered_subscriber_history = subscriber_history.filter((subscriber_history.CUSTOMER_KEY == '923056199') & (subscriber_history.SUBSCRIBER_KEY == '1093429'))
filtered_subscriber_history.select('COMMITMENT_END_DATE').display()