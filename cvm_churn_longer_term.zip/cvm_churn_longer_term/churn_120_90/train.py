# Databricks notebook source
import mlflow
import pyspark.sql.functions as psf
from pyspark.sql.types import DoubleType
from pyspark.ml.feature import (
    StringIndexer,
    OneHotEncoder,
    Imputer,
    VectorAssembler,
    StandardScaler,
)
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from pyspark.ml.classification import GBTClassifier
from pyspark.ml import Pipeline


def balanced_sample(df, column_name):
    """
    Return a balanced sample DataFrame based on a binary column.

    Parameters:
    - df: Input PySpark DataFrame.
    - column_name: Name of the binary column.

    Returns:
    - A balanced sample DataFrame.
    """

    # Split the dataframe based on the binary column values
    df_positive = df.filter(df[column_name] == 1)
    df_negative = df.filter(df[column_name] == 0)

    # Get the minimum count between positive and negative classes
    min_count = min(df_positive.count(), df_negative.count())

    # Sample from each dataframe
    sampled_positive = df_positive.sample(
        withReplacement=False, fraction=min_count / df_positive.count(), seed=42
    ).limit(min_count)
    sampled_negative = df_negative.sample(
        withReplacement=False, fraction=min_count / df_negative.count(), seed=42
    ).limit(min_count)

    # Return the union of the two sampled dataframes
    return sampled_positive.union(sampled_negative)


def compute_metrics(predictions):
    """
    Computes precision, recall, and F1 score based on the predictions DataFrame which contains actual and predicted churn flags.

    Parameters:
    - predictions (DataFrame): A DataFrame containing the actual churn flags and predicted churn flags for customers.

    Returns:
    - tuple: A tuple containing the precision, recall, and F1 score as floats.
    """

    TP = predictions.filter(
        (predictions.prediction == 1) & (predictions.churn_flag == 1)
    ).count()
    FP = predictions.filter(
        (predictions.prediction == 1) & (predictions.churn_flag == 0)
    ).count()
    FN = predictions.filter(
        (predictions.prediction == 0) & (predictions.churn_flag == 1)
    ).count()

    precision = TP / (TP + FP) if (TP + FP) != 0 else 0
    recall = TP / (TP + FN) if (TP + FN) != 0 else 0
    f1 = (
        2 * (precision * recall) / (precision + recall)
        if (precision + recall) != 0
        else 0
    )

    return precision, recall, f1
