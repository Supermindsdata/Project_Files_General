# Databricks notebook source
import pyspark.sql.functions as psf
import seaborn as sns
import matplotlib.pyplot as plt

# COMMAND ----------

numerical_features = [
"three_tenure",
"voice_time",
"AMOUNT_OF_DATA",
"ONNET_TIME",
"FAH_ROAMING_DATA",
"OUT_OF_BUNDLE_TIME",
"COUNT_OF_VOICE_CALLS",
"COUNT_OF_ON_NET_CALLS",
"AVE_UNIQ_NUMS_DIALLED",
"MEAN_VOICE",
"STDDEV_VOICE",
"MEAN_DATA",
"STDDEV_DATA",
"accs_opened",
"acc_acq_rec",
"accs_closed",
"accs_upgrade",
"other_acc_FTG",
"other_acc_ret_window",
"other_acc_inlife",
"MRC_PCT_DISCOUNT_AMORTISED",
"MRC_TARIFF",
"MRC_PRICE_MODIFIER",
"MRC_INSURANCE",
"MRC_OTHER",
"MRC_DISCOUNT",
"DISCOUNT_PERCENTAGE",
"MRC_PCT_DISCOUNT",
"MRC_FIXED_DISCOUNT",
"mean_BILL_PREV_BALANCE_AMT",
"std_BILL_PREV_BALANCE_AMT",
"mean_BILL_PYM_RECEIVED_AMT",
"std_BILL_PYM_RECEIVED_AMT",
"mean_PAST_DUE_AMT",
"std_PAST_DUE_AMT",
"mean_LATE_PYM_BASE_AMT",
"std_LATE_PYM_BASE_AMT",
"mean_LATE_PYM_CHRG_AMT",
"std_LATE_PYM_CHRG_AMT",
"mean_CURR_DISCOUNT_AMT",
"std_CURR_DISCOUNT_AMT",
"mean_TOTAL_DUE_AMT",
"std_TOTAL_DUE_AMT",
"mean_OVERDUE_AMT",
"std_OVERDUE_AMT",
"mean_RECURRING_CHRG_AMT",
"std_RECURRING_CHRG_AMT",
"mean_LOCAL_USAGE_CHRG_AMT",
"std_LOCAL_USAGE_CHRG_AMT",
"mean_ROAMING_USAGE_CHRG_AMT",
"std_ROAMING_USAGE_CHRG_AMT",
"mean_DATA_USAGE_CHRG_AMT",
"std_DATA_USAGE_CHRG_AMT",
'int_want_cancel',
'int_want_upgrade',
'int_new_ph_con',
'int_bill_enq',
'int_refund_enq',
'int_tech_enq',
'int_make_payment',
'int_network',
'int_tariff_enq',
'int_offers_enq',
'int_want_pac',
'int_want_dat_addon',
'int_comp_better_offer',
'int_want_better_deal',
'outcome_case_raised',
'outcome_pac_given',
'outcome_cons_offer',
'WTC_calls',
'int_total',
'Total_complaints',
'Billing_complaints',
'Network_complaints',
'Service_complaints',
'Device_complaints'
]

# COMMAND ----------

training_data_location = "hive_metastore.cvm_churn_120_90.training_data"
train_df = spark.sql("SELECT * FROM {} WHERE set='train' AND LOB='Voice_CHS'".format(training_data_location))
test_df = spark.sql("SELECT * FROM {} WHERE set='test' AND LOB='Voice_CHS'".format(training_data_location))

# COMMAND ----------

train_df.select([psf.count(psf.when(psf.col(feature).isNull(), feature)).alias(feature + "_na_count") for feature in numerical_features]).display()

# COMMAND ----------

train_df.filter(psf.col('three_tenure').isNull()).display()

# COMMAND ----------

# MAGIC %run ./data_import

# COMMAND ----------

# MAGIC %run ./featurization

# COMMAND ----------

data_dict = get_data_dict()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get Data

# COMMAND ----------

subscriber = data_dict["subscriber"]
subscriber_history = data_dict["subscriber_history"]
usage_v = data_dict["usage_v"]
eng_subscriber_history = data_dict["eng_subscriber_history"]
bill_customer = data_dict["bill_customer"]
customer = data_dict["customer"]
port_in_request = data_dict["port_in_request"]
interactions_v = data_dict["interactions_v"]
complaints = data_dict["complaints"]

# COMMAND ----------

schema_path = "hive_metastore.cvm_churn_120_90."
customer_sample_w_churn_flag = spark.read.table(schema_path + "customer_sample_w_churn_flag" + "_train")
customer_sample_keys = spark.read.table(schema_path + "customer_sample_keys" + "_train")
subs_history_filter = spark.read.table(schema_path + "subs_history_filter" + "train")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customer Metdata

# COMMAND ----------


customer_metadata_final = get_customer_metadata(subscriber, subscriber_history, customer_sample_w_churn_flag)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Counts

# COMMAND ----------

print(customer_metadata_final.count())
print(customer_metadata_final.select('CUSTOMER_KEY','SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Nulls

# COMMAND ----------

features_list = ["age", "three_tenure", "first_contract"]

null_counts = customer_metadata_final.select([psf.sum(psf.col(c).isNull().cast("int")).alias(c) for c in features_list])

null_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC * SUBSCRIBER_BIRTH_DATE is sometimes NULL or 1900 so age is null - can impute

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Distributions

# COMMAND ----------

sns.histplot(data=customer_metadata_final.toPandas(), x="age")
plt.show()

# COMMAND ----------

sns.histplot(data=customer_metadata_final.toPandas(), x="three_tenure")
plt.show()

# COMMAND ----------

sns.countplot(data=customer_metadata_final.toPandas(), x="first_contract")
plt.show()

# COMMAND ----------

customer_metadata_final.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Contract Details

# COMMAND ----------

customer_contract_details_final = get_contract_details(subs_history_filter, customer_sample_w_churn_flag)

# COMMAND ----------

customer_contract_details_final.columns

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Counts

# COMMAND ----------

print(customer_contract_details_final.count())
print(customer_contract_details_final.select('CUSTOMER_KEY','SUBSCRIBER_KEY').distinct().count())

# COMMAND ----------

# MAGIC %md
# MAGIC #### Check Nulls

# COMMAND ----------

features_list = ['LOB',
 'COMMITMENT_DURATION',
 'GBYTE_ALLOWANCE',
 'GBYTE_ALLOWANCE_GROUP',
 'MINUTES_ALLOWANCE',
 'MINUTES_ALLOWANCE_GROUP',
 'PLAN_TARIFF',
 'PLAN_TARIFF_GROUP',
 'AMORTISED_DEVICE_COST',
 'MRC_DEAL_WITHOUT_ADDONS_EXVAT',
 'NMRC_BLENDED_DEAL',
 'MRC_BLENDED_DEAL',
 'MRC_PCT_DISCOUNT_AMORTISED',
 'MRC_TARIFF',
 'MRC_PRICE_MODIFIER',
 'MRC_INSURANCE',
 'MRC_OTHER',
 'MRC_DISCOUNT',
 'DISCOUNT_PERCENTAGE',
 'MRC_PCT_DISCOUNT',
 'MRC_FIXED_DISCOUNT',
 'DEVICE_BRAND',
 'DEVICE_MODEL',
 'DEVICE_TYPE',
 'RRPPRICE_INC_VAT',
 'SIM_TYPE']

null_counts = customer_contract_details_final.select([psf.sum(psf.col(c).isNull().cast("int")).alias(c) for c in features_list])

null_counts.display()

# COMMAND ----------

# MAGIC %md
# MAGIC #### View Distributions

# COMMAND ----------

# Plot distribution of GBYTE_ALLOWANCE_GROUP
sns.countplot(data=customer_contract_details_final.toPandas(), x='GBYTE_ALLOWANCE_GROUP')

# COMMAND ----------

# Plot distribution of MINUTES_ALLOWANCE_GROUP
sns.countplot(data=customer_contract_details_final.toPandas(), x='MINUTES_ALLOWANCE_GROUP')

# COMMAND ----------

customer_contract_details_final.groupby('MINUTES_ALLOWANCE_GROUP').count().display()

# COMMAND ----------

# Plot distribution of PLAN_TARIFF_GROUP
sns.countplot(data=customer_contract_details_final.toPandas(), x='PLAN_TARIFF_GROUP')
plt.xticks(rotation=90)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Multiple Accounts

# COMMAND ----------

customer_multiple_accounts_final = get_customer_multiple_accounts(
    customer_sample_keys, customer_sample_w_churn_flag, eng_subscriber_history
)