# Databricks notebook source
# MAGIC %run ./data_import

# COMMAND ----------

# MAGIC %run ./featurization

# COMMAND ----------

schema_location = "hive_metastore.cvm_churn_120_90_rw"
spark.sql("CREATE SCHEMA IF NOT EXISTS {}".format(schema_location))

# COMMAND ----------

data_dict = get_data_dict()
feature_data =  get_features(spark, data_dict,schema_location, training=True,subscriber_window_start='2024-01-01',subscriber_window_end='2024-02-01',days_before_end_min=90, days_before_end_max=120)

# COMMAND ----------

feature_data.write.mode("overwrite").saveAsTable("hive_metastore.cvm_churn_120_90_rw.training_data")

# COMMAND ----------

customer_sample_w_churn_flag = spark.read.table(schema_location + ".customer_sample_w_churn_flag" + "_train")
customer_sample_keys = spark.read.table(schema_location + ".customer_sample_keys" + "_train")
suffix = "train"
eng_subscriber_history = data_dict['eng_subscriber_history']

customer_multiple_accounts = get_customer_multiple_accounts(customer_sample_keys, customer_sample_w_churn_flag, eng_subscriber_history)
customer_multiple_accounts = write_read(spark, customer_multiple_accounts, f"{schema_location}.customer_multiple_accounts_{suffix}")

# COMMAND ----------

subscriber = data_dict['subscriber']
subscriber_history = data_dict['subscriber_history']

customer_metadata = get_customer_metadata(subscriber, subscriber_history, customer_sample_w_churn_flag)
customer_metadata = write_read(spark, customer_metadata, f"{schema_location}.customer_metadata_{suffix}")

# COMMAND ----------

schema_path = "hive_metastore.cvm_churn_120_90_rw."
customer_sample_w_churn_flag = spark.read.table(schema_path + "customer_sample_w_churn_flag" + "_train")
customer_metadata = spark.read.table(schema_path + "customer_metadata" + "_train")
customer_contract_details = spark.read.table(schema_path + "customer_contract_details" + "_train")
customer_usage = spark.read.table(schema_path + "customer_usage" + "_train")
customer_billing = spark.read.table(schema_path + "customer_billing" + "_train")
customer_ported_in_from = spark.read.table(schema_path + "customer_ported_in_from" + "_train")
customer_multiple_accounts = spark.read.table(schema_path + "customer_multiple_accounts" + "_train")
customer_demographics = spark.read.table(schema_path + "customer_demographics" + "_train")
customer_allocation_usage = spark.read.table(schema_path + "customer_allocation_usage" + "_train")
customer_interactions = spark.read.table(schema_path + "customer_interactions" + "_train")
customer_complaints = spark.read.table(schema_path + "customer_complaints" + "_train")
customer_acquisition_channel = spark.read.table(schema_path + "customer_acquisition_channel" + "_train")

all_customer_data = (
    customer_sample_w_churn_flag.join(
        customer_metadata,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_contract_details,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_usage,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_billing,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_ported_in_from,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_multiple_accounts,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_demographics,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_allocation_usage,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_interactions,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_complaints,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_acquisition_channel,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .drop(
        "COMMITMENT_END_DATE",
        "DISCONNECTION_DATE",
        "COMMITMENT_START_DATE",
    )
    .drop_duplicates()
)
    
all_customer_data.write.mode("overwrite").saveAsTable("hive_metastore.cvm_churn_120_90_rw.training_data")

# COMMAND ----------

schema_path = "hive_metastore.cvm_churn_120_90."
customer_sample_w_churn_flag_120_90 = spark.read.table(schema_path + "customer_sample_w_churn_flag" + "_train")

schema_path = "hive_metastore.cvm_churn_90_60_1."
customer_sample_w_churn_flag_90_60 = spark.read.table(schema_path + "customer_sample_w_churn_flag" + "_train")

# COMMAND ----------

print(customer_sample_w_churn_flag_120_90.count())
print(customer_sample_w_churn_flag_90_60.count())

# COMMAND ----------

