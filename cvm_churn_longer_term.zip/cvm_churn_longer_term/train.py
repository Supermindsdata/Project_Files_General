# Databricks notebook source
import mlflow
import pyspark.sql.functions as psf
from pyspark.sql.types import DoubleType
from pyspark.ml.feature import (
    StringIndexer,
    OneHotEncoder,
    Imputer,
    VectorAssembler,
    StandardScaler,
)
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from pyspark.ml.classification import GBTClassifier
from pyspark.ml import Pipeline


def balanced_sample(df, column_name):
    """
    Return a balanced sample DataFrame based on a binary column.

    Parameters:
    - df: Input PySpark DataFrame.
    - column_name: Name of the binary column.

    Returns:
    - A balanced sample DataFrame.
    """

    # Split the dataframe based on the binary column values
    df_positive = df.filter(df[column_name] == 1)
    df_negative = df.filter(df[column_name] == 0)

    # Get the minimum count between positive and negative classes
    min_count = min(df_positive.count(), df_negative.count())

    # Sample from each dataframe
    sampled_positive = df_positive.sample(
        withReplacement=False, fraction=min_count / df_positive.count(), seed=42
    ).limit(min_count)
    sampled_negative = df_negative.sample(
        withReplacement=False, fraction=min_count / df_negative.count(), seed=42
    ).limit(min_count)

    # Return the union of the two sampled dataframes
    return sampled_positive.union(sampled_negative)


def compute_metrics(predictions):
    """
    Computes precision, recall, and F1 score based on the predictions DataFrame which contains actual and predicted churn flags.

    Parameters:
    - predictions (DataFrame): A DataFrame containing the actual churn flags and predicted churn flags for customers.

    Returns:
    - tuple: A tuple containing the precision, recall, and F1 score as floats.
    """

    TP = predictions.filter(
        (predictions.prediction == 1) & (predictions.churn_flag == 1)
    ).count()
    FP = predictions.filter(
        (predictions.prediction == 1) & (predictions.churn_flag == 0)
    ).count()
    FN = predictions.filter(
        (predictions.prediction == 0) & (predictions.churn_flag == 1)
    ).count()

    precision = TP / (TP + FP) if (TP + FP) != 0 else 0
    recall = TP / (TP + FN) if (TP + FN) != 0 else 0
    f1 = (
        2 * (precision * recall) / (precision + recall)
        if (precision + recall) != 0
        else 0
    )

    return precision, recall, f1


def training_pipeline(
    training_sdf,
    product,
    features_to_include,
    data_types,
    params,
    exp_id=None,
    model_name=None,
):

    BOOL_COLS = [i for i in features_to_include if data_types[i] == "Boolean"]

    NUMERICAL_COLS = [i for i in features_to_include if data_types[i] == "Numerical"]

    CATEGORICAL_COLS = [
        i for i in features_to_include if data_types[i] == "Categorical"
    ]

    for col_name in BOOL_COLS:
        training_sdf = training_sdf.withColumn(
            col_name, psf.col(col_name).cast("string")
        )

    for col_name in NUMERICAL_COLS:
        training_sdf = training_sdf.withColumn(
            col_name, psf.col(col_name).cast(DoubleType())
        )

    for col_name in CATEGORICAL_COLS:
        training_sdf = training_sdf.withColumn(
            col_name,
            psf.when(psf.col(col_name) == "", None).otherwise(psf.col(col_name)),
        )

    bool_indexers = [
        StringIndexer(
            inputCol=col_name, outputCol=col_name + "_indexed", handleInvalid="keep"
        )
        for col_name in BOOL_COLS
    ]
    bool_encoders = [
        OneHotEncoder(
            inputCol=col_name + "_indexed",
            outputCol=col_name + "_encoded",
            dropLast=True,
            handleInvalid="keep",
        )
        for col_name in BOOL_COLS
    ]

    numerical_imputer = Imputer(
        inputCols=NUMERICAL_COLS,
        outputCols=[col_name + "_imputed" for col_name in NUMERICAL_COLS],
    )
    numerical_assemblers = [
        VectorAssembler(inputCols=[col_name + "_imputed"], outputCol=col_name + "_vec")
        for col_name in NUMERICAL_COLS
    ]
    numerical_scalers = [
        StandardScaler(inputCol=col_name + "_vec", outputCol=col_name + "_scaled")
        for col_name in NUMERICAL_COLS
    ]

    categorical_indexers = [
        StringIndexer(
            inputCol=col_name, outputCol=col_name + "_indexed", handleInvalid="keep"
        )
        for col_name in CATEGORICAL_COLS
    ]
    categorical_encoders = [
        OneHotEncoder(
            inputCol=col_name + "_indexed",
            outputCol=col_name + "_encoded",
            dropLast=True,
            handleInvalid="keep",
        )
        for col_name in CATEGORICAL_COLS
    ]

    all_processed_cols = [
        col_name + "_encoded" for col_name in BOOL_COLS + CATEGORICAL_COLS
    ] + [col_name + "_scaled" for col_name in NUMERICAL_COLS]
    assembler = VectorAssembler(inputCols=all_processed_cols, outputCol="features")

    (train_df, test_df) = training_sdf.randomSplit([0.7, 0.3], seed=42)

    evaluator = BinaryClassificationEvaluator(labelCol="churn_flag")

    gbt = GBTClassifier(featuresCol="features", labelCol="churn_flag")

    gbt_paramGrid = ParamGridBuilder()

    for param, values in params.items():
        gbt_paramGrid = gbt_paramGrid.addGrid(getattr(gbt, param), values)

    all_stages = (
        bool_indexers
        + bool_encoders
        + categorical_indexers
        + categorical_encoders
        + [numerical_imputer]
        + numerical_assemblers
        + numerical_scalers
        + [assembler]
        + [gbt]
    )

    gbt_transformation_pipeline = Pipeline(stages=all_stages)

    gbt_crossval = CrossValidator(
        estimator=gbt_transformation_pipeline,
        estimatorParamMaps=gbt_paramGrid,
        evaluator=evaluator,
        numFolds=3,
    )

    balanced_train_sdf = balanced_sample(train_df, "churn_flag")
    balanced_test_sdf = balanced_sample(test_df, "churn_flag")

    with mlflow.start_run(experiment_id=exp_id) as run:

        classifier_type = type(gbt_crossval.getEstimator().getStages()[-1]).__name__
        print(f"Training {classifier_type}...")

        model = gbt_crossval.fit(balanced_train_sdf)
        predictions_balanced = model.transform(balanced_test_sdf)

        bestModel = model.bestModel

        sample_input = balanced_train_sdf.limit(5)
        signature = mlflow.models.infer_signature(sample_input)

        mlflow.spark.log_model(
            bestModel,
            artifact_path="model",
            registered_model_name=model_name,
            signature=signature,
        )

        for param, value in bestModel.stages[-1].extractParamMap().items():
            print(f"{param.name}: {value}")

        # Compute AUC
        test_auc = evaluator.evaluate(predictions_balanced)
        print(f"Test AUC for {classifier_type} {classifier_type}: {test_auc}")
        print("----------------------------")

        # Compute precision, recall, and F1-score
        precision, recall, f1 = compute_metrics(predictions_balanced)

        mlflow.log_metrics(
            {"ROC_AUC": test_auc, "precision": precision, "recall": recall, "f1": f1}
        )

        run = mlflow.active_run()
        mlflow.set_tag("candidate", "true")

        print("Training completed!")
        print("Model and artifacts saved to active run_id: {}".format(run.info.run_id))
