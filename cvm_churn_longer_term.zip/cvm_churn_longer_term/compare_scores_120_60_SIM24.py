# Databricks notebook source
import pyspark.sql.functions as psf
from pyspark.sql.window import Window

# COMMAND ----------

test_sdf_90_60 = spark.read.load('/dbfs/FileStore/shared_uploads/jsanders@corpuk.net/cvm/test_sdf_90_60_SIM24')
train_sdf_90_60 = spark.read.load('/dbfs/FileStore/shared_uploads/jsanders@corpuk.net/cvm/train_sdf_90_60_SIM24')

test_sdf_120_90 = spark.read.load('/dbfs/FileStore/shared_uploads/jsanders@corpuk.net/cvm/test_sdf_120_90_SIM24')
train_sdf_120_90 = spark.read.load('/dbfs/FileStore/shared_uploads/jsanders@corpuk.net/cvm/train_sdf_120_90_SIM24')

# COMMAND ----------

sdf = (
    train_sdf_120_90
    .select(
        'CUSTOMER_KEY'
        ,'SUBSCRIBER_KEY'
        ,'pred'
        ,'prob'
    )
    .withColumnRenamed('pred','pred_120_90')
    .withColumnRenamed('prob','prob_120_90')
    .join(
        (train_sdf_90_60
            .select(
            'CUSTOMER_KEY'
            ,'SUBSCRIBER_KEY'
            ,'pred'
            ,'prob'
        )
        .withColumnRenamed('pred','pred_90_60')
        .withColumnRenamed('prob','prob_90_60')),
        on=['CUSTOMER_KEY','SUBSCRIBER_KEY'],
        how="inner")
)

sdf = sdf.withColumn('prob_bucket_120_90', psf.floor(sdf['prob_120_90'] * 10) / 10)
sdf = sdf.withColumn('prob_bucket_90_60', psf.floor(sdf['prob_90_60'] * 10) / 10)

# Determine the bucket movement
sdf = sdf.withColumn('bucket_movement',
                     psf.when(sdf['prob_bucket_120_90'] == sdf['prob_bucket_90_60'], 'same')
                     .when(sdf['prob_bucket_120_90'] > sdf['prob_bucket_90_60'], 'lower')
                     .otherwise('higher'))

# Calculate the percentage for each bucket movement using a subquery
subquery = sdf.select(
    'prob_bucket_120_90',
    'bucket_movement',
    psf.count('*').over(Window.partitionBy('prob_bucket_120_90', 'bucket_movement')).alias('count')
)

result = subquery.groupBy('prob_bucket_120_90').agg(
    psf.sum(psf.when(subquery['bucket_movement'] == 'same', subquery['count']).otherwise(0)).alias('same_count'),
    psf.sum(psf.when(subquery['bucket_movement'] == 'lower', subquery['count']).otherwise(0)).alias('lower_count'),
    psf.sum(psf.when(subquery['bucket_movement'] == 'higher', subquery['count']).otherwise(0)).alias('higher_count'),
    psf.sum('count').alias('total_count')
).withColumn('same_percentage', psf.col('same_count') / psf.col('total_count') * 100) \
 .withColumn('lower_percentage', psf.col('lower_count') / psf.col('total_count') * 100) \
 .withColumn('higher_percentage', psf.col('higher_count') / psf.col('total_count') * 100) \
 .select('prob_bucket_120_90', 'same_percentage', 'lower_percentage', 'higher_percentage') \
 .orderBy('prob_bucket_120_90')

result.display()

# COMMAND ----------

sdf.groupby('prob_bucket_120_90','bucket_movement').count().display()

# COMMAND ----------

sdf_agg = sdf.groupby('prob_bucket_120_90','bucket_movement').count()
sdf_agg_2 = sdf.groupby('prob_bucket_120_90').count()
sdf_agg.join(sdf_agg_2,on='prob_bucket_120_90',how='inner').display()

# COMMAND ----------

sdf.groupby('pred_120_90','pred_90_60').count().display()

# COMMAND ----------

sdf = sdf.withColumn('movement',psf.col('prob_120_90')-psf.col('prob_90_60'))
sdf = sdf.withColumn('movement_bucket', psf.floor(sdf['movement'] * 10) / 10)
sdf.groupby('movement_bucket').count().display()