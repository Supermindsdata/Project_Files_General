# Databricks notebook source
import pyspark.sql.functions as psf
from pyspark.sql.window import Window
from pyspark.sql.types import IntegerType
import datetime
import os

GB_ALLOWANCE_LIST = ['AYCE', '30', '100', '12', '8', '4', '1']

PLAN_TARIFF_LIST = [
    "Unlimited Data Unlim Min",
    "AdvSIM Unlim Data ULD Min24M",
    "AdvSIM 8GB Data Unlim Min 24M",
    "Three Advance 100GB Unlim Min",
    "SIM 30GB Data Unlim Min 12M",
    "Adv SIM 12GB Data Unlim Min24M",
    "SIM Unlim Data ULD Min 12M",
    "SIMAdv 100GB Data Unlim Min12M",
    "30GB Data Unlimited Minutes",
    "Adv SIM 30GB Data Unlim Min24M",
    "AdvSIM 12GB Data Unlim Min 12M",
    "12GB Data Unlimited Minutes",
    "4GB Data Unlimited Minutes",
    "1GB Data Unlimited Minutes",
    "Adv SIM 1GB Data Unlim Min 24M",
    "Adv SIM 8GB Data Unlim Min 12M",
    "SIM 4GB Data Unlim Min 12M",
    "AdvSIM 4GB Data Unlim Min 24M",
    "Adv SIM 100GB Dat Unlim Min24M"
]

complaint_cat_cols = [
    'BILLING_COMPLAINT_MTHS_SINCE',
    'NETWORK_COMPLAINT_MTHS_SINCE',
    'SERVICE_COMPLAINT_MTHS_SINCE',
    'DEVICE_COMPLAINT_MTHS_SINCE',
    'MOST_RECENT_COMPLAINT_MTHS_SINCE'
]

def write_read(spark, sdf, table_path):
    """
    Writes a Spark DataFrame to a Hive table at the specified path and then reads it back.

    Parameters:
    - spark: The Spark Session
    - sdf (DataFrame): The Spark DataFrame to be written and read.
    - table_path (str): The Hive table path where the DataFrame is to be written.

    Returns:
    - DataFrame: The Spark DataFrame that has been read from the Hive table.
    Note:
    This function overwrites any existing data at the table_path.
    """

    sdf.write.mode("overwrite").saveAsTable(table_path)
    sdf = spark.read.table(table_path)

    return sdf


def get_year_month_lists(date_start, date_end, days_delta=30):
    """
    Generates lists of years and months between two dates, with an optional adjustment to the start date.
    The start date can be adjusted backwards by a specified number of days to include additional months.

    Parameters:
    - date_start (date): The start date for generating the year and month lists.
    - date_end (date): The end date for generating the year and month lists.
    - days_delta (int, optional): The number of days to adjust the start date backwards. Defaults to 30.

    Returns:
    - Tuple[List[int], List[int]]: A tuple containing two lists. The first list contains the unique years
      between the adjusted start date and the end date. The second list contains the unique months
      within those years.
    """

    adjusted_start_date = date_start - datetime.timedelta(days=days_delta)

    years = []
    months = []

    current_date = datetime.datetime.combine(adjusted_start_date, datetime.datetime.min.time())
    date_end_datetime = datetime.datetime.combine(date_end, datetime.datetime.min.time())

    while current_date <= date_end_datetime:
        years.append(current_date.year)
        months.append(current_date.month)

        next_month = current_date.month + 1
        next_year = current_date.year
        if next_month > 12:
            next_month = 1
            next_year += 1
        current_date = datetime.datetime(next_year, next_month, 1)

    years = list(set(years))
    months = list(set(months))

    return years, months

def fill_with_zero(df, columns):
    """
    Fill specified columns in a DataFrame with zeros.

    Parameters:
        df: DataFrame - The input DataFrame
        columns: list - A list of column names to fill with zero

    Returns:
        DataFrame - The DataFrame with specified columns filled with zero
    """
    fill_dict = {col: 0 for col in columns}
    return df.na.fill(fill_dict)


def categorize_complaints(df, col_name):
    """
    Categorize a column in a DataFrame based on the number of complaints.

    Parameters:
        df: DataFrame - The input DataFrame
        col_name: str - The name of the column to categorize

    Returns:
        DataFrame - The DataFrame with the categorized column
    """
    return df.withColumn(
        col_name,
        psf.when(psf.col(col_name) == 0, "0")
        .when((psf.col(col_name) > 0) & (psf.col(col_name) <= 3), "1-3")
        .when((psf.col(col_name) > 3) & (psf.col(col_name) <= 6), "3-6")
        .when((psf.col(col_name) > 6) & (psf.col(col_name) <= 12), "6-12")
        .when(psf.col(col_name) > 12, "12+")
        .when(psf.col(col_name).isNull(), "No complaint")
        .otherwise(psf.col(col_name))
    )

def get_subs_history_filter_training(
    subscriber_history, subscriber_window_start, subscriber_window_end
):
    """
    Filters the subscriber history DataFrame for training purposes.

    Args:
        subscriber_history (pyspark.sql.DataFrame): The DataFrame containing the subscriber history.
        subscriber_window_start (str): The start date of the commitment window in the format 'YYYY-MM-DD'.
        subscriber_window_end (str): The end date of the commitment window in the format 'YYYY-MM-DD'.

    Returns:
        pyspark.sql.DataFrame: The filtered DataFrame containing subscribers with the following criteria:
            - CUSTOMER_TYPE is 'B2C'
            - CUSTOMER_SUB_TYPE is 'Individual'
            - LOB is either 'Voice_SIMO' or 'Voice_CHS'
            - COMMITMENT_END_DATE is between subscriber_window_start and subscriber_window_end
    """
    subs_history_filter = (
        subscriber_history.filter(psf.col("CUSTOMER_TYPE") == "B2C")
        .filter(psf.col("CUSTOMER_SUB_TYPE") == "Individual")
        .filter(psf.col("LOB").isin("Voice_SIMO", "Voice_CHS"))
        .filter(psf.col("COMMITMENT_END_DATE") >= subscriber_window_start)
        .filter(psf.col("COMMITMENT_END_DATE") < subscriber_window_end)
    )

    return subs_history_filter


def get_subs_history_filter_inference(subscriber_history):
    """
    Filters the subscriber history DataFrame for inference purposes.

    Args:
        subscriber_history (pyspark.sql.DataFrame): The DataFrame containing the subscriber history.

    Returns:
        pyspark.sql.DataFrame: The filtered DataFrame containing subscribers with the following criteria:
            - CUSTOMER_TYPE is 'B2C'
            - CUSTOMER_SUB_TYPE is 'Individual'
            - LOB is either 'Voice_SIMO' or 'Voice_CHS'
            - COMMITMENT_END_DATE is between 30 and 60 days before the current date
            - DISCONNECTION_DATE is null
            - The DataFrame also contains a new column 'days_diff' calculated as the difference between the current date and COMMITMENT_END_DATE
            - The special date '3333-03-03T00:00:00Z' in DISCONNECTION_DATE is replaced with None
    """
    subs_history_filter = (
        subscriber_history.withColumn("model_date", psf.current_date())
        .withColumn(
            "DISCONNECTION_DATE",
            psf.when(
                psf.col("DISCONNECTION_DATE") == "3333-03-03T00:00:00Z", None
            ).otherwise(psf.col("DISCONNECTION_DATE")),
        )
        .withColumn(
            "days_diff",
            psf.datediff(psf.col("model_date"), psf.col("COMMITMENT_END_DATE")),
        )
        .filter(psf.col("CUSTOMER_TYPE") == "B2C")
        .filter(psf.col("CUSTOMER_SUB_TYPE") == "Individual")
        .filter(psf.col("LOB").isin("Voice_SIMO", "Voice_CHS"))
        .filter((psf.col("days_diff") < -30) & (psf.col("days_diff") >= -60))
        .filter(psf.col("DISCONNECTION_DATE").isNull())
    )

    return subs_history_filter

def get_customer_sample_training(
    subs_history_filter,
    days_before_end_min,
    days_before_end_max,
):
    """
    Filters and processes a customer sample from subscriber history based on specified criteria
    for training purposes, including churn flag calculation.

    Parameters:
    - subscriber_history (DataFrame): The dataset containing subscriber history.
    - subscriber_window_start (datetime): Start date of the subscriber window for filtering.
    - subscriber_window_end (datetime): End date of the subscriber window for filtering.
    - days_before_end_min (int): Minimum number of days before the commitment end date to consider.
    - days_before_end_max (int): Maximum number of days before the commitment end date to consider.

    Returns:
    - Tuple[DataFrame, DataFrame]: A tuple containing two DataFrames. The first DataFrame includes the
      customer sample with churn flags and other calculated fields. The second DataFrame contains just
      the customer and subscriber keys of the filtered sample.
    """

    contract_details = (
        subs_history_filter.select(
            "CUSTOMER_KEY",
            "SUBSCRIBER_KEY",
            "MSISDN",
            "COMMITMENT_START_DATE",
            "COMMITMENT_END_DATE",
            "GBYTE_ALLOWANCE",
            "MINUTES_ALLOWANCE",
            "PLAN_TARIFF",
            "AMORTISED_DEVICE_COST",
            "WHAT_CUSTOMER_PAYS_NET_VAT",
            "MRC_DEAL_WITHOUT_ADDONS_EXVAT",
            "NMRC_BLENDED_DEAL",
            "MRC_BLENDED_DEAL",
            "MRC_PCT_DISCOUNT_AMORTISED",
            "MRC_TARIFF",
            "MRC_PRICE_MODIFIER",
            "MRC_ADD_ONS",
            "MRC_INSURANCE",
            "MRC_OTHER",
            "MRC_DISCOUNT",
            "DISCOUNT_PERCENTAGE",
            "MRC_PCT_DISCOUNT",
            "MRC_FIXED_DISCOUNT",
            "DEVICE_BRAND",
            "DEVICE_MODEL",
            "DEVICE_TYPE",
            "RRPPRICE_INC_VAT",
            "SIM_TYPE",
        )
        .distinct()
        .groupby(["CUSTOMER_KEY", "SUBSCRIBER_KEY"])
        .count()
    )

    single_contract_subs = contract_details.filter(psf.col("count") == 1)

    customer_sample = (
        subs_history_filter.join(
            single_contract_subs, on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"], how="inner"
        )
        .select(
            "CUSTOMER_KEY",
            "SUBSCRIBER_KEY",
            "COMMITMENT_START_DATE",
            "COMMITMENT_END_DATE",
            "DISCONNECTION_DATE",
        )
        .distinct()
    )

    customer_sample_w_churn_flag = (
        customer_sample.withColumn(
            "DISCONNECTION_DATE",
            psf.when(
                psf.col("DISCONNECTION_DATE") == "3333-03-03T00:00:00Z", None
            ).otherwise(psf.col("DISCONNECTION_DATE")),
        )
        .withColumn(
            "model_date",
            psf.date_sub(
                psf.col("COMMITMENT_END_DATE"),
                (
                    psf.floor(
                        psf.rand(seed=42)
                        * (days_before_end_max - days_before_end_min + 1)
                    )
                    + days_before_end_min
                ).cast("int"),
            ),
        )
        .withColumn(
            "churn_flag",
            psf.when(
                (psf.col("DISCONNECTION_DATE") >= psf.col("model_date"))
                & (
                    psf.col("DISCONNECTION_DATE")
                    <= psf.date_add(psf.col("COMMITMENT_END_DATE"), 30)
                ),
                1,
            ).otherwise(0),
        )
        .withColumn(
            "churn_before_flag",
            psf.when(
                psf.col("DISCONNECTION_DATE") <= psf.col("model_date"), 1
            ).otherwise(0),
        )
        .withColumn(
            "days_remaining",
            -1 * psf.datediff(psf.col("model_date"), psf.col("COMMITMENT_END_DATE")),
        )
        .withColumn("30d_start", psf.date_add(psf.col("model_date"), -30))
        .withColumn("90d_start", psf.date_add(psf.col("model_date"), -90))
        .filter(psf.col("COMMITMENT_START_DATE") <= psf.col("model_date"))
        .filter(psf.col("churn_before_flag") == 0)
        .drop("churn_before_flag")
    )

    single_end_customers = (
        customer_sample_w_churn_flag.groupby("CUSTOMER_KEY", "SUBSCRIBER_KEY")
        .count()
        .filter(psf.col("count") <= 1)
    )

    customer_sample_w_churn_flag = (
        customer_sample_w_churn_flag.join(
            single_end_customers, on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"], how="inner"
        )
        .drop("count")
        .withColumn("set", psf.when(psf.rand() < 0.7, "train").otherwise("test"))
        .distinct()
    )

    customer_sample_keys = (
        customer_sample_w_churn_flag.select(
            "CUSTOMER_KEY", "SUBSCRIBER_KEY"
        )
        .distinct()
    )

    return customer_sample_w_churn_flag, customer_sample_keys


def get_customer_sample_inference(subs_history_filter):
    """
    Filters and processes a customer sample from subscriber history for inference, focusing on subscribers
    within a specific range of days before their commitment end date.

    Parameters:
    - subscriber_history (DataFrame): The dataset containing subscriber history.

    Returns:
    - Tuple[DataFrame, DataFrame]: A tuple containing two DataFrames. The first DataFrame includes the
      customer sample with churn-related and other calculated fields. The second DataFrame contains just
      the customer and subscriber keys of the filtered sample.
    """

    contract_details = (
        subs_history_filter.select(
            "CUSTOMER_KEY",
            "SUBSCRIBER_KEY",
            "MSISDN",
            "COMMITMENT_START_DATE",
            "COMMITMENT_END_DATE",
            "GBYTE_ALLOWANCE",
            "MINUTES_ALLOWANCE",
            "PLAN_TARIFF",
            "AMORTISED_DEVICE_COST",
            "WHAT_CUSTOMER_PAYS_NET_VAT",
            "MRC_DEAL_WITHOUT_ADDONS_EXVAT",
            "NMRC_BLENDED_DEAL",
            "MRC_BLENDED_DEAL",
            "MRC_PCT_DISCOUNT_AMORTISED",
            "MRC_TARIFF",
            "MRC_PRICE_MODIFIER",
            "MRC_ADD_ONS",
            "MRC_INSURANCE",
            "MRC_OTHER",
            "MRC_DISCOUNT",
            "DISCOUNT_PERCENTAGE",
            "MRC_PCT_DISCOUNT",
            "MRC_FIXED_DISCOUNT",
            "DEVICE_BRAND",
            "DEVICE_MODEL",
            "DEVICE_TYPE",
            "RRPPRICE_INC_VAT",
            "SIM_TYPE",
        )
        .distinct()
        .groupby(["CUSTOMER_KEY", "SUBSCRIBER_KEY"])
        .count()
    )

    single_contract_subs = contract_details.filter(psf.col("count") == 1)

    customer_sample = (
        subs_history_filter.join(
            single_contract_subs, on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"], how="inner"
        )
        .select(
            "CUSTOMER_KEY",
            "SUBSCRIBER_KEY",
            "COMMITMENT_START_DATE",
            "COMMITMENT_END_DATE",
            "DISCONNECTION_DATE",
            "model_date",
        )
        .distinct()
    )

    customer_sample_w_churn_flag = (
        customer_sample.withColumn(
            "DISCONNECTION_DATE",
            psf.when(
                psf.col("DISCONNECTION_DATE") == "3333-03-03T00:00:00Z", None
            ).otherwise(psf.col("DISCONNECTION_DATE")),
        )
        .withColumn(
            "days_remaining",
            -1 * psf.datediff(psf.col("model_date"), psf.col("COMMITMENT_END_DATE")),
        )
        .withColumn("30d_start", psf.date_add(psf.col("model_date"), -30))
        .withColumn("90d_start", psf.date_add(psf.col("model_date"), -90))
        .filter(psf.col("COMMITMENT_START_DATE") <= psf.col("model_date"))
    )

    single_end_customers = (
        customer_sample_w_churn_flag.groupby("CUSTOMER_KEY", "SUBSCRIBER_KEY")
        .count()
        .filter(psf.col("count") <= 1)
    )

    customer_sample_w_churn_flag = customer_sample_w_churn_flag.join(
        single_end_customers, on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"], how="inner"
    ).drop("count")

    customer_sample_keys = customer_sample_w_churn_flag.select(
        "CUSTOMER_KEY", "SUBSCRIBER_KEY"
    )

    return customer_sample_w_churn_flag, customer_sample_keys


def get_contract_details(subscriber_history, customer_sample_w_churn_flag):
    """
    Retrieves contract details for a given customer sample, focusing on those with specific customer
    types and line of business.

    Parameters:
    - subscriber_history (DataFrame): The dataset containing subscriber history.
    - customer_sample_w_churn_flag (DataFrame): The customer sample DataFrame with churn flags.

    Returns:
    - DataFrame: A DataFrame containing detailed contract information for the customer sample.
    """

    contract_details = (
        customer_sample_w_churn_flag.select(
            "CUSTOMER_KEY", "SUBSCRIBER_KEY", "COMMITMENT_END_DATE", "model_date"
        )
        .join(
            subscriber_history,
             on=["CUSTOMER_KEY", "SUBSCRIBER_KEY", "COMMITMENT_END_DATE"],
             how = "left"
        )
        .filter(psf.col("CUSTOMER_SUB_TYPE") == "Individual")
        .filter(psf.col("LOB").isin("Voice_SIMO", "Voice_CHS"))
        .filter(psf.col("COMMITMENT_END_DATE") >= psf.col("model_date"))
        .withColumn('PLAN_TARIFF_GROUP',psf.when(psf.col('PLAN_TARIFF').isin(PLAN_TARIFF_LIST), psf.col('PLAN_TARIFF')).otherwise('Other'))
        .withColumn('GBYTE_ALLOWANCE_GROUP',psf.when(psf.col('GBYTE_ALLOWANCE').isin(GB_ALLOWANCE_LIST), psf.col('GBYTE_ALLOWANCE')).otherwise('Other'))
        .withColumn('MINUTES_ALLOWANCE_GROUP',psf.when(psf.col('MINUTES_ALLOWANCE').isin(['AYCE']), psf.col('MINUTES_ALLOWANCE')).otherwise('Other'))
        .select(
            "CUSTOMER_KEY",
            "SUBSCRIBER_KEY",
            "COMMITMENT_END_DATE",
            "LOB",
            "COMMITMENT_DURATION",
            "GBYTE_ALLOWANCE",
            "GBYTE_ALLOWANCE_GROUP",
            "MINUTES_ALLOWANCE",
            "MINUTES_ALLOWANCE_GROUP",
            "PLAN_TARIFF",
            "PLAN_TARIFF_GROUP",
            "AMORTISED_DEVICE_COST",
            "MRC_DEAL_WITHOUT_ADDONS_EXVAT",
            "NMRC_BLENDED_DEAL",
            "MRC_BLENDED_DEAL",
            "MRC_PCT_DISCOUNT_AMORTISED",
            "MRC_TARIFF",
            "MRC_PRICE_MODIFIER",
            "MRC_INSURANCE",
            "MRC_OTHER",
            "MRC_DISCOUNT",
            "DISCOUNT_PERCENTAGE",
            "MRC_PCT_DISCOUNT",
            "MRC_FIXED_DISCOUNT",
            "DEVICE_BRAND",
            "DEVICE_MODEL",
            "DEVICE_TYPE",
            "RRPPRICE_INC_VAT",
            "SIM_TYPE",
        )
        .distinct()
    )

    windowSpec = Window.partitionBy("CUSTOMER_KEY", "SUBSCRIBER_KEY").orderBy(
        "CUSTOMER_KEY"
    )

    customer_contract_details_final = (
        contract_details
        .withColumn("row_num", psf.row_number().over(windowSpec))
        .filter(psf.col("row_num") == 1)
        .drop("COMMITMENT_END_DATE", "row_num")
        
    )

    return customer_contract_details_final


def get_customer_metadata(subscriber, subscriber_history, customer_sample_w_churn_flag):
    """
    Generates customer metadata including age, tenure, and whether the contract is the first one based
    on the subscriber and subscriber history data.

    Parameters:
    - subscriber (DataFrame): The dataset containing subscriber information.
    - subscriber_history (DataFrame): The dataset containing subscriber history.
    - customer_sample_w_churn_flag (DataFrame): The customer sample DataFrame with churn flags.

    Returns:
    - DataFrame: A DataFrame containing customer metadata.
    """

    subscriber_age = (
        subscriber.join(customer_sample_w_churn_flag, on="SUBSCRIBER_KEY", how="inner")
        .filter(psf.col("SUBSCRIBER_BIRTH_DATE") != "1900-01-01 00:00:00.000")
        .filter(psf.col("SUBSCRIBER_BIRTH_DATE").isNotNull())
        .withColumn(
            "age",
            psf.floor(
                psf.datediff(psf.col("model_date"), psf.col("SUBSCRIBER_BIRTH_DATE"))
                / 365
            ),
        )
        .groupby(
            "SUBSCRIBER_KEY",
        )
        .agg(psf.max("age").alias("age"))
    )

    subscriber_first_contract = (
        subscriber_history.join(
            customer_sample_w_churn_flag,
            on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
            how="left",
        )
        .filter(psf.col("START_DATE") <= psf.col("model_date"))
        .groupby("CUSTOMER_KEY", "SUBSCRIBER_KEY", "ACQ_DATE_CUSTOMER")
        .agg(psf.countDistinct("START_DATE").alias('count_start_dates'))
        .withColumn(
            "first_contract",
            psf.when(psf.col("count_start_dates") == 1, True).otherwise(False),
        )
    )

    customer_metadata_final = (
        customer_sample_w_churn_flag.join(
            subscriber_age, on="SUBSCRIBER_KEY", how="left"
        )
        .join(
            subscriber_first_contract, on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"], how="left"
        )
        .withColumn(
            "three_tenure",
            psf.round(
                psf.months_between(
                    psf.col("model_date"), psf.to_date(psf.col("ACQ_DATE_CUSTOMER"))
                )
            ).cast("int"),
        )
        .select(
            "CUSTOMER_KEY", "SUBSCRIBER_KEY", "age", "three_tenure", "first_contract"
        )
    )

    return customer_metadata_final


def get_customer_usage(
    customer_sample_w_churn_flag, customer_sample_keys, usage_v, years, months
):
    """
    Aggregates usage statistics for customers within the sample, for specified years and months.

    Parameters:
    - customer_sample_w_churn_flag (DataFrame): The customer sample DataFrame with churn flags.
    - customer_sample_keys (DataFrame): DataFrame containing customer and subscriber keys.
    - usage_v (DataFrame): The dataset containing usage information.
    - years (list): List of years to include in the usage data.
    - months (list): List of months to include in the usage data.

    Returns:
    - DataFrame: A DataFrame containing aggregated usage statistics for the customer sample.
    """
    usage_v_limit = (
        usage_v.select(
            "CUSTOMER_KEY",
            "SUBSCRIBER_KEY",
            "START_TIME",
            "event_type",
            "actual_duration",
            "VOLUME_MB",
            "ONNET_IND",
            "CHARGE_DESC",
            "ROAMING_CHARGE_TYPE",
            "ALLOWANCE_INFORMATION",
            "called_number",
            "cycle_year",
            "cycle_month",
        )
        .filter(psf.col("cycle_year").isin(years))
        .filter(psf.col("cycle_month").isin(months))
        .join(
            customer_sample_w_churn_flag,
            on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
            how="inner",
        )
        .filter(
            (psf.col("START_TIME") > psf.col("30d_start"))
            & (psf.col("START_TIME") <= psf.col("model_date"))
        )
    )

    voice_condition = psf.upper(psf.col("event_type")) == "VOICE"
    onnet_condition = psf.upper(psf.col("ONNET_IND")) == "ONNET"
    roaming_voice_condition = (
        psf.upper(psf.col("ROAMING_CHARGE_TYPE")).like("%ROAM%")
    ) & (psf.trim(psf.upper(psf.col("event_type"))) == "VOICE")
    roaming_data_condition = (
        psf.upper(psf.col("ROAMING_CHARGE_TYPE")).like("%ROAM%")
    ) & (psf.trim(psf.upper(psf.col("event_type"))) == "DATA")
    out_of_bundle_voice_condition = (psf.col("ALLOWANCE_INFORMATION").isNull()) & (
        psf.trim(psf.upper(psf.col("event_type"))) == "VOICE"
    )
    fah_calls_condition = (
        (psf.upper(psf.col("event_type")) == "VOICE")
        & (psf.upper(psf.col("CHARGE_DESC")).like("%ROAM%"))
        & (psf.upper(psf.col("ROAMING_CHARGE_TYPE")) == "NONE")
    )

    # Grouping and aggregating data
    customer_usage_agg = usage_v_limit.groupBy("CUSTOMER_KEY", "SUBSCRIBER_KEY").agg(
        psf.sum(
            psf.when(voice_condition, psf.col("actual_duration")).otherwise(0)
        ).alias("voice_time"),
        psf.sum(psf.col("VOLUME_MB")).alias("AMOUNT_OF_DATA"),
        psf.sum(
            psf.when(onnet_condition, psf.col("actual_duration")).otherwise(0)
        ).alias("ONNET_TIME"),
        psf.count(psf.lit(1)).alias("MOLO_TIME"),
        psf.sum(
            psf.when(roaming_voice_condition, psf.col("actual_duration")).otherwise(0)
        ).alias("FAH_TIME"),
        psf.sum(
            psf.when(roaming_data_condition, psf.col("VOLUME_MB")).otherwise(0)
        ).alias("FAH_ROAMING_DATA"),
        psf.sum(
            psf.when(
                out_of_bundle_voice_condition, psf.col("actual_duration")
            ).otherwise(0)
        ).alias("OUT_OF_BUNDLE_TIME"),
        psf.sum(psf.when(voice_condition, 1).otherwise(0)).alias(
            "COUNT_OF_VOICE_CALLS"
        ),
        psf.sum(psf.when((voice_condition & onnet_condition), 1).otherwise(0)).alias(
            "COUNT_OF_ON_NET_CALLS"
        ),
        psf.count(psf.lit(1)).alias("COUNT_OF_MOLO_CALLS"),
        psf.sum(psf.when(fah_calls_condition, 1).otherwise(0)).alias(
            "COUNT_OF_FAH_CALLS"
        ),
        psf.countDistinct("called_number").alias("AVE_UNIQ_NUMS_DIALLED"),
        psf.avg(
            psf.when(voice_condition, psf.col("actual_duration")).otherwise(0)
        ).alias("MEAN_VOICE"),
        psf.stddev(
            psf.when(voice_condition, psf.col("actual_duration")).otherwise(0)
        ).alias("STDDEV_VOICE"),
        psf.avg(
            psf.when(psf.col("volume_mb") > 0, psf.col("VOLUME_MB")).otherwise(0)
        ).alias("MEAN_DATA"),
        psf.stddev(psf.col("VOLUME_MB")).alias("STDDEV_DATA"),
    )

    customer_usage_final = customer_sample_keys.join(
        customer_usage_agg, on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"], how="left"
    )

    return customer_usage_final


def get_customer_multiple_accounts(
    customer_sample_keys, customer_sample_w_churn_flag, eng_subscriber_history
):
    """
    Identifies customers with multiple accounts and aggregates relevant statistics based on the
    engineered subscriber history.

    Parameters:
    - customer_sample_keys (DataFrame): DataFrame containing customer and subscriber keys.
    - customer_sample_w_churn_flag (DataFrame): The customer sample DataFrame with churn flags.
    - eng_subscriber_history (DataFrame): The dataset containing engineered subscriber history.

    Returns:
    - DataFrame: A DataFrame containing aggregated statistics for customers with multiple accounts.
    """

    eng_subscriber_history_b2c = eng_subscriber_history.filter(
        psf.col("customer_type") == "B2C"
    )

    acquisition_condition = psf.col("ORDER_ACTION_DESC") == "Acquisition"
    disconnection_condition = psf.col("tariff_action") == "Disconnection"
    upgrade_condition = psf.col("tariff_action") == "Upgrade"

    days_since_commitment_end = psf.datediff(
        psf.col("model_date"), psf.to_date(psf.col("COMMITMENT_END_DATE"))
    )
    in_FTG_condition = days_since_commitment_end <= 0
    in_retention_window_condition = (days_since_commitment_end > 0) & (
        days_since_commitment_end <= 60
    )
    inlife_condition = days_since_commitment_end > 60

    eng_subscriber_history_agg = (
        eng_subscriber_history_b2c.join(
            customer_sample_w_churn_flag.select(
                "CUSTOMER_KEY", "SUBSCRIBER_KEY", "model_date"
            ),
            on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
            how="inner",
        )
        .filter(psf.col("START_DATE") < psf.col("model_date"))
        .groupBy("CUSTOMER_KEY")
        .agg(
            psf.countDistinct("SUBSCRIBER_KEY").alias("accs_opened"),
            psf.countDistinct(
                psf.when(acquisition_condition, psf.col("SUBSCRIBER_KEY"))
            ).alias("acc_acq_rec"),
            psf.countDistinct(
                psf.when(disconnection_condition, psf.col("SUBSCRIBER_KEY"))
            ).alias("accs_closed"),
            psf.countDistinct(
                psf.when(upgrade_condition, psf.col("SUBSCRIBER_KEY"))
            ).alias("accs_upgrade"),
            psf.countDistinct(
                psf.when(in_FTG_condition, psf.col("SUBSCRIBER_KEY"))
            ).alias("other_acc_FTG"),
            psf.countDistinct(
                psf.when(in_retention_window_condition, psf.col("SUBSCRIBER_KEY"))
            ).alias("other_acc_ret_window"),
            psf.countDistinct(
                psf.when(inlife_condition, psf.col("SUBSCRIBER_KEY"))
            ).alias("other_acc_inlife"),
        )
    )

    customer_multiple_accounts_final = customer_sample_keys.join(
        eng_subscriber_history_agg, on="CUSTOMER_KEY", how="left"
    ).distinct()

    return customer_multiple_accounts_final


def get_customer_billing(
    customer_sample_w_churn_flag, customer_sample_keys, bill_customer
):
    """
    Aggregates billing information for customers within the sample, focusing on data from the last 90 days.

    Parameters:
    - customer_sample_w_churn_flag (DataFrame): The customer sample DataFrame with churn flags.
    - customer_sample_keys (DataFrame): DataFrame containing customer and subscriber keys.
    - bill_customer (DataFrame): The dataset containing billing information.

    Returns:
    - DataFrame: A DataFrame containing aggregated billing information for the customer sample.
    """

    customer_plus_billing =  (
        customer_sample_w_churn_flag
        .join(
            bill_customer
            .withColumnRenamed(
                "CUSTOMER_ID", "CUSTOMER_KEY"
            ),
            on="CUSTOMER_KEY",
            how="left"
        )
        .filter(
            (psf.col("BILL_DATE") > psf.date_sub(psf.col("model_date"), 90))
            & (psf.col("BILL_DATE") <= psf.col("model_date"))
        )
        .select(
            "CUSTOMER_KEY",
            "BILL_DATE",
            "BILL_PREV_BALANCE_AMT",
            "BILL_PYM_RECEIVED_AMT",
            "PAST_DUE_AMT",
            "LATE_PYM_BASE_AMT",
            "LATE_PYM_CHRG_AMT",
            "CURR_DISCOUNT_AMT",
            "TOTAL_DUE_AMT",
            "OVERDUE_AMT",
            "RECURRING_CHRG_AMT",
            "LOCAL_USAGE_CHRG_AMT",
            "ROAMING_USAGE_CHRG_AMT",
            "DATA_USAGE_CHRG_AMT",
        )
    )

    customer_plus_billing_agg = customer_plus_billing.groupBy("CUSTOMER_KEY").agg(
        psf.mean("BILL_PREV_BALANCE_AMT").alias("mean_BILL_PREV_BALANCE_AMT"),
        psf.stddev("BILL_PREV_BALANCE_AMT").alias("std_BILL_PREV_BALANCE_AMT"),
        psf.mean("BILL_PYM_RECEIVED_AMT").alias("mean_BILL_PYM_RECEIVED_AMT"),
        psf.stddev("BILL_PYM_RECEIVED_AMT").alias("std_BILL_PYM_RECEIVED_AMT"),
        psf.mean("PAST_DUE_AMT").alias("mean_PAST_DUE_AMT"),
        psf.stddev("PAST_DUE_AMT").alias("std_PAST_DUE_AMT"),
        psf.mean("LATE_PYM_BASE_AMT").alias("mean_LATE_PYM_BASE_AMT"),
        psf.stddev("LATE_PYM_BASE_AMT").alias("std_LATE_PYM_BASE_AMT"),
        psf.mean("LATE_PYM_CHRG_AMT").alias("mean_LATE_PYM_CHRG_AMT"),
        psf.stddev("LATE_PYM_CHRG_AMT").alias("std_LATE_PYM_CHRG_AMT"),
        psf.mean("CURR_DISCOUNT_AMT").alias("mean_CURR_DISCOUNT_AMT"),
        psf.stddev("CURR_DISCOUNT_AMT").alias("std_CURR_DISCOUNT_AMT"),
        psf.mean("TOTAL_DUE_AMT").alias("mean_TOTAL_DUE_AMT"),
        psf.stddev("TOTAL_DUE_AMT").alias("std_TOTAL_DUE_AMT"),
        psf.mean("OVERDUE_AMT").alias("mean_OVERDUE_AMT"),
        psf.stddev("OVERDUE_AMT").alias("std_OVERDUE_AMT"),
        psf.mean("RECURRING_CHRG_AMT").alias("mean_RECURRING_CHRG_AMT"),
        psf.stddev("RECURRING_CHRG_AMT").alias("std_RECURRING_CHRG_AMT"),
        psf.mean("LOCAL_USAGE_CHRG_AMT").alias("mean_LOCAL_USAGE_CHRG_AMT"),
        psf.stddev("LOCAL_USAGE_CHRG_AMT").alias("std_LOCAL_USAGE_CHRG_AMT"),
        psf.mean("ROAMING_USAGE_CHRG_AMT").alias("mean_ROAMING_USAGE_CHRG_AMT"),
        psf.stddev("ROAMING_USAGE_CHRG_AMT").alias("std_ROAMING_USAGE_CHRG_AMT"),
        psf.mean("DATA_USAGE_CHRG_AMT").alias("mean_DATA_USAGE_CHRG_AMT"),
        psf.stddev("DATA_USAGE_CHRG_AMT").alias("std_DATA_USAGE_CHRG_AMT"),
    )

    customer_billing_final = customer_sample_keys.join(
        customer_plus_billing_agg, on="CUSTOMER_KEY", how="left"
    ).dropDuplicates()

    return customer_billing_final


def get_customer_demographics(customer_sample_keys, customer):
    """
    Retrieves demographic information for the customer sample.

    Parameters:
    - customer_sample_keys (DataFrame): DataFrame containing customer and subscriber keys.
    - customer (DataFrame): The dataset containing customer demographic information.

    Returns:
    - DataFrame: A DataFrame containing demographic information for the customer sample.
    """

    customer_demographics_final = customer_sample_keys.join(
        customer.select(
            "CUSTOMER_KEY",
            "OCCUPATION_CODE_DESC",
            "REGION",
        ),
        on="CUSTOMER_KEY",
        how="left",
    )

    return customer_demographics_final


def get_customer_ported_in_from(customer_sample_w_churn_flag, port_in_request):
    """
    Identifies customers who ported in from another network provider and categorizes them based on the source network.

    Parameters:
    - customer_sample_w_churn_flag (DataFrame): The customer sample DataFrame with churn flags.
    - port_in_request (DataFrame): The dataset containing port-in request information for customers.

    Returns:
    - DataFrame: A DataFrame with customers who ported in, including flags for port-in status and categories
      based on the source network.
    """

    windowSpec = Window.partitionBy("CUSTOMER_KEY").orderBy(psf.desc("request_date"))

    customer_ported_in_filter = (
        port_in_request.withColumn("CUSTOMER_KEY", psf.trim(psf.col("CUSTOMER_KEY")))
        .join(
            customer_sample_w_churn_flag.drop("SUBSCRIBER_KEY").withColumn(
                "CUSTOMER_KEY", psf.trim(psf.col("CUSTOMER_KEY"))
            ),
            on="CUSTOMER_KEY",
            how="inner",
        )
        .withColumn("request_date", psf.to_date(psf.col("PI_REQUEST_INITIATION_DATE")))
        .withColumn("row_number", psf.row_number().over(windowSpec))
        .filter((psf.col("request_date").isNull()) | (psf.col("row_number") == 1))
        .drop("row_number")
    )

    customer_ported_in_final = (
        customer_sample_w_churn_flag.join(
            customer_ported_in_filter.drop("SUBSCRIBER_KEY"),
            how="left",
            on="CUSTOMER_KEY",
        )
        .withColumn(
            "portin_flag",
            psf.when(
                (psf.col("NETWORK_NAME") == "") | (psf.col("NETWORK_NAME").isNull()),
                "N",
            ).otherwise("Y"),
        )
        .withColumn(
            "G_portin_from",
            psf.when(
                psf.upper(psf.col("NETWORK_NAME")).like("%2 CIRCLES COMMUNICATIONS%"), 0
            )
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%ASDA%"), 5)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%ABZORB SOLUTIONS LTD%"), 0)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%ALTERNATIVE NETWORKS%"), 5)
            .when(
                psf.upper(psf.col("NETWORK_NAME")).like(
                    "%ARROW MOBILE COMMUNICATIONS PLC%"
                ),
                5,
            )
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%BT BUSINESS%"), 3)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%BT CONSUMER%"), 1)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%BT MOBILITY%"), 5)
            .when(
                psf.upper(psf.col("NETWORK_NAME")).like("%BAMBOO TECHNOLOGY GROUP%"), 0
            )
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%BROADSWORD NETWORK%"), 5)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%DAISY%"), 1)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%INTERCIT%"), 0)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%LEBARA MOBILE%"), 2)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%LIFECYCLE%"), 5)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%LYCAMOBILE%"), 4)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%MANX%"), 5)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%MUNDIO MOBILE LTD%"), 2)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%NA %"), 5)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%NOWMOB%"), 2)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%OPAL %"), 2)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%ORANGE SP%"), 5)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%PLAN COMMUNICATIONS%"), 1)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%SKY UK LIMITED%"), 1)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%T-MOBILE SP%"), 3)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%TALK TALK GROUP%"), 5)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%TALKMOBILE%"), 5)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%TALKMOBILE PAYM%"), 1)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%TELECOM PLUS%"), 2)
            .when(
                psf.upper(psf.col("NETWORK_NAME")).like("%TELEFONICA O2 UK LIMITED%"), 4
            )
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%TESCO MOBILE%"), 3)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%TIMICO LTD%"), 5)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%TRANSATEL%"), 0)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%TRUPHONE%"), 5)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%VALUE%"), 5)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%VIRGIN MOBILE%"), 4)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%VODAFONE BUSINESS %"), 5)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%VODAFONE CONNECT%"), 5)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%VODAFONE CORPORATE %"), 2)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%VODAFONE PARTNER%"), 2)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%VODAFONE UK%"), 2)
            .when(psf.upper(psf.col("NETWORK_NAME")).like("%GIFFGAFF%"), 2)
            .otherwise(None),
        )
        .withColumn(
            "G_portin_from0",
            psf.when(psf.col("G_portin_from") == 5, -1)
            .when(psf.col("G_portin_from") == 0, 1)
            .otherwise(None),
        )
        .withColumn(
            "G_portin_from1",
            psf.when(psf.col("G_portin_from") == 5, -1)
            .when(psf.col("G_portin_from") == 1, 1)
            .otherwise(None),
        )
        .withColumn(
            "G_portin_from2",
            psf.when(psf.col("G_portin_from") == 5, -1)
            .when(psf.col("G_portin_from") == 2, 1)
            .otherwise(None),
        )
        .withColumn(
            "G_portin_from3",
            psf.when(psf.col("G_portin_from") == 5, -1)
            .when(psf.col("G_portin_from") == 3, 1)
            .otherwise(None),
        )
        .withColumn(
            "G_portin_from4",
            psf.when(psf.col("G_portin_from") == 5, -1)
            .when(psf.col("G_portin_from") == 4, 1)
            .otherwise(None),
        )
        .select(
            "CUSTOMER_KEY",
            "SUBSCRIBER_KEY",
            "NETWORK_NAME",
            "portin_flag",
            "G_portin_from",
            "G_portin_from0",
            "G_portin_from1",
            "G_portin_from2",
            "G_portin_from3",
            "G_portin_from4",
        )
        .dropDuplicates()
    )

    return customer_ported_in_final

def calculate_usage_percentage(usage_column, allowance_column):
    """
    Calculates the percentage of usage against the allowance for a given service (e.g., data, voice).

    Parameters:
    - usage_column (str): Column name representing the amount of usage.
    - allowance_column (str): Column name representing the service allowance.

    Returns:
    - Column: A column with calculated usage percentages, rounded to the nearest whole number.
    """
    return psf.round(
        (psf.col(usage_column) / allowance_column) * 100, 
        0
    )

def handle_ayce(column_name, ayce_value):
    """
    Handles "All You Can Eat" (AYCE) allowances by replacing them with a specified high value to facilitate
    percentage calculations.

    Parameters:
    - column_name (str): Column name containing the allowances.
    - ayce_value (int): The value to replace AYCE allowances with.

    Returns:
    - Column: A column with AYCE allowances replaced by the specified value.
    """
    return psf.round(
        psf.when(psf.col(column_name) == "AYCE", ayce_value).otherwise(psf.col(column_name)), 
        0
    )

def get_customer_allocation_usage(customer_usage_final, customer_sample_keys, contract_details):
    """
    Calculates the percentage of allocated usage for data and voice services and categorizes them into predefined buckets.

    Parameters:
    - customer_usage_final (DataFrame): The DataFrame containing customer usage information.
    - customer_sample_keys (DataFrame): DataFrame containing customer and subscriber keys.
    - contract_details (DataFrame): The DataFrame containing contract details including allowances.

    Returns:
    - DataFrame: A DataFrame with the percentage of allocated usage and bucket categorization for each customer.
    """

    customer_allocations_pcnts = (
        contract_details
        .select("SUBSCRIBER_KEY", "GBYTE_ALLOWANCE", "MINUTES_ALLOWANCE")
        .join(customer_usage_final.drop('CUSTOMER_KEY'), on="SUBSCRIBER_KEY", how="inner")
        # Handle AYCE indicators and allowances
        .withColumn("DATA_AYCE_IND", psf.when(psf.col("GBYTE_ALLOWANCE") == "AYCE", 1).otherwise(0))
        .withColumn("VOICE_AYCE_IND", psf.when(psf.col("MINUTES_ALLOWANCE") == "AYCE", 1).otherwise(0))
        .withColumn("GBYTE_ALLOWANCE", handle_ayce("GBYTE_ALLOWANCE", 100000))
        .withColumn("MINUTES_ALLOWANCE", handle_ayce("MINUTES_ALLOWANCE", 100000))
        # Calculate usage in minutes and GB
        .withColumn("voice_usage_min", psf.round(psf.col("voice_time") / 60, 0))
        .withColumn("DATA_USAGE_GB", psf.round(psf.col("AMOUNT_OF_DATA") / 1024, 2))
        # Calculate usage percentages
        .withColumn("data_usage_perc", calculate_usage_percentage("AMOUNT_OF_DATA", psf.col("GBYTE_ALLOWANCE")))
        .withColumn("voice_usage_perc", calculate_usage_percentage("voice_time", psf.col("MINUTES_ALLOWANCE")))
        # Allocate usage into categories
        .withColumn("mbs_alloc_50", psf.when(psf.col("data_usage_perc").between(0, 50), 1).otherwise(0))
        .withColumn("mbs_alloc_75", psf.when(psf.col("data_usage_perc").between(50, 75), 1).otherwise(0))
        .withColumn("mbs_alloc_90", psf.when(psf.col("data_usage_perc").between(75, 90), 1).otherwise(0))
        .withColumn("mbs_alloc_all", psf.when(psf.col("data_usage_perc") > 90, 1).otherwise(0))
        .withColumn("voi_alloc_50", psf.when(psf.col("voice_usage_perc").between(0, 50), 1).otherwise(0))
        .withColumn("voi_alloc_75", psf.when(psf.col("voice_usage_perc").between(50, 75), 1).otherwise(0))
        .withColumn("voi_alloc_90", psf.when(psf.col("voice_usage_perc").between(75, 90), 1).otherwise(0))
        .withColumn("voi_alloc_all", psf.when(psf.col("voice_usage_perc") > 90, 1).otherwise(0))
        .drop("GBYTE_ALLOWANCE", "MINUTES_ALLOWANCE")
    )

    customer_allocations_final = (
        customer_sample_keys
        .join(
            customer_allocations_pcnts,
            on = "SUBSCRIBER_KEY",
            how = "left"
        )
        .select(
            "CUSTOMER_KEY",
            "SUBSCRIBER_KEY",
            "DATA_AYCE_IND",
            "VOICE_AYCE_IND",
            "voice_usage_min",
            "DATA_USAGE_GB",
            "data_usage_perc",
            "voice_usage_perc",
            "mbs_alloc_50",
            "mbs_alloc_75",
            "mbs_alloc_90",
            "mbs_alloc_all",
            "voi_alloc_50",
            "voi_alloc_75",
            "voi_alloc_90",
            "voi_alloc_all"
        )
    )
    
    return customer_allocations_final

def get_customer_interactions(
    customer_sample_w_churn_flag, subs_history_filter, interactions_v
):
    """
    Aggregates customer interaction data in the 30 days leading up to the model date, categorizing interactions by type.

    Parameters:
    - customer_sample_w_churn_flag (DataFrame): The customer sample DataFrame with churn flags.
    - interactions_v (DataFrame): The dataset containing customer interaction information.

    Returns:
    - DataFrame: A DataFrame with aggregated interaction counts by type for each customer.
    """

    customer_plus_msisdn = customer_sample_w_churn_flag.join(
        subs_history_filter.select("CUSTOMER_KEY", "SUBSCRIBER_KEY", "MSISDN"),
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    ).distinct()

    interactions_agg = (
        customer_plus_msisdn.join(
            interactions_v.withColumn(
                "START_DATE", psf.to_date(psf.col("START_DATE"), "yyyy-MM-dd")
            )
            .withColumnRenamed("SU_SUBSCRIBER_ID", "MSISDN")
            .withColumnRenamed("CU_CUSTOMER_ID", "CUSTOMER_KEY"),
            on=["CUSTOMER_KEY", "MSISDN"],
            how="inner",
        )
        .filter(
            (psf.col("START_DATE") >= psf.col("90d_start"))
            & (psf.col("START_DATE") < psf.col("model_date"))
        )
        .groupBy("CUSTOMER_KEY", "SUBSCRIBER_KEY")
        .agg(
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_1_TEXT")).like("%CANCEL%"), 1
                ).otherwise(0)
            ).alias("int_want_cancel"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_1_TEXT")).like("%UPGRADE%"), 1
                ).otherwise(0)
            ).alias("int_want_upgrade"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_1_TEXT")).like("%PHONE%"), 1
                ).otherwise(0)
            ).alias("int_new_ph_con"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_1_TEXT")).like("%BILL%"), 1
                ).otherwise(0)
            ).alias("int_bill_enq"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_1_TEXT")).like("%ENQUIRY%")
                    | psf.upper(psf.col("REASON_2_TEXT")).like("%ENQUIRY%")
                    | psf.upper(psf.col("REASON_3_TEXT")).like("%ENQUIRY%"),
                    1,
                ).otherwise(0)
            ).alias("int_refund_enq"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_1_TEXT")).like("%(TECH)%"), 1
                ).otherwise(0)
            ).alias("int_tech_enq"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_1_TEXT")).like("%MAKE A PAYMENT%")
                    | psf.upper(psf.col("REASON_2_TEXT")).like("%MAKE A PAYMENT%"),
                    1,
                ).otherwise(0)
            ).alias("int_make_payment"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_1_TEXT")).like("%COVERAGE%")
                    | psf.upper(psf.col("REASON_2_TEXT")).like("%COVERAGE%"),
                    1,
                ).otherwise(0)
            ).alias("int_network"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_1_TEXT")).like("%PRICE PLAN%"), 1
                ).otherwise(0)
            ).alias("int_tariff_enq"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_2_TEXT")).like("%OFFER%")
                    | psf.upper(psf.col("REASON_1_TEXT")).like("%OFFER%"),
                    1,
                ).otherwise(0)
            ).alias("int_offers_enq"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_2_TEXT")).like("% PAC %"), 1
                ).otherwise(0)
            ).alias("int_want_pac"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_2_TEXT")).like("% ADD%"), 1
                ).otherwise(0)
            ).alias("int_want_dat_addon"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_2_TEXT")).like("%BETTER%"), 1
                ).otherwise(0)
            ).alias("int_comp_better_offer"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_1_TEXT")).like("%DEAL%")
                    | psf.upper(psf.col("REASON_2_TEXT")).like("%DEAL%"),
                    1,
                ).otherwise(0)
            ).alias("int_want_better_deal"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_3_TEXT")).like("%CASE RAISED%"), 1
                ).otherwise(0)
            ).alias("outcome_case_raised"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_3_TEXT")).like("%PAC%"), 1
                ).otherwise(0)
            ).alias("outcome_pac_given"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_3_TEXT")).like("%CONSIDERING%"), 1
                ).otherwise(0)
            ).alias("outcome_cons_offer"),
            psf.sum(
                psf.when(
                    psf.upper(psf.col("REASON_1_TEXT")).like("%CANCEL%"), 1
                ).otherwise(0)
            ).alias("WTC_calls"),
            psf.count("*").alias("int_total"),
        )
    )

    customer_interactions_final = (
        customer_sample_w_churn_flag.select("CUSTOMER_KEY", "SUBSCRIBER_KEY")
        .join(interactions_agg, on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"], how="left")
        .distinct()
    )

    ints_to_fill = [
        "int_want_cancel",
        "int_want_upgrade",
        "int_new_ph_con",
        "int_bill_enq",
        "int_refund_enq",
        "int_tech_enq",
        "int_make_payment",
        "int_network",
        "int_tariff_enq",
        "int_offers_enq",
        "int_want_pac",
        "int_want_dat_addon",
        "int_comp_better_offer",
        "int_want_better_deal",
        "outcome_case_raised",
        "outcome_pac_given",
        "outcome_cons_offer",
        "WTC_calls",
        "int_total",
    ]

    customer_interactions_final = customer_interactions_final.na.fill(
        {col: 0 for col in ints_to_fill}
    )

    return customer_interactions_final

def get_customer_complaints(customer_sample_w_churn_flag, complaints):
    """
    Aggregates customer complaint data up to the model date, including the most recent complaint and categorization of complaints by type.

    Parameters:
    - customer_sample_w_churn_flag (DataFrame): The customer sample DataFrame with churn flags.
    - complaints (DataFrame): The dataset containing customer complaint information.

    Returns:
    - DataFrame: A DataFrame with aggregated complaint data, including counts and recency of complaints by type.
    """

    complaints_filter = (
        complaints
        .withColumn("START_DATE", psf.to_date(psf.col('START_DATE'), "yyyy-MM-dd"))
        .join(
            customer_sample_w_churn_flag.select('CUSTOMER_KEY','model_date','90d_start'),
            complaints["CUSTOMER_ID"] == customer_sample_w_churn_flag["CUSTOMER_KEY"],
            "inner"
        )
        .filter(
            (psf.col('START_DATE')>=psf.col('90d_start')) & (psf.col('START_DATE')<psf.col('model_date'))
        )
    )

    complaints_agg = (
        complaints_filter
        .groupBy("customer_id","model_date")
        .agg(
            psf.count("*").alias("Total_complaints"),
            psf.max(psf.to_date("CASE_CREATED_DATE", format="yyyy-MM-dd")).alias("most_recent_complaint"),
            psf.max(psf.when(psf.upper(psf.col("case_description")).like("%BILL%"), 
                            psf.to_date("CASE_CREATED_DATE", format="yyyy-MM-dd")).otherwise(None)).alias("Billing_most_recent_int"),
            psf.sum(psf.when(psf.upper(psf.col("case_description")).like("%BILL%"), 1).otherwise(0)).alias("Billing_complaints"),
            psf.max(psf.when(psf.upper(psf.col("case_description")).rlike("CONNECT|NETWORK"), 
                            psf.to_date("CASE_CREATED_DATE", format="yyyy-MM-dd")).otherwise(None)).alias("Network_most_recent_int"),
            psf.sum(psf.when(psf.upper(psf.col("case_description")).rlike("CONNECT|NETWORK"), 1).otherwise(0)).alias("Network_complaints"),
            psf.max(psf.when(psf.upper(psf.col("case_description")).like("%SERIVCE%"), 
                            psf.to_date("CASE_CREATED_DATE", format="yyyy-MM-dd")).otherwise(None)).alias("Service_most_recent_int"),
            psf.sum(psf.when(psf.upper(psf.col("case_description")).like("%SERIVCE%"), 1).otherwise(0)).alias("Service_complaints"),
            psf.max(psf.when(psf.upper(psf.col("case_description")).like("%DEVICE%"), 
                            psf.to_date("CASE_CREATED_DATE", format="yyyy-MM-dd")).otherwise(None)).alias("Device_most_recent_int"),
            psf.sum(psf.when(psf.upper(psf.col("case_description")).like("%DEVICE%"), 1).otherwise(0)).alias("Device_complaints"),
        )
        .select(
            "*",
            psf.when(psf.col("Billing_most_recent_int").isNotNull(), 
                    psf.months_between(psf.col("model_date"), psf.col("Billing_most_recent_int"))).alias("Billing_complaint_mths_since"),
            psf.when(psf.col("Network_most_recent_int").isNotNull(), 
                    psf.months_between(psf.col("model_date"), psf.col("Network_most_recent_int"))).alias("Network_complaint_mths_since"),
            psf.when(psf.col("Service_most_recent_int").isNotNull(), 
                    psf.months_between(psf.col("model_date"), psf.col("Service_most_recent_int"))).alias("Service_complaint_mths_since"),
            psf.when(psf.col("Device_most_recent_int").isNotNull(), 
                    psf.months_between(psf.col("model_date"), psf.col("Device_most_recent_int"))).alias("Device_complaint_mths_since"),
            psf.when(psf.col("most_recent_complaint").isNotNull(), 
                    psf.months_between(psf.col("model_date"), psf.col("most_recent_complaint"))).alias("most_recent_complaint_mths_since")
        )
    )

    most_recent_complaint = (
        complaints
        .join(
            customer_sample_w_churn_flag,
            complaints.CUSTOMER_ID == customer_sample_w_churn_flag.CUSTOMER_KEY,
            "inner"
        )
        .where(psf.col("CASE_CREATED_DATE") <= psf.col("model_date"))
        .groupBy("CUSTOMER_ID","model_date")
        .agg(
            psf.max(psf.when(psf.col("CASE_CREATED_DATE").isNotNull(), psf.col("CASE_CREATED_DATE")).otherwise(None)).alias("max_complaint_dttm")
        )
    )

    most_recent_complaint_type = (
        complaints.alias("a")
        .join(
            most_recent_complaint.alias("b"),
            (psf.col("a.customer_id") == psf.col("b.customer_id")) & (psf.col("a.CASE_CREATED_DATE") == psf.col("b.max_complaint_dttm")),
            "inner"
        )
        .select(
            "a.customer_id",
            "b.model_date",
            psf.when(psf.upper(psf.col("case_description")).like("%BILL%"), 2)
            .when(psf.upper(psf.col("case_description")).like("%CONNECT%"), 0)
            .when(psf.upper(psf.col("case_description")).like("%NETWORK%"), 0)
            .when(psf.upper(psf.col("case_description")).like("%SERVICE%"), 1)
            .when(psf.upper(psf.col("case_description")).like("%DEVICE%"), 2)
            .when(psf.upper(psf.col("case_description")).like("%MISC%"), 2)
            .when(psf.upper(psf.col("case_description")).like("%NONE%"), 2)
            .otherwise(None).alias("most_recent_complaint_type")
        )
    )

    customer_complaints_final = (
        customer_sample_w_churn_flag.select("CUSTOMER_KEY","SUBSCRIBER_KEY","model_date").alias('a')
        .join(
            complaints_agg.alias('b'),
            on = ((psf.col('a.CUSTOMER_KEY') == psf.col('b.CUSTOMER_ID')) & (psf.col('a.model_date') == psf.col('b.model_date'))),
            how='left'
        )
        .join(
            most_recent_complaint_type.alias('c'),
            on = ((psf.col('a.CUSTOMER_KEY') == psf.col('c.CUSTOMER_ID')) & (psf.col('a.model_date') == psf.col('c.model_date'))),
            how = "left"
        )
        .withColumn('BILLING_MOST_RECENT_INT',psf.when(psf.col('BILLING_MOST_RECENT_INT').isNull(),0).otherwise(1))
        .withColumn('NETWORK_MOST_RECENT_INT',psf.when(psf.col('NETWORK_MOST_RECENT_INT').isNull(),0).otherwise(1))
        .withColumn('SERVICE_MOST_RECENT_INT',psf.when(psf.col('SERVICE_MOST_RECENT_INT').isNull(),0).otherwise(1))
        .withColumn('DEVICE_MOST_RECENT_INT',psf.when(psf.col('DEVICE_MOST_RECENT_INT').isNull(),0).otherwise(1))
        .drop('CUSTOMER_ID',"model_date")
    )

    for column in complaint_cat_cols:
        customer_complaints_final = categorize_complaints(customer_complaints_final, column)

    return customer_complaints_final


def get_features(
    spark,
    data_dict,
    table_output_schema,
    training=False,
    subscriber_window_start=None,
    subscriber_window_end=None,
    days_before_end_min=None,
    days_before_end_max=None,
):
    """
    Process and clean data, then save it into specified Hive tables.
    """

    subscriber = data_dict["subscriber"]
    subscriber_history = data_dict["subscriber_history"]
    usage_v = data_dict["usage_v"]
    eng_subscriber_history = data_dict["eng_subscriber_history"]
    bill_customer = data_dict["bill_customer"]
    customer = data_dict["customer"]
    port_in_request = data_dict["port_in_request"]
    interactions_v = data_dict["interactions_v"]
    complaints = data_dict["complaints"]

    if training:
        required_vars = [
            subscriber_window_start,
            subscriber_window_end,
            days_before_end_min,
            days_before_end_max,
        ]
        for var in required_vars:
            if var is None:
                raise ValueError(f"Required variable {var} must have a value")

        subs_history_filter = get_subs_history_filter_training(
            subscriber_history, subscriber_window_start, subscriber_window_end
        )

        customer_sample_w_churn_flag, customer_sample_keys = (
            get_customer_sample_training(
                subs_history_filter,
                days_before_end_min,
                days_before_end_max,
            )
        )
        suffix = "train"
    else:
        subs_history_filter = get_subs_history_filter_inference(subscriber_history)

        customer_sample_w_churn_flag, customer_sample_keys = (
            get_customer_sample_inference(subscriber_history)
        )
        suffix = "inf"

    subs_history_filter = write_read(spark, subs_history_filter, f"{table_output_schema}.subs_history_filter{suffix}")
    customer_sample_w_churn_flag = write_read(spark, customer_sample_w_churn_flag, f"{table_output_schema}.customer_sample_w_churn_flag_{suffix}")
    customer_sample_keys = write_read(spark, customer_sample_keys, f"{table_output_schema}.customer_sample_keys_{suffix}")

    print('got customer_sample_w_churn_flag')

    date_end = customer_sample_w_churn_flag.agg(psf.max('model_date')).collect()[0]['max(model_date)']
    date_start = customer_sample_w_churn_flag.agg(psf.min('model_date')).collect()[0]['min(model_date)']
    years, months = get_year_month_lists(date_start, date_end, days_delta=30)

    customer_contract_details = get_contract_details(subscriber_history, customer_sample_w_churn_flag)
    customer_contract_details = write_read(spark, customer_contract_details, f"{table_output_schema}.customer_contract_details_{suffix}")

    print('got customer_contract_details')

    customer_metadata = get_customer_metadata(subscriber, subscriber_history, customer_sample_w_churn_flag)
    customer_metadata = write_read(spark, customer_metadata, f"{table_output_schema}.customer_metadata_{suffix}")

    print('got customer_metadata')

    customer_usage = get_customer_usage(customer_sample_w_churn_flag, customer_sample_keys, usage_v, years, months)
    customer_usage = write_read(spark, customer_usage, f"{table_output_schema}.customer_usage_{suffix}")

    print('got customer_usage')

    customer_multiple_accounts = get_customer_multiple_accounts(customer_sample_keys, customer_sample_w_churn_flag, eng_subscriber_history)
    customer_multiple_accounts = write_read(spark, customer_multiple_accounts, f"{table_output_schema}.customer_multiple_accounts_{suffix}")

    print('got customer_multiple_accounts')

    customer_billing = get_customer_billing(customer_sample_w_churn_flag, customer_sample_keys, bill_customer)
    customer_billing = write_read(spark, customer_billing, f"{table_output_schema}.customer_billing_{suffix}")

    print('got customer_billing')

    customer_demographics = get_customer_demographics(customer_sample_keys, customer)
    customer_demographics = write_read(spark, customer_demographics, f"{table_output_schema}.customer_demographics_{suffix}")

    print('got customer_demographics')

    customer_ported_in_from = get_customer_ported_in_from(customer_sample_w_churn_flag, port_in_request)
    customer_ported_in_from = write_read(spark, customer_ported_in_from, f"{table_output_schema}.customer_ported_in_from_{suffix}")

    print('got customer_ported_in_from')

    customer_allocation_usage = get_customer_allocation_usage(customer_usage, customer_sample_keys, customer_contract_details)
    customer_allocation_usage = write_read(spark, customer_allocation_usage, f"{table_output_schema}.customer_allocation_usage_{suffix}")

    print('got customer_allocation_usage')

    customer_interactions = customer_interactions = get_customer_interactions(
        customer_sample_w_churn_flag, subs_history_filter, interactions_v
    )
    customer_interactions = write_read(spark, customer_interactions, f"{table_output_schema}.customer_interactions_{suffix}")

    print('got customer_interactions')

    customer_complaints = get_customer_complaints(customer_sample_w_churn_flag, complaints)
    customer_complaints = write_read(spark, customer_complaints, f"{table_output_schema}.customer_complaints_{suffix}")

    print('got customer_complaints')

    all_customer_data = (
        customer_sample_w_churn_flag.join(
            customer_metadata,
            on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
            how="left",
        )
        .join(
            customer_contract_details,
            on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
            how="left",
        )
        .join(
            customer_usage,
            on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
            how="left",
        )
        .join(
            customer_billing,
            on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
            how="left",
        )
        .join(
            customer_ported_in_from,
            on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
            how="left",
        )
        .join(
            customer_multiple_accounts,
            on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
            how="left",
        )
        .join(
            customer_demographics,
            on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
            how="left",
        )
        .join(
            customer_allocation_usage,
            on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
            how="left",
        )
        .join(
            customer_interactions,
            on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
            how="left",
        )
        .join(
            customer_complaints,
            on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
            how="left",
        )
        .drop(
            "COMMITMENT_END_DATE",
            "DISCONNECTION_DATE",
            "COMMITMENT_START_DATE",
        )
        .drop_duplicates()
    )
    
    return all_customer_data
