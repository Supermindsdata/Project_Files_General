# Databricks notebook source
# MAGIC %run ./data_import

# COMMAND ----------

# MAGIC %run ./featurization

# COMMAND ----------

schema_location = "hive_metastore.cvm_churn_90_60_1"
spark.sql("CREATE SCHEMA IF NOT EXISTS {}".format(schema_location))

# COMMAND ----------

data_dict = get_data_dict()
feature_data =  get_features(spark, data_dict,schema_location, training=True,subscriber_window_start='2024-01-01',subscriber_window_end='2024-02-01',days_before_end_min=60, days_before_end_max=90)

feature_data.write.mode("overwrite").saveAsTable("hive_metastore.cvm_churn_90_60_1.training_data")

# COMMAND ----------

schema_path = "hive_metastore.cvm_churn_90_60_1."
customer_sample_w_churn_flag = spark.read.table(schema_path + "customer_sample_w_churn_flag" + "_train")
customer_metadata = spark.read.table(schema_path + "customer_metadata" + "_train")
customer_contract_details = spark.read.table(schema_path + "customer_contract_details" + "_train")
customer_usage = spark.read.table(schema_path + "customer_usage" + "_train")
customer_billing = spark.read.table(schema_path + "customer_billing" + "_train")
customer_ported_in_from = spark.read.table(schema_path + "customer_ported_in_from" + "_train")
customer_multiple_accounts = spark.read.table(schema_path + "customer_multiple_accounts" + "_train")
customer_demographics = spark.read.table(schema_path + "customer_demographics" + "_train")
customer_allocation_usage = spark.read.table(schema_path + "customer_allocation_usage" + "_train")
customer_interactions = spark.read.table(schema_path + "customer_interactions" + "_train")
customer_complaints = spark.read.table(schema_path + "customer_complaints" + "_train")

all_customer_data = (
    customer_sample_w_churn_flag.join(
        customer_metadata,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_contract_details,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_usage,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_billing,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_ported_in_from,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_multiple_accounts,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_demographics,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_allocation_usage,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_interactions,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_complaints,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .drop(
        "COMMITMENT_END_DATE",
        "DISCONNECTION_DATE",
        "COMMITMENT_START_DATE",
    )
    .drop_duplicates()
)
    
all_customer_data.write.mode("overwrite").saveAsTable("hive_metastore.cvm_churn_90_60_1.training_data")