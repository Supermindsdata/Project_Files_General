# Databricks notebook source
import pyspark.sql.functions as psf
import pandas as pd
from pyspark.sql.types import IntegerType
from joblib import load

# COMMAND ----------

model = load('/dbfs/FileStore/shared_uploads/jsanders@corpuk.net/cvm/SIM12.joblib')

# COMMAND ----------

LOB = 'Voice_SIMO'
COMMITMENT_DURATION = '12'
METRIC_ID = 'PRO-RET:SIM12'

# COMMAND ----------

sdf = (
    spark.read.table('hive_metastore.cvm_churn_90_60.inference_features')
    .filter((psf.col('LOB') == LOB) & (psf.col('COMMITMENT_DURATION') == 12))
)

sdf.count()

# COMMAND ----------

features_to_include = [
    'std_PAST_DUE_AMT',
    'voi_alloc_50',
    'three_tenure',
    'int_want_cancel',
    'accs_upgrade',
    'mbs_alloc_75',
    'COUNT_OF_ON_NET_CALLS',
    'std_RECURRING_CHRG_AMT',
    'mean_BILL_PREV_BALANCE_AMT',
    'mean_TOTAL_DUE_AMT',
    'AMOUNT_OF_DATA',
    'AVE_UNIQ_NUMS_DIALLED',
    'mean_OVERDUE_AMT',
    'mean_BILL_PYM_RECEIVED_AMT'
]

data_types = {
    "first_contract": "Boolean",
    "DATA_AYCE_IND": "Boolean",
    "VOICE_AYCE_IND": "Boolean",
    "mbs_alloc_50": "Boolean",
    "mbs_alloc_75": "Boolean",
    "mbs_alloc_90": "Boolean",
    "mbs_alloc_all": "Boolean",
    "voi_alloc_50": "Boolean",
    "voi_alloc_75": "Boolean",
    "voi_alloc_90": "Boolean",
    "voi_alloc_all": "Boolean",
    "three_tenure": "Numerical",
    "voice_time": "Numerical",
    "AMOUNT_OF_DATA": "Numerical",
    "ONNET_TIME": "Numerical",
    "FAH_ROAMING_DATA": "Numerical",
    "OUT_OF_BUNDLE_TIME": "Numerical",
    "COUNT_OF_VOICE_CALLS": "Numerical",
    "COUNT_OF_ON_NET_CALLS": "Numerical",
    "AVE_UNIQ_NUMS_DIALLED": "Numerical",
    "MEAN_VOICE": "Numerical",
    "STDDEV_VOICE": "Numerical",
    "MEAN_DATA": "Numerical",
    "STDDEV_DATA": "Numerical",
    "accs_opened": "Numerical",
    "acc_acq_rec": "Numerical",
    "accs_closed": "Numerical",
    "accs_upgrade": "Numerical",
    "other_acc_FTG": "Numerical",
    "other_acc_ret_window": "Numerical",
    "other_acc_inlife": "Numerical",
    "MRC_PCT_DISCOUNT_AMORTISED": "Numerical",
    "MRC_TARIFF": "Numerical",
    "MRC_PRICE_MODIFIER": "Numerical",
    "MRC_INSURANCE": "Numerical",
    "MRC_OTHER": "Numerical",
    "MRC_DISCOUNT": "Numerical",
    "DISCOUNT_PERCENTAGE": "Numerical",
    "MRC_PCT_DISCOUNT": "Numerical",
    "MRC_FIXED_DISCOUNT": "Numerical",
    "LOB": "Categorical",
    "COMMITMENT_DURATION": "Categorical",
    "DEVICE_TYPE": "Categorical",
    "DEVICE_BRAND": "Categorical",
    "DEVICE_MODEL": "Categorical",
    "GBYTE_ALLOWANCE_GROUP": "Categorical",
    "MINUTES_ALLOWANCE_GROUP": "Categorical",
    "PLAN_TARIFF_GROUP": "Categorical",
    "mean_BILL_PREV_BALANCE_AMT": "Numerical",
    "std_BILL_PREV_BALANCE_AMT": "Numerical",
    "mean_BILL_PYM_RECEIVED_AMT": "Numerical",
    "std_BILL_PYM_RECEIVED_AMT": "Numerical",
    "mean_PAST_DUE_AMT": "Numerical",
    "std_PAST_DUE_AMT": "Numerical",
    "mean_LATE_PYM_BASE_AMT": "Numerical",
    "std_LATE_PYM_BASE_AMT": "Numerical",
    "mean_LATE_PYM_CHRG_AMT": "Numerical",
    "std_LATE_PYM_CHRG_AMT": "Numerical",
    "mean_CURR_DISCOUNT_AMT": "Numerical",
    "std_CURR_DISCOUNT_AMT": "Numerical",
    "mean_TOTAL_DUE_AMT": "Numerical",
    "std_TOTAL_DUE_AMT": "Numerical",
    "mean_OVERDUE_AMT": "Numerical",
    "std_OVERDUE_AMT": "Numerical",
    "mean_RECURRING_CHRG_AMT": "Numerical",
    "std_RECURRING_CHRG_AMT": "Numerical",
    "mean_LOCAL_USAGE_CHRG_AMT": "Numerical",
    "std_LOCAL_USAGE_CHRG_AMT": "Numerical",
    "mean_ROAMING_USAGE_CHRG_AMT": "Numerical",
    "std_ROAMING_USAGE_CHRG_AMT": "Numerical",
    "mean_DATA_USAGE_CHRG_AMT": "Numerical",
    "std_DATA_USAGE_CHRG_AMT": "Numerical",
    'int_want_cancel': "Numerical",
    'int_want_upgrade': "Numerical",
    'int_new_ph_con': "Numerical",
    'int_bill_enq': "Numerical",
    'int_refund_enq': "Numerical",
    'int_tech_enq': "Numerical",
    'int_make_payment': "Numerical",
    'int_network': "Numerical",
    'int_tariff_enq': "Numerical",
    'int_offers_enq': "Numerical",
    'int_want_pac': "Numerical",
    'int_want_dat_addon': "Numerical",
    'int_comp_better_offer': "Numerical",
    'int_want_better_deal': "Numerical",
    'outcome_case_raised': "Numerical",
    'outcome_pac_given': "Numerical",
    'outcome_cons_offer': "Numerical",
    'WTC_calls': "Numerical",
    'int_total': "Numerical",
    'Total_complaints': "Numerical",
    'Billing_complaints': "Numerical",
    'Network_complaints': "Numerical",
    'Service_complaints': "Numerical",
    'Device_complaints': "Numerical",
}

BOOL_COLS = [i for i in features_to_include if data_types[i] == "Boolean"]

NUMERICAL_COLS = [i for i in features_to_include if data_types[i] == "Numerical"]

CATEGORICAL_COLS = [
    i for i in features_to_include if data_types[i] == "Categorical"
]

# COMMAND ----------

pdf = sdf.toPandas()

# COMMAND ----------

# Preprocess boolean columns
for col_name in BOOL_COLS:
    pdf[col_name] = pdf[col_name].astype(str)

# Preprocess numerical columns
for col_name in NUMERICAL_COLS:
    pdf[col_name] = pd.to_numeric(pdf[col_name], errors='coerce')

# Preprocess categorical columns
for col_name in CATEGORICAL_COLS:
    pdf[col_name] = pdf[col_name].fillna('')

# COMMAND ----------

pred = model.predict(pdf)
pred_proba = model.predict_proba(pdf)[:, 1]

pdf['pred'] = pred
pdf['pred_proba'] = pred_proba

# COMMAND ----------

results_sdf = spark.createDataFrame(pdf)

# COMMAND ----------

results_sdf.display()

# COMMAND ----------

from pyspark.sql.window import Window

window_spec = Window.orderBy(psf.col('SCORE'))

snowflake_predictions = (
    results_sdf
    .withColumn('SCORE', (psf.round(psf.col('pred_proba'), 2) * 100).astype(IntegerType()))
    .withColumn('METRIC_ID', psf.lit(METRIC_ID))
    .withColumn('MODEL_DATE',  psf.to_timestamp(psf.date_sub(psf.next_day(psf.current_date(), 'friday'), 7)))
    .withColumn('NTILE', psf.ntile(20).over(window_spec))
    .withColumn('SCORE', psf.concat(psf.lit('nt'), psf.col('NTILE'), psf.lit(' - pv'), psf.col('SCORE')))
    .select(
        'SUBSCRIBER_KEY',
        'CUSTOMER_KEY',
        'METRIC_ID',
        'SCORE',
        'MODEL_DATE'
    )
    .distinct()
)

print(snowflake_predictions.count())
print(snowflake_predictions.select('SUBSCRIBER_KEY','CUSTOMER_KEY').distinct().count())

# COMMAND ----------

import seaborn as sns
import matplotlib.pyplot as plt

result_df = snowflake_predictions.withColumn("score_bracket", psf.floor(psf.col("SCORE_O") / 10) * 10) \
    .groupBy("score_bracket") \
    .count() \
    .withColumn("percentage", psf.col("count") / snowflake_predictions.count() * 100) \
    .orderBy("score_bracket") \
    .toPandas()

# Plotting using Seaborn
sns.barplot(x="score_bracket", y="percentage", data=result_df)
plt.title("Percentage of Total Rows per Score Bracket")
plt.xlabel("Score Bracket")
plt.ylabel("% of Total Rows")
plt.show()

# COMMAND ----------

PROD_USER = dbutils.secrets.get(scope="DS_SA",key="username")
PROD_PWD = dbutils.secrets.get(scope="DS_SA",key="password")
SNOWFLAKE_OUTPUT_TABLE = 'DECISION_B2C_SUBSCRIPTION_MODEL_SCORE_HIST'

BDS_MAKE_CONSUMER_OPTIONS = {
    "sfUrl": "threemobile.west-europe.privatelink.snowflakecomputing.com",
    "sfUser": f"{PROD_USER}",
    "sfPassword": f"{PROD_PWD}",
    "sfDatabase": 'PRD_BDS_MAKECONSUMER',
    "sfSchema": 'PROD_MAKECONSUMER',
    "sfRole" : "DATA3PRODBDSMAKECONSUMER",
    "sfWarehouse": "PRD_BDS_REPORTING_MAKECONSUMER_TRANSFORMATION_WH",
}

snowflake_predictions.write.format("snowflake").options(**BDS_MAKE_CONSUMER_OPTIONS).option("dbtable", SNOWFLAKE_OUTPUT_TABLE).mode("append").save()

# COMMAND ----------

def get_snowflake_table_as_sdf(snowflake_options, table):
    """
    Reads a table from Snowflake and returns it as a Spark DataFrame (sdf).

    Args:
    snowflake_options (dict): A dictionary containing the connection options for Snowflake.
    table (str): The name of the table to be loaded from Snowflake.

    Returns:
    pyspark.sql.DataFrame: A Spark DataFrame containing the data from the specified Snowflake table.
    """

    sdf = (
        spark.read
        .format("snowflake")
        .options(**snowflake_options)
        .option("dbtable", table)
        .load()
    )

    return sdf


sdf = get_snowflake_table_as_sdf(BDS_MAKE_CONSUMER_OPTIONS,'DECISION_B2C_SUBSCRIPTION_MODEL_SCORE_HIST')

sdf.groupby('MODEL_DATE','METRIC_ID').count().display()