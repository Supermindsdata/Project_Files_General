# Databricks notebook source
customer_sample_w_churn_flag = spark.read.table("hive_metastore.cvm_churn_90_60.customer_sample_w_churn_flag_train")
customer_sample_w_churn_flag.count()

# COMMAND ----------

# MAGIC %run ./data_import

# COMMAND ----------

# MAGIC %run ./featurization

# COMMAND ----------

schema_location = "hive_metastore.cvm_churn_90_60"
spark.sql("CREATE SCHEMA IF NOT EXISTS {}".format(schema_location))

# COMMAND ----------

data_dict = get_data_dict()
feature_data =  get_features(spark, data_dict,schema_location, training=True,subscriber_window_start='2023-10-06',subscriber_window_end='2023-11-06',days_before_end_min=30, days_before_end_max=60)

# COMMAND ----------

suffix = "train"

dim_subscriber_key_t = data_dict["dim_subscriber_key_t"]
customer_sample_w_churn_flag = spark.read.table("hive_metastore.cvm_churn_90_60.customer_sample_w_churn_flag_train")

customer_acquisition_channel = get_customer_acquisition_channel(customer_sample_w_churn_flag,dim_subscriber_key_t)
customer_acquisition_channel = write_read(spark, customer_acquisition_channel, f"{schema_location}.customer_acquisition_channel_{suffix}")

# COMMAND ----------

customer_sample_w_churn_flag = spark.read.table("hive_metastore.cvm_churn_90_60.customer_sample_w_churn_flag_train")
customer_metadata = spark.read.table("hive_metastore.cvm_churn_90_60.customer_metadata_train")
customer_contract_details = spark.read.table("hive_metastore.cvm_churn_90_60.customer_contract_details_train")
customer_usage = spark.read.table("hive_metastore.cvm_churn_90_60.customer_usage_train")
customer_billing = spark.read.table("hive_metastore.cvm_churn_90_60.customer_billing_train")
customer_ported_in_from = spark.read.table("hive_metastore.cvm_churn_90_60.customer_ported_in_from_train")
customer_multiple_accounts = spark.read.table("hive_metastore.cvm_churn_90_60.customer_multiple_accounts_train")
customer_demographics = spark.read.table("hive_metastore.cvm_churn_90_60.customer_demographics_train")
customer_allocation_usage = spark.read.table("hive_metastore.cvm_churn_90_60.customer_allocation_usage_train")
customer_interactions = spark.read.table("hive_metastore.cvm_churn_90_60.customer_interactions_train")
customer_complaints = spark.read.table("hive_metastore.cvm_churn_90_60.customer_complaints_train")
customer_acquisition_channel = spark.read.table("hive_metastore.cvm_churn_90_60.customer_acquisition_channel_train")

all_customer_data = (
    customer_sample_w_churn_flag.join(
        customer_metadata,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_contract_details,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_usage,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_billing,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_ported_in_from,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_multiple_accounts,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_demographics,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_allocation_usage,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_interactions,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_complaints,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .join(
        customer_acquisition_channel,
        on=["CUSTOMER_KEY", "SUBSCRIBER_KEY"],
        how="left",
    )
    .drop(
        "COMMITMENT_END_DATE",
        "DISCONNECTION_DATE",
        "COMMITMENT_START_DATE",
    )
    .drop_duplicates()
)

# COMMAND ----------

all_customer_data.write.saveAsTable("hive_metastore.cvm_churn_90_60.all_customer_data_acq")

# COMMAND ----------

all_customer_data = spark.read.table("hive_metastore.cvm_churn_90_60.all_customer_data")

# COMMAND ----------

data_dict = get_data_dict()

data_dict.keys()

#CHANNEL_ACQ,
#CHANNEL_ACQ_SUBCH_1

# COMMAND ----------

def get_snowflake_table_as_sdf(snowflake_options, table):
    """
    Reads a table from Snowflake and returns it as a Spark DataFrame (sdf).

    Args:
    snowflake_options (dict): A dictionary containing the connection options for Snowflake.
    table (str): The name of the table to be loaded from Snowflake.

    Returns:
    pyspark.sql.DataFrame: A Spark DataFrame containing the data from the specified Snowflake table.
    """

    sdf = (
        spark.read.format("snowflake")
        .options(**snowflake_options)
        .option("dbtable", table)
        .load()
    )

    return sdf

prod_user = dbutils.secrets.get(scope="DS_SA", key="username")
prod_pwd = dbutils.secrets.get(scope="DS_SA", key="password")

bds_prod_user = dbutils.secrets.get(scope="COEX", key="sf_bds_u")
bds_prod_pwd = dbutils.secrets.get(scope="COEX", key="sf_bds_p")

bds_make_consumer_options = {
    "sfUrl": "threemobile.west-europe.privatelink.snowflakecomputing.com",
    "sfUser": f"{prod_user}",
    "sfPassword": f"{prod_pwd}",
    "sfDatabase": "PROD_SANDBOX",
    "sfRole": "DATA3PRODBDSMAKECONSUMER",
    "sfWarehouse": "PRD_BDS_REPORTING_MAKECONSUMER_TRANSFORMATION_WH",
}

prod_reader_options = {
    "sfUrl": "threemobile.west-europe.privatelink.snowflakecomputing.com",
    "sfUser": f"{prod_user}",
    "sfPassword": f"{prod_pwd}",
    "sfDatabase": "PROD_SANDBOX",
    "sfRole": "DATA3-PROD-READER",
    "sfWarehouse": "PRD_IDW_REPORTING_WH",
}

bds_options = {
    "sfUrl": "threemobile.west-europe.privatelink.snowflakecomputing.com",
    "sfUser": f"{bds_prod_user}",
    "sfPassword": f"{bds_prod_pwd}",
    "sfDatabase": "PROD_SANDBOX",
    "sfSchema": "PRS_B2C_TMP",
    "sfWarehouse": "PRD_IDW_REPORTING_WH",
    "sfRole": "SVCPRDDATA3BDSCONSOLIDATION",
}

DIM_SUBSCRIBER_KEY_T = get_snowflake_table_as_sdf(
    bds_options, "PROD_SANDBOX.ALDM_ANALYTICS.DIM_SUBSCRIBER_KEY_T"
)

DIM_SUBSCRIBER_KEY_T.display()

# COMMAND ----------

customer_sample_w_churn_flag = spark.read.table("hive_metastore.cvm_churn_90_60.customer_sample_w_churn_flag_train")

customer_sample_w_churn_flag
sdf = (
    DIM_SUBSCRIBER_KEY_T
    .select('CUSTOMER_KEY','SUBSCRIBER_KEY','CHANNEL_ACQ','CHANNEL_ACQ_SUBCH','CHANNEL_ACQ_SUBCH_1','CHANNEL_ACQ_SUBCH_2','CHANNEL_ACQ_SUBCH_3')
    .distinct()
)

sdf_join = customer_sample_w_churn_flag.join(sdf,how="left",on=['CUSTOMER_KEY','SUBSCRIBER_KEY']).distinct()

print(sdf_join.select('CHANNEL_ACQ').distinct().collect())
print(sdf_join.select('CHANNEL_ACQ_SUBCH_1').distinct().collect())