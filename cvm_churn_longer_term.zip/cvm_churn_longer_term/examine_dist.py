# Databricks notebook source
import pyspark.sql.functions as psf

# COMMAND ----------

def get_snowflake_table_as_sdf(snowflake_options, table):
    """
    Reads a table from Snowflake and returns it as a Spark DataFrame (sdf).

    Args:
    snowflake_options (dict): A dictionary containing the connection options for Snowflake.
    table (str): The name of the table to be loaded from Snowflake.

    Returns:
    pyspark.sql.DataFrame: A Spark DataFrame containing the data from the specified Snowflake table.
    """

    sdf = (
        spark.read
        .format("snowflake")
        .options(**snowflake_options)
        .option("dbtable", table)
        .load()
    )

    return sdf

PROD_USER = dbutils.secrets.get(scope="DS_SA",key="username")
PROD_PWD = dbutils.secrets.get(scope="DS_SA",key="password")

BDS_MAKE_CONSUMER_OPTIONS = {
    "sfUrl": "threemobile.west-europe.privatelink.snowflakecomputing.com",
    "sfUser": f"{PROD_USER}",
    "sfPassword": f"{PROD_PWD}",
    "sfDatabase": 'PRD_BDS_MAKECONSUMER',
    "sfSchema": 'PROD_MAKECONSUMER',
    "sfRole" : "DATA3PRODBDSMAKECONSUMER",
    "sfWarehouse": "PRD_BDS_REPORTING_MAKECONSUMER_TRANSFORMATION_WH",
}

sdf = get_snowflake_table_as_sdf(BDS_MAKE_CONSUMER_OPTIONS,'DECISION_B2C_SUBSCRIPTION_MODEL_SCORE_HIST')

sdf.groupby('MODEL_DATE','METRIC_ID').count().display()

# COMMAND ----------

import seaborn as sns
import matplotlib.pyplot as plt

metric = 'PRO-RET:SIM24'
m_sdf = sdf.filter(psf.col('MODEL_DATE')=='2024-02-01T00:00:00.000+00:00').filter(psf.col('METRIC_ID')==metric)

# Assuming df is your PySpark DataFrame
# Generate score brackets
score_brackets = list(range(0, 101, 10))

# Group by score brackets and count rows
result_df = m_sdf.withColumn("score_bracket", psf.floor(psf.col("SCORE") / 10) * 10) \
    .groupBy("score_bracket") \
    .count() \
    .withColumn("percentage", psf.col("count") / m_sdf.count() * 100) \
    .orderBy("score_bracket") \
    .toPandas()

# Plotting using Seaborn
sns.barplot(x="score_bracket", y="percentage", data=result_df)
plt.title("Percentage of Total Rows per Score Bracket")
plt.xlabel("Score Bracket")
plt.ylabel("% of Total Rows")
plt.show()

# COMMAND ----------

subscriber_history = get_snowflake_table_as_sdf(
    BDS_MAKE_CONSUMER_OPTIONS, "PROD_SANDBOX.ALDM_ANALYTICS.ENG_SUBSCRIBER_HISTORY"
)

subs_history_filter = (
    subscriber_history.withColumn("model_date", psf.current_date())
    .withColumn(
        "DISCONNECTION_DATE",
        psf.when(
            psf.col("DISCONNECTION_DATE") == "3333-03-03T00:00:00Z", None
        ).otherwise(psf.col("DISCONNECTION_DATE")),
    )
    .withColumn(
        "days_diff",
        psf.datediff(psf.col("model_date"), psf.col("COMMITMENT_END_DATE")),
    )
    .filter(psf.col("CUSTOMER_TYPE") == "B2C")
    .filter(psf.col("CUSTOMER_SUB_TYPE") == "Individual")
    .filter(psf.col("LOB").isin("Voice_SIMO", "Voice_CHS"))
    .filter((psf.col("days_diff") < -30) & (psf.col("days_diff") >= -60))
    .filter(psf.col("DISCONNECTION_DATE").isNull())
)

subs_history_filter.select('CUSTOMER_KEY','SUBSCRIBER_KEY','LOB','COMMITMENT_DURATION').distinct().groupby('LOB','COMMITMENT_DURATION').count().display()