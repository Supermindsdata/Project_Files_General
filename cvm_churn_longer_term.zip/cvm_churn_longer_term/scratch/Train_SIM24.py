# Databricks notebook source
# MAGIC %pip install catboost

# COMMAND ----------

# MAGIC %run ./train

# COMMAND ----------

all_customer_data = spark.read.table("hive_metastore.cvm_churn_90_60.all_customer_data")
training_data_location = "hive_metastore.cvm_churn_90_60.all_customer_data"
train_df = spark.sql("SELECT * FROM {} WHERE set='train' AND LOB='Voice_SIMO' AND COMMITMENT_DURATION=24".format(training_data_location))
test_df = spark.sql("SELECT * FROM {} WHERE set='test' AND LOB='Voice_SIMO' AND COMMITMENT_DURATION=24".format(training_data_location))

# COMMAND ----------

train_df.groupby('churn_flag').count().display()

# COMMAND ----------

test_df.groupby('churn_flag').count().display()

# COMMAND ----------

features_to_include = ['first_contract',
 'three_tenure',
 'voice_time',
 'ONNET_TIME',
 'FAH_ROAMING_DATA',
 'OUT_OF_BUNDLE_TIME',
 'COUNT_OF_VOICE_CALLS',
 'COUNT_OF_ON_NET_CALLS',
 'AVE_UNIQ_NUMS_DIALLED',
 'MEAN_VOICE',
 'MEAN_DATA',
 'accs_opened',
 'acc_acq_rec',
 'accs_closed',
 'accs_upgrade',
 'other_acc_ret_window',
 'other_acc_inlife',
 'MRC_PCT_DISCOUNT_AMORTISED',
 'MRC_TARIFF',
 'MRC_PRICE_MODIFIER',
 'MRC_INSURANCE',
 'MRC_OTHER',
 'MRC_FIXED_DISCOUNT',
 'mean_PAST_DUE_AMT',
 'mean_RECURRING_CHRG_AMT',
 'std_LOCAL_USAGE_CHRG_AMT',
 'mean_ROAMING_USAGE_CHRG_AMT',
 'std_ROAMING_USAGE_CHRG_AMT',
 'mean_DATA_USAGE_CHRG_AMT',
 'std_DATA_USAGE_CHRG_AMT',
 'int_want_cancel',
 'int_want_upgrade',
 'int_new_ph_con',
 'int_bill_enq',
 'int_refund_enq',
 'int_tech_enq',
 'outcome_cons_offer',
 'int_total',
]

data_types = {
    "first_contract": "Boolean",
    "DATA_AYCE_IND": "Boolean",
    "VOICE_AYCE_IND": "Boolean",
    "mbs_alloc_50": "Boolean",
    "mbs_alloc_75": "Boolean",
    "mbs_alloc_90": "Boolean",
    "mbs_alloc_all": "Boolean",
    "voi_alloc_50": "Boolean",
    "voi_alloc_75": "Boolean",
    "voi_alloc_90": "Boolean",
    "voi_alloc_all": "Boolean",
    "three_tenure": "Numerical",
    "voice_time": "Numerical",
    "AMOUNT_OF_DATA": "Numerical",
    "ONNET_TIME": "Numerical",
    "FAH_ROAMING_DATA": "Numerical",
    "OUT_OF_BUNDLE_TIME": "Numerical",
    "COUNT_OF_VOICE_CALLS": "Numerical",
    "COUNT_OF_ON_NET_CALLS": "Numerical",
    "AVE_UNIQ_NUMS_DIALLED": "Numerical",
    "MEAN_VOICE": "Numerical",
    "STDDEV_VOICE": "Numerical",
    "MEAN_DATA": "Numerical",
    "STDDEV_DATA": "Numerical",
    "accs_opened": "Numerical",
    "acc_acq_rec": "Numerical",
    "accs_closed": "Numerical",
    "accs_upgrade": "Numerical",
    "other_acc_FTG": "Numerical",
    "other_acc_ret_window": "Numerical",
    "other_acc_inlife": "Numerical",
    "MRC_PCT_DISCOUNT_AMORTISED": "Numerical",
    "MRC_TARIFF": "Numerical",
    "MRC_PRICE_MODIFIER": "Numerical",
    "MRC_INSURANCE": "Numerical",
    "MRC_OTHER": "Numerical",
    "MRC_DISCOUNT": "Numerical",
    "DISCOUNT_PERCENTAGE": "Numerical",
    "MRC_PCT_DISCOUNT": "Numerical",
    "MRC_FIXED_DISCOUNT": "Numerical",
    "LOB": "Categorical",
    "COMMITMENT_DURATION": "Categorical",
    "DEVICE_TYPE": "Categorical",
    "DEVICE_BRAND": "Categorical",
    "DEVICE_MODEL": "Categorical",
    "GBYTE_ALLOWANCE_GROUP": "Categorical",
    "MINUTES_ALLOWANCE_GROUP": "Categorical",
    "PLAN_TARIFF_GROUP": "Categorical",
    "mean_BILL_PREV_BALANCE_AMT": "Numerical",
    "std_BILL_PREV_BALANCE_AMT": "Numerical",
    "mean_BILL_PYM_RECEIVED_AMT": "Numerical",
    "std_BILL_PYM_RECEIVED_AMT": "Numerical",
    "mean_PAST_DUE_AMT": "Numerical",
    "std_PAST_DUE_AMT": "Numerical",
    "mean_LATE_PYM_BASE_AMT": "Numerical",
    "std_LATE_PYM_BASE_AMT": "Numerical",
    "mean_LATE_PYM_CHRG_AMT": "Numerical",
    "std_LATE_PYM_CHRG_AMT": "Numerical",
    "mean_CURR_DISCOUNT_AMT": "Numerical",
    "std_CURR_DISCOUNT_AMT": "Numerical",
    "mean_TOTAL_DUE_AMT": "Numerical",
    "std_TOTAL_DUE_AMT": "Numerical",
    "mean_OVERDUE_AMT": "Numerical",
    "std_OVERDUE_AMT": "Numerical",
    "mean_RECURRING_CHRG_AMT": "Numerical",
    "std_RECURRING_CHRG_AMT": "Numerical",
    "mean_LOCAL_USAGE_CHRG_AMT": "Numerical",
    "std_LOCAL_USAGE_CHRG_AMT": "Numerical",
    "mean_ROAMING_USAGE_CHRG_AMT": "Numerical",
    "std_ROAMING_USAGE_CHRG_AMT": "Numerical",
    "mean_DATA_USAGE_CHRG_AMT": "Numerical",
    "std_DATA_USAGE_CHRG_AMT": "Numerical",
    'int_want_cancel': "Numerical",
    'int_want_upgrade': "Numerical",
    'int_new_ph_con': "Numerical",
    'int_bill_enq': "Numerical",
    'int_refund_enq': "Numerical",
    'int_tech_enq': "Numerical",
    'int_make_payment': "Numerical",
    'int_network': "Numerical",
    'int_tariff_enq': "Numerical",
    'int_offers_enq': "Numerical",
    'int_want_pac': "Numerical",
    'int_want_dat_addon': "Numerical",
    'int_comp_better_offer': "Numerical",
    'int_want_better_deal': "Numerical",
    'outcome_case_raised': "Numerical",
    'outcome_pac_given': "Numerical",
    'outcome_cons_offer': "Numerical",
    'WTC_calls': "Numerical",
    'int_total': "Numerical",
    'Total_complaints': "Numerical",
    'Billing_complaints': "Numerical",
    'Network_complaints': "Numerical",
    'Service_complaints': "Numerical",
    'Device_complaints': "Numerical",
}

# COMMAND ----------

BOOL_COLS = [i for i in features_to_include if data_types[i] == "Boolean"]

NUMERICAL_COLS = [i for i in features_to_include if data_types[i] == "Numerical"]

CATEGORICAL_COLS = [
    i for i in features_to_include if data_types[i] == "Categorical"
]

# COMMAND ----------

# Convert PySpark DataFrame to pandas DataFrame
train_pdf = train_df.toPandas()
test_pdf = test_df.toPandas()

# COMMAND ----------

import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.metrics import roc_auc_score, precision_score, recall_score, f1_score

# Preprocess boolean columns
for col_name in BOOL_COLS:
    train_pdf[col_name] = train_pdf[col_name].astype(str)
    test_pdf[col_name] = test_pdf[col_name].astype(str)

# Preprocess numerical columns
for col_name in NUMERICAL_COLS:
    train_pdf[col_name] = pd.to_numeric(train_pdf[col_name], errors='coerce')
    test_pdf[col_name] = pd.to_numeric(test_pdf[col_name], errors='coerce')

# Preprocess categorical columns
for col_name in CATEGORICAL_COLS:
    train_pdf[col_name] = train_pdf[col_name].fillna('')
    test_pdf[col_name] = test_pdf[col_name].fillna('')

# Create column transformers
bool_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='mean')),
    ('scaler', StandardScaler())
])

categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

preprocessor = ColumnTransformer(transformers=[
    ('bool', bool_transformer, BOOL_COLS),
    ('numerical', numerical_transformer, NUMERICAL_COLS),
    ('categorical', categorical_transformer, CATEGORICAL_COLS)
])

classifiers = [
    {
        'name': 'Gradient Boosting',
        'classifier': GradientBoostingClassifier(random_state=42),
        'param_grid': {
            'classifier__n_estimators': [100],
            'classifier__max_depth': [3],
            'classifier__learning_rate': [0.1]
        }
    },
]

# Create an empty DataFrame to store the results
results_df = pd.DataFrame(columns=['Classifier', 'Best Parameters', 'Test AUC', 'Test Precision', 'Test Recall', 'Test F1'])

# Iterate over the classifiers
for cls in classifiers:
    print(f"Training {cls['name']}...")
    
    # Create the pipeline
    pipeline = Pipeline(steps=[('preprocessor', preprocessor),('classifier', cls['classifier'])])
    
    # Create the grid search object
    grid_search = GridSearchCV(pipeline, cls['param_grid'], cv=3, scoring='roc_auc')
    
    # Balance the training data
    train_pdf_balanced = pd.concat([
        train_pdf[train_pdf['churn_flag'] == 0].sample(n=len(train_pdf[train_pdf['churn_flag'] == 1]), random_state=42),
        train_pdf[train_pdf['churn_flag'] == 1]
    ])

    print(len(train_pdf_balanced))
    
    # Split the balanced training data into features and target
    X_train = train_pdf_balanced[features_to_include]
    y_train = train_pdf_balanced['churn_flag']
    
    # Fit the grid search object
    grid_search.fit(X_train, y_train)
    
    # Get the best model
    best_model = grid_search.best_estimator_
    
    # Balance the test data
    test_pdf_balanced = pd.concat([
        test_pdf[test_pdf['churn_flag'] == 0].sample(n=len(test_pdf[test_pdf['churn_flag'] == 1]), random_state=42),
        test_pdf[test_pdf['churn_flag'] == 1]
    ])
    
    # Split the balanced test data into features and target
    X_test = test_pdf_balanced.drop('churn_flag', axis=1)
    y_test = test_pdf_balanced['churn_flag']
    
    # Make predictions on the balanced test data
    y_pred = best_model.predict(X_test)
    y_pred_proba = best_model.predict_proba(X_test)[:, 1]
    
    # Compute metrics
    test_auc = roc_auc_score(y_test, y_pred_proba)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    
    # Store the results in the DataFrame
    results_df = results_df.append({
        'Classifier': cls['name'],
        'Best Parameters': grid_search.best_params_,
        'Test AUC': test_auc,
        'Test Precision': precision,
        'Test Recall': recall,
        'Test F1': f1
    }, ignore_index=True)
    
    print(f"Best parameters for {cls['name']}: {grid_search.best_params_}")
    print(f"Test AUC for {cls['name']}: {test_auc:.4f}")
    print(f"Test Precision for {cls['name']}: {precision:.4f}")
    print(f"Test Recall for {cls['name']}: {recall:.4f}")
    print(f"Test F1 for {cls['name']}: {f1:.4f}")
    print("---")

# Display the results DataFrame
print("Results:")
print(results_df)

# COMMAND ----------

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

corr_matrix = train_pdf[NUMERICAL_COLS].corr()

# Get the upper triangular matrix of the correlation matrix
upper_tri = np.triu(corr_matrix, k=1)

# Create a mask for the upper triangular matrix
mask = upper_tri != 0

# Get the indices of the non-zero elements in the upper triangular matrix
indices = np.nonzero(mask)

# Create a list of tuples containing the variable pairs and their correlation coefficients
corr_pairs = [(corr_matrix.columns[i], corr_matrix.columns[j], corr_matrix.iloc[i,j]) for i, j in zip(*indices)]
# Create a DataFrame from the correlation pairs
df_pairs = pd.DataFrame(corr_pairs, columns=['Variable 1', 'Variable 2', 'Correlation'])

# Sort the DataFrame in descending order based on the absolute value of the correlation coefficient
df_pairs['Absolute Correlation'] = df_pairs['Correlation'].abs()
df_pairs.sort_values('Absolute Correlation', ascending=False, inplace=True)
df_pairs.drop('Absolute Correlation', axis=1, inplace=True)

df_pairs.display()

# COMMAND ----------

# Get feature importance
feature_importance = best_model.named_steps['classifier'].feature_importances_

# Print feature importance
res = []
for i, feature in enumerate(X_train.columns):
    res.append({"feature":feature, "importance":feature_importance[i]})
pd.DataFrame(res).display()