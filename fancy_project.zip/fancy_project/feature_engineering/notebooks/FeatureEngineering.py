# Databricks notebook source
##################################################################################
# Generate and Write Features Notebook
#
# This notebook can be used to generate and write features to a table.
# It is configured and can be executed as the tasks in the write_feature_table_job workflow defined under
# ``fancy_project/resources/feature-engineering-workflow-resource.yml``
#
# Parameters:
#
# * output_catalog (required)  - catalog where we wish to save the features
# * output_schema (required)  - schema where we wish to save the features
# * output_table (required)  - table where we wish to save the features
##################################################################################

# COMMAND ----------
# Set up the input parameters for the notebook. These are populated automatically for the jobs but this is helpful for debugging the ntebook in dev environments

dbutils.widgets.text(
    "output_catalog",
    "hive_metastore",
    label="output_catalog",
)

dbutils.widgets.text(
    "output_schema",
    "fancy_project",
    label="output_schema",
)

dbutils.widgets.text(
    "output_table",
    "cleaned_features",
    label="output_table",
)

# COMMAND ----------
import os
import sys
notebook_path =  '/Workspace/' + os.path.dirname(dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get())
%cd $notebook_path
%cd ..

# COMMAND ----------
from data.data_import import get_data
from features.featurization import clean_col_names

# COMMAND ----------
raw_data_df = get_data()
cleaned_data = clean_col_names(raw_data_df)

# COMMAND ----------
# Get the location to save the training data to (recommended to save as table)
metastore_or_catalog = dbutils.widgets.get("output_catalog")
schema = dbutils.widgets.get("output_schema")
table = dbutils.widgets.get("output_table")

schema_location = '.'.join([metastore_or_catalog, schema])
table_location = '.'.join([metastore_or_catalog, schema, table])

# COMMAND ----------
# Make the schema and table
spark.sql("CREATE SCHEMA IF NOT EXISTS {}".format(schema_location))

# COMMAND ----------
spark.sql("CREATE TABLE IF NOT EXISTS {} (feature_a double, feature_b double, target double)".format(table_location))

# COMMAND ----------
# Save data to delta table
spark_df = spark.createDataFrame(cleaned_data)
spark_df.write.mode('overwrite').saveAsTable(table_location)