# Databricks notebook source
##################################################################################
# Model Training Notebook
#
# This notebook shows an example of a Model Training pipeline using Delta tables.
# It is configured and can be executed as the "Train" task in the model_training_job workflow defined under
# ``fancy_project/resources/model-workflow-resource.yml``
#
# Parameters:
# * env (required):                 - Environment the notebook is run in (staging, or prod). Defaults to "staging".
# * training_catalog (required)     - catalog where we wish to read features from
# * training_schema (required)      - schema where we wish to read features from
# * training_table (required)       - table where we wish to read features from
# * experiment_name (required)      - MLflow experiment name for the training runs. Will be created if it doesn't exist.
# * model_name (required)           - MLflow registered model name to use for the trained model. Will be created if it
# *                                   doesn't exist.
##################################################################################

# COMMAND ----------
# Set up the input parameters for the notebook. These are populated automatically for the jobs but this is helpful for debugging the ntebook in dev environments
dbutils.widgets.dropdown("env", "dev", ["dev", "staging", "prod"], "Environment Name")

dbutils.widgets.text(
    "training_catalog",
    "hive_metastore",
    label="training_catalog",
)

dbutils.widgets.text(
    "training_schema",
    "fancy_project",
    label="training_schema",
)

dbutils.widgets.text(
    "training_table",
    "cleaned_features",
    label="training_table",
)

dbutils.widgets.text(
    "experiment_name",
    "/Users/"+ dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get() + "/dev-fancy_project-experiment",
    label="experiment_name",
)

dbutils.widgets.text(
    "model_name",
    "dev-fancy_project-model",
    label="model_name",
)

# COMMAND ----------
import os
notebook_path =  '/Workspace/' + os.path.dirname(dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get())
%cd $notebook_path

# COMMAND ----------

# MAGIC %pip install -r ../../requirements.txt

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------
import os, sys
notebook_path =  '/Workspace/' + os.path.dirname(dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get())
%cd $notebook_path
%cd ..
sys.path.append('..') # Need this to access utils.py

# COMMAND ----------
from steps.train import training_pipeline
from utils import get_latest_model_version
from mlflow.exceptions import RestException
import mlflow

# COMMAND ----------
env = dbutils.widgets.get("env")

metastore_or_catalog = dbutils.widgets.get("training_catalog")
schema = dbutils.widgets.get("training_schema")
table = dbutils.widgets.get("training_table")

experiment_name = dbutils.widgets.get("experiment_name")
model_name = dbutils.widgets.get("model_name")

# COMMAND ----------
try:
    exp_id = mlflow.create_experiment(experiment_name)
except RestException:
    # experiment already exists
    exp_id = dict(mlflow.get_experiment_by_name(experiment_name))['experiment_id']

# COMMAND ----------
training_data_location = '.'.join([metastore_or_catalog, schema, table])
# Get the data in
data_df = spark.sql("SELECT * FROM {}".format(training_data_location)).toPandas()

# COMMAND ----------

# Do training
training_pipeline(data_df, exp_id=exp_id, model_name=model_name)

# The returned model URI is needed by the model deployment notebook.
model_version = get_latest_model_version(model_name)
model_uri = f"models:/{model_name}/{model_version}"
dbutils.jobs.taskValues.set("model_uri", model_uri)
dbutils.jobs.taskValues.set("model_name", model_name)
dbutils.jobs.taskValues.set("model_version", model_version)
dbutils.notebook.exit(model_uri)